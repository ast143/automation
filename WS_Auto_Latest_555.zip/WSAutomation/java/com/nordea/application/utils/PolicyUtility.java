package com.nordea.application.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;
import com.nordea.pages.EventViewPage;
import com.nordea.pages.PaymentPlan;
import com.nordea.utility.Report;
import com.nordea.workflow.OfferWorkflow;

public class PolicyUtility {

	final static Logger logger = Logger.getLogger(PolicyUtility.class);
	HashMap<String, String> periodsWithStatus = new HashMap<String, String>();

	/**
	 * Functionality: Verification for Invoice due date, Invoice period and Invoice amount
	 * @param test data,futureDuedates,futureInvoiceNo
	 * @throws Exception
	 */

	public String verifyInvoiceStatusandDate(LinkedHashMap<String, String> testData, String futureDuedates,String futureInvoiceNo) throws Exception {

		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(LHN.class).clickEventView(); 
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		List<WebElement> paymentDatesCompleted;
		List<WebElement> paymentDates;
		paymentDatesCompleted=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Completed");
		paymentDates=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Incomplete");
	
		String frequency=testData.get("PaymentFrequency");
		String appDate=Context.local().getAppUtilityFunction().getApplicationDate();
		String invoiceDate;
		if(futureInvoiceNo.equals("First") )	
		{	
			if(Context.local().getAppUtilityFunction().getDateDifference(appDate, futureDuedates)>=30){
				invoiceDate=Context.local().getAppUtilityFunction().getNextWorkingDay(futureDuedates);
			}
			else
			{	
				DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		    	Date date1=dateFormat.parse(futureDuedates); 
				Date newDate=DateUtils.addMonths(date1, 1);
				String dueDate=dateFormat.format(newDate);
				invoiceDate=Context.local().getAppUtilityFunction().getNextWorkingDay(dueDate);
			}
		}
		else
		{
			invoiceDate=Context.local().getAppUtilityFunction().getNextWorkingDay(futureDuedates);
		}
		
		//paymentDatesCompleted = Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Completed");
		//List<WebElement> paymentDates = Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Incomplete");
		if(frequency.equals("12") && paymentDatesCompleted.size()==0 )
		{	
			for(int i=0;i<paymentDates.size();i++){

				if(paymentDates.get(i).getText().equals(invoiceDate))
				{
					Report.updateReport("PASS", "Invoice due date "+paymentDates.get(i).getText()+" is being displayed correctly on UI as "+invoiceDate+" with incomplete status ", "InvoicedPaymentsPage");
				}
				else
				{
					Report.updateReport("FAIL", "Incorrect invoice due date "+paymentDates.get(i).getText()+" is being displayed rather than "+invoiceDate+" ", "ErrorInvoicedPaymentsPage");
				}
			}
		}
		else
		{
			int j=	paymentDates.size();
			if(paymentDates.get(j-1).getText().equals(invoiceDate))
			{
				Report.updateReport("PASS", "Invoice due date "+paymentDates.get(j-1).getText()+" is being displayed correctly on UI as "+invoiceDate+" with incomplete status", "InvoicedPaymentsPage");
			}
			else
			{
				Report.updateReport("FAIL", "Incorrect invoice due date "+paymentDates.get(j-1).getText()+" is being displayed rather than "+invoiceDate+"", "ErrorInvoicedPaymentsPage");
			}
		}
		
		return invoiceDate;
	}	
	
	/**
	 * Functionality: Verification for due date
	 * @param test data,futureInvoiceDueDate
	 * @throws Exception
	 */

	public void verifyDueDate(LinkedHashMap<String, String> testData, String futureInvoiceDueDate) throws Exception {
		
		List<WebElement> paymentDates;
		paymentDates=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Incomplete");
		
		String invoiceDueDate;
		
		for(int i=0;i<paymentDates.size();i++){
			String dueDate=futureInvoiceDueDate.trim().substring(0,2);
			
				if(!(testData.get("InvoiceDate").equalsIgnoreCase("NA")))
				{
					invoiceDueDate=testData.get("InvoiceDate");
				}
				else
				{
					invoiceDueDate=Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).getInvoiceDate();
				}
				if(dueDate.equals(invoiceDueDate))
				{
					Report.updateReport("PASS", "Due date: "+invoiceDueDate+" is displayed correctly as per the date set during offer creation ", "InvoicedPaymentsPage");
					//paymentDates.get(i).click();
				}
				else if(!(dueDate.equals(invoiceDueDate)))
				{
					invoiceDueDate=invoiceDueDate+futureInvoiceDueDate.trim().substring(2,10);
					invoiceDueDate=Context.local().getAppUtilityFunction().getNextWorkingDay(invoiceDueDate);
					invoiceDueDate=invoiceDueDate.trim().substring(0,2);
					if(dueDate.equals(invoiceDueDate)){
						Report.updateReport("PASS", "Due date: "+invoiceDueDate+" is displayed correctly as per the date set during offer creation", "InvoicedPaymentsPage");
					}
				}
				else
				{
					Report.updateReport("FAIL", "Due date "+invoiceDueDate+" is not displayed correctly", "ErrorInvoicedPaymentsPage");
				}
			}
	}
	
	/**
	 * Functionality: Verification for due date post CC
	 * @param test data
	 * @throws Exception
	 */
	

public void verifyDueDatePostCC(LinkedHashMap<String, String> testData) throws Exception {
	
	Context.local().getPages().getPage(LHN.class).clickPolicy();
	Context.local().getPages().getPage(LHN.class).clickEventView();
	Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
	
	List<WebElement> paymentDates;
	paymentDates=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Incomplete");
	String invoiceDueDate;
	
	for(int i=0;i<paymentDates.size();i++){
		String dueDate=paymentDates.get(i).getText().trim().substring(0,2);
		
			if(!(testData.get("InvoiceDate").equalsIgnoreCase("NA")))
			{
				invoiceDueDate=testData.get("InvoiceDate");
			}
			else
			{
				invoiceDueDate=Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).getInvoiceDate();
			}
			if(dueDate.equals(invoiceDueDate))
			{
				Report.updateReport("PASS", "Due date: "+invoiceDueDate+" is displayed correctly for the newly generated invoice post change calculation", "InvoicedPaymentsPage");
				//paymentDates.get(i).click();
			}
			else if(!(dueDate.equals(invoiceDueDate)))
			{
				invoiceDueDate=invoiceDueDate+paymentDates.get(i).getText().trim().substring(2,10);
				invoiceDueDate=Context.local().getAppUtilityFunction().getNextWorkingDay(invoiceDueDate);
				invoiceDueDate=invoiceDueDate.trim().substring(0,2);
				if(dueDate.equals(invoiceDueDate)){
					Report.updateReport("PASS", "Due date: "+invoiceDueDate+" is displayed correctly for the newly generated invoice post change calculation ", "InvoicedPaymentsPage");
				}
			}
			else
			{
				Report.updateReport("FAIL", "Due date "+invoiceDueDate+" is not displayed correctly", "ErrorInvoicedPaymentsPage");
			}
		}
}

	/**
	 * Functionality: To pick dates with completed status prior to CC
	 * @param none
	 * @throws Exception
	 */

	
	public HashMap<String, String> pickdatesWithCompletedStatusPriorCC() throws Exception {
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(LHN.class).clickEventView();
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		List<WebElement> invoicingPeriodElements = Context.local().getPages().getPage(EventViewPage.class).fetchInvoicePeriodList();
		List<WebElement> paymentDatesStatusElements = Context.local().getPages().getPage(EventViewPage.class).fetchInvoiceStatusList();
		for(int i=0;i<invoicingPeriodElements.size();i++)
		{	
		periodsWithStatus.put(invoicingPeriodElements.get(i).getText(), paymentDatesStatusElements.get(i).getText()); 
		}
		
		return periodsWithStatus;
	}
	
	/**
	 * Functionality: Verify dates with status post CC
	 * @param dates,changeCalDate
	 * @throws Exception
	 */
	
	public void verifyDatesWithCompletedStatusPostCC(HashMap<String, String> dates,String changeCalDate) throws Exception {
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(LHN.class).clickEventView();
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		List<WebElement> invoicingPeriod =  Context.local().getPages().getPage(EventViewPage.class).fetchInvoicePeriodList();
		List<WebElement> paymentDatesStatusElements = Context.local().getPages().getPage(EventViewPage.class).fetchInvoiceStatusList();
		List<WebElement> paymentDatesElements= Context.local().getPages().getPage(EventViewPage.class).fetchEventDateList();
		Context.local().setPolicyUtilityFunction();
		String value;	
		String[] dateValues;
		String startDate;
		String endDate;
		for(int i=0;i<dates.size();i++){	
			value=invoicingPeriod.get(i).getText();
			value=value.replace("-", "   ");
			dateValues=value.split("   ");
			startDate=dateValues[0];
			endDate=dateValues[1];

			if(Context.local().getAppUtilityFunction().getDateDifference(changeCalDate, endDate)>=0 && Context.local().getAppUtilityFunction().getDateDifference(startDate, changeCalDate)>=0){
				if(dates.get(invoicingPeriod.get(i).getText()).equals("Completed")){
					if(paymentDatesStatusElements.get(i).getText().equals("Completed")){
						Report.updateReport("PASS", "Status of date  : "+paymentDatesElements.get(i).getText()+" is displayed correctly as  post change calculation ", "InvoicedPaymentsPage");
					}
					else
					{
						Report.updateReport("PASS", "Status of date  : "+paymentDatesElements.get(i).getText()+" is displayed incorrectly as post change calculation ", "InvoicedPaymentsPage");
					}

				}
			}//1nd condition
			if(Context.local().getAppUtilityFunction().getDateDifference(changeCalDate, endDate)>=0 && Context.local().getAppUtilityFunction().getDateDifference(startDate, changeCalDate)>=0){
				if(dates.get(invoicingPeriod.get(i).getText()).equals("Incomplete") || dates.get(invoicingPeriod.get(i).getText()).equals("Partially Paid") ){
					if(paymentDatesStatusElements.get(i).getText().equals("Cancelled")) {
						Report.updateReport("PASS", "Status of date  : "+paymentDatesElements.get(i).getText()+" is displayed correctly as cancelled", "InvoicedPaymentsPage");
					}
					else
					{
						Report.updateReport("PASS", "Status of date  : "+paymentDatesElements.get(i).getText()+" is displayed incorrectly  post change calculation ", "InvoicedPaymentsPage");
					}
				}
			}
			//2rd condition
			if(!(Context.local().getAppUtilityFunction().getDateDifference(changeCalDate, endDate)>=0 && Context.local().getAppUtilityFunction().getDateDifference(startDate, changeCalDate)>=0))
			{
				if(dates.get(invoicingPeriod.get(i).getText()).equals("Completed")){
					if(dates.get(invoicingPeriod.get(i).getText()).equals("Completed")){
						Report.updateReport("PASS", "Status of date  : "+paymentDatesElements.get(i).getText()+" is displayed correctly  post change calculation ", "InvoicedPaymentsPage");
					}
					else
					{
						Report.updateReport("PASS", "Status of date  : "+paymentDatesElements.get(i).getText()+" is displayed incorrectly  post change calculation ", "InvoicedPaymentsPage");
					}
				}
				else if(dates.get(invoicingPeriod.get(i).getText()).equals("Incomplete")){
					if((Context.local().getAppUtilityFunction().getDateDifference(changeCalDate, endDate)>=0 && Context.local().getAppUtilityFunction().getDateDifference(changeCalDate, startDate)>=0)){
						if(paymentDatesStatusElements.get(i).getText().equals("Cancelled")){
							Report.updateReport("PASS", "Status of date  : "+paymentDatesElements.get(i).getText()+" is displayed correctly post change calculation ", "InvoicedPaymentsPage");
						}
						else{
							Report.updateReport("PASS", "Status of date  : "+paymentDatesElements.get(i).getText()+" is displayed incorrectly as post change calculation ", "InvoicedPaymentsPage");
						}

					}

				}
				else{
					Report.updateReport("PASS", "Status of date  : "+paymentDatesElements.get(i).getText()+" is displayed incorrectly as post change calculation ", "InvoicedPaymentsPage");
				}
			}//3rd condition

		}


	}

	/**
	 * Functionality: Verify invoice period and amount post CC
	 * @param none
	 * @throws Exception
	 */

	public void verifyInvoicePeriodandInvoiceAmountPostCC() throws Exception {
		List<WebElement> invoicingPeriod=Context.local().getPages().getPage(EventViewPage.class).fetchInvoicePeriodWithIncompleteStatusList();
		List<String> invoicingPeriodValues = new ArrayList<String>();
		String value;
		for(int i=0;i<invoicingPeriod.size();i++)
		{
			value=invoicingPeriod.get(i).getText();
			value=value.replace("-", "   ");
			invoicingPeriodValues.add(value);		}
		List<WebElement> invoiceAmt=Context.local().getPages().getPage(EventViewPage.class).fetchAmtWithIncompleteStatusList();
		List<String> invoiceAmtValues = new ArrayList<String>();
		for(int i=0;i<invoiceAmt.size();i++)
		{
			invoiceAmtValues.add(invoiceAmt.get(i).getText());
		}
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(PaymentPlan.class).clickPaymentPlanTab();
		Context.local().getPages().getPage(PaymentPlan.class).clickUpdatedViewDetails();
		List<WebElement> invoicingPeriodOnPaymentPlan=Context.local().getPages().getPage(EventViewPage.class).fetchInvoicePeriodListPaymentPlanTab();
		List<String> invoicingPeriodOnPaymentPlanValues = new ArrayList<String>();
		for(int i=0;i<invoicingPeriodOnPaymentPlan.size();i++)
		{
			invoicingPeriodOnPaymentPlanValues.add(invoicingPeriodOnPaymentPlan.get(i).getText());
		}
		List<WebElement> invoiceAmtOnPaymentPlan=Context.local().getPages().getPage(EventViewPage.class).fetchInvoiceAmtListPaymentPlanTab();
		List<String> invoiceAmtOnPaymentPlanValues = new ArrayList<String>();
		for(int i=0;i<invoiceAmtOnPaymentPlan.size();i++)
		{
			invoiceAmtOnPaymentPlanValues.add(invoiceAmtOnPaymentPlan.get(i).getText());
		}
		for(int i=0;i<invoicingPeriod.size();i++){
			if(invoicingPeriodValues.get(i).equals(invoicingPeriodOnPaymentPlanValues.get(i)) && invoiceAmtValues.get(i).equals(invoiceAmtOnPaymentPlanValues.get(i)) )
			{
				Report.updateReport("PASS", "Invoice period and amount are being displayed corretly on view payments events csreen post change calculation", "InvoicedPaymentsPage");
			}
			else
			{
				Report.updateReport("FAIL", "Invoice period and amount are being displayed incorretly on view payments events csreen post change calculation", "ErrorInvoicedPaymentsPage");
			}
		}

	}
	
	/**
	 * Functionality: Code to fetch invoice date
	 * @param 
	 * @throws Exception
	 */
	
	public String fetchInvoiceDate() throws Exception {
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(LHN.class).clickEventView();
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		
		String futureInvoiceDates=Context.local().getAppUtilityFunction().fetchDataFromTable(Context.local().getPages().getPage(EventViewPage.class).fetchFutureInvoiceTable(), 1, "Due date");
		Context.local().getWorkflows().getWorkflow(ApplicationUtility.class).getPastDate(futureInvoiceDates,21);
		return futureInvoiceDates;
	}
	
	/**
	 * Functionality: Code to fetch invoice sequence
	 * @param testData
	 * @throws Exception
	 */
	
	public String fetchInvoiceSequence(LinkedHashMap<String, String> testData) throws Exception {
		
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(LHN.class).clickEventView();
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		List<WebElement> paymentDatesCompleted;
		List<WebElement> paymentDates;
		String invoice;
		paymentDatesCompleted=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Completed");
		paymentDates=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Incomplete");
		
		if(paymentDatesCompleted.size()==0 && paymentDates.size()==0)
		{
			invoice="First";
		}
		else
		{
			invoice="NotFirst";
		}
		 return invoice;
	}

    /**
     * Functionality: This method is used to fetch the cover premium amount with the corresponding pension cover
     * @param tableElement
     * @return
     * @throws Exception 
     */
    public HashMap<String, String> fetchPensionAmount(WebElement tableElement) throws Exception {
    	Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(tableElement, 5);
    	List<WebElement> coverList = tableElement.findElements(By.xpath("./tbody//a"));
    	HashMap<String, String> coverPremium = new HashMap<String, String>();
    	for(WebElement ele : coverList) {
    		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(ele, 5);
    		if(coverPremium.containsKey(ele.getText())) {
    			coverPremium.put(ele.getText() + "_" + ele.findElement(By.xpath("./../following-sibling::td[4]")).getText().trim(), 
    					ele.findElement(By.xpath("./../following-sibling::td[1]")).getText().trim());
    		}else {
    			coverPremium.put(ele.getText(), ele.findElement(By.xpath("./../following-sibling::td[1]")).getText().trim());
    		}
    	}
    	return coverPremium;
    }
    
	/**
	 * Method to be used for clicking on the needed content in table
	 * @param strBatchId
	 */
	public String fetchChangeCalcStatus(WebElement tableElement, String linkText) {
		tableElement.findElement(By.xpath("./tbody//a[text()='"+linkText+"']")).sendKeys("");
		return tableElement.findElement(By.xpath("./tbody//a[text()='"+linkText+"']")).findElement(By.xpath("./../following-sibling::td[2]")).getText();
	}
	
    /**
     * Description: This method is used to fetch the cover premium amount with the corresponding pension cover from policy cover tab
     * @param tableElement
     * @return
     * @throws Exception
     */
    public HashMap<String, String> fetchPnsnAmntPolicyCoverTab(WebElement tableElement) throws Exception {
    	Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(tableElement, 5);
    	List<WebElement> coverPremium = tableElement.findElements(By.xpath("./tbody//a"));
    	HashMap<String, String> coverList = new HashMap<String, String>();
    	int count=0;
    	int maxTry=3;
    	while(true) {
    		try {
		    	for(WebElement ele : coverPremium) {
		    		ele.findElement(By.xpath("./../preceding-sibling::td[1]")).sendKeys("");
		    		if(coverList.containsKey(ele.findElement(By.xpath("./../preceding-sibling::td[1]")).getText().trim())) {
		    			coverList.put(ele.findElement(By.xpath("./../preceding-sibling::td[1]")).getText().trim() + "_" + ele.findElement(By.xpath("./../following-sibling::td[1]")).getText().trim(),
		    					ele.getText().replaceAll("EUR|%", "").trim());
		    		}else {
		    			coverList.put(ele.findElement(By.xpath("./../preceding-sibling::td[1]")).getText().trim(),ele.getText().replaceAll("EUR|%", "").trim());
		    		}
		    	}
		    	return coverList;
    		}catch(StaleElementReferenceException e) {
    			if(++count<=maxTry){
    				logger.info(e);
    				throw e; 
    			}
    		}catch(WebDriverException e) {
    			if(++count<=maxTry){
    				logger.info(e);
    				throw e; 
    			}
    		}
    	}
    }
	
	/**
	 * Functionality: Code to verify start of  new payment plan on Payment plan page post CC
	 * @param testData
	 * @throws Exception
	 */
public void verifyPaymentPlanStartDate(LinkedHashMap<String, String> testData) throws Exception {
		
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(LHN.class).clickEventView();
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		List<WebElement> paymentDatesIncomplete;
		
		paymentDatesIncomplete=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Incomplete");
		
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(PaymentPlan.class).clickPaymentPlanTab();
		List<WebElement> paymentPlanStartDate=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentPlanStartDate();
		if(paymentDatesIncomplete.get(0).getText().equals(paymentPlanStartDate.get(0).getText()))
		{
			Report.updateReport("PASS", "Payment plan start date on view details screen should be same as the start date of the new invoice on view payments screen ", "InvoicedPaymentsPage");
		}
		else
		{
			Report.updateReport("PASS", "Payment plan start date on view details screen is incorrect ", "InvoicedPaymentsPage");
		}
	}


}
	
