package com.nordea.application.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.nordea.framework.Context;
import com.nordea.page.components.FooterSection;
import com.nordea.pages.ChangeCalculation;
import com.nordea.pages.CustomerPage;
import com.nordea.pages.DataSearchPage;
import com.nordea.pages.InsuranceClaimsPage;
import com.nordea.utility.LoadPropertiesUtil;
import com.nordea.utility.Report;

/**
 * @author z986911
 *
 */
public class ApplicationUtility {

	final static Logger logger = Logger.getLogger(ApplicationUtility.class);
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

	/**
	 * Method to be used for getting the todays date
	 * @return
	 */
	public String getCurrentDate() {
		return dateFormat.format(new Date());
	}

	/**
	 * Method to be used for renaming the downloaded file
	 * @param newFileName
	 */
	public void renameSavedFile(String newFileName) {
		File oldFile = new File(System.getProperty("user.dir")+ "\\src\\test\\resources\\saved-files\\Example.pdf");
		oldFile.renameTo(new File(System.getProperty("user.dir")+ "\\src\\test\\resources\\saved-files\\"+newFileName+".pdf"));
	}


	/**
	 * Functionality: This method to be used for validating the customer name, Customer Address,
	 * Policy ID, Product Name, Letter Content, Creation Date, Payment Value
	 * @param expectedContent
	 * @param pdfFileName
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	
	public void validatePdfContent(HashMap<String, String> expectedContent,
			String pdfFileName) throws FileNotFoundException, IOException {
		HashMap<String, String> pdfData = new HashMap<String, String>();
		pdfData = Context.local().getInvoiceLetterObject().getDataFromInvoiceLetter(System.getProperty("user.dir")+ "\\src\\test\\resources\\saved-files\\"+ pdfFileName + ".pdf");
		logger.info("******************************");
		logger.info("******************************");
		logger.info("******************************");
		logger.info("PDF Content to be verified are : " + pdfData);
		logger.info("******************************");
		logger.info("******************************");
		logger.info("******************************");
		logger.info("Values from UI :" + expectedContent);
		logger.info("******************************");
		logger.info("******************************");
		logger.info("******************************");

		if (Context.global().getSeleniumUtils().assertText(expectedContent.get("CustomerName"),pdfData.get("CustomerName"))) {
			Report.updatePDFReport("PASS", "Customer Name",
					expectedContent.get("CustomerName"),
					pdfData.get("CustomerName"));
		} else {
			Report.updatePDFReport("FAIL", "Customer Name",
					expectedContent.get("CustomerName"),
					pdfData.get("CustomerName"));
		}

		if (Context.global().getSeleniumUtils().assertText(expectedContent.get("CustomerAddress"),pdfData.get("CustomerAddress"))) {
			Report.updatePDFReport("PASS", "Customer Address",
					expectedContent.get("CustomerAddress"),
					pdfData.get("CustomerAddress"));
		} else {
			Report.updatePDFReport("FAIL", "Customer Address",
					expectedContent.get("CustomerAddress"),
					pdfData.get("CustomerAddress"));
		}

		if (Context.global().getSeleniumUtils().assertText(expectedContent.get("PolicyId"),pdfData.get("PolicyId"))) {
			Report.updatePDFReport("PASS", "Policy ID",
			expectedContent.get("PolicyId"), pdfData.get("PolicyId"));
		} else {
			Report.updatePDFReport("FAIL", "Policy ID",
			expectedContent.get("PolicyId"), pdfData.get("PolicyId"));
		}

		if (Context.global().getSeleniumUtils().assertText(expectedContent.get("ProductName"),pdfData.get("ProductName"))) {
			Report.updatePDFReport("PASS", "Product Name",
			expectedContent.get("ProductName"),
			pdfData.get("ProductName"));
		} 
		else {
			Report.updatePDFReport("FAIL", "Product Name",
			expectedContent.get("ProductName"),
			pdfData.get("ProductName"));
		}

		if (Context.global().getSeleniumUtils().assertText(expectedContent.get("LetterContent"),pdfData.get("LetterContent"))) {
			Report.updatePDFReport("PASS", "Letter Content",
			expectedContent.get("LetterContent"),
			pdfData.get("LetterContent"));
		} else {
			Report.updatePDFReport("FAIL", "Letter Content",
			expectedContent.get("LetterContent"),
			pdfData.get("LetterContent"));
		}

		if (Context.global().getSeleniumUtils().assertText(expectedContent.get("CreationDate"),pdfData.get("CreationDate"))) {
			Report.updatePDFReport("PASS", "Creation Date",
			expectedContent.get("CreationDate"),
			pdfData.get("CreationDate"));
		} else {
			Report.updatePDFReport("FAIL", "Creation Date",
			expectedContent.get("CreationDate"),
			pdfData.get("CreationDate"));
		}

		if (Context.global().getSeleniumUtils().assertText(expectedContent.get("PaymentValue"),pdfData.get("PaymentValue"))) {
			Report.updatePDFReport("PASS", "Payment Value",
			expectedContent.get("PaymentValue"),
			pdfData.get("PaymentValue"));
		} else {
			Report.updatePDFReport("FAIL", "Payment Value",
			expectedContent.get("PaymentValue"),
			pdfData.get("PaymentValue"));
		}
	}

	
	/**
	 * Functionality: Return list of Nordea Holidays
	 * @return List
	 * @throws Exception
	 */
	public List<String> getNordeaHolidayList() throws Exception
	{
		List <String> holidaylist = new ArrayList<String>();
		String[] strholiday = LoadPropertiesUtil.loadNordeaHoliday().get("NordeaHolidays").toString().split(",");
		for(int i=0;i<strholiday.length;i++){
			holidaylist.add(strholiday[i]);						
		}
		return holidaylist;
	}
	
	/**
	 * Functionality: Return future date in String format considering banking holidays 
	 * @return String
	 * @throws Exception
	 */
    public String getFutureDateConsideringBankHoliday(String currentdate,int futuredays) throws Exception{
    	DateFormat dateformat = new SimpleDateFormat("dd.MM.yyyy");
		Calendar calendar = new GregorianCalendar();
    	Date date = dateformat.parse(currentdate); 		
 	    calendar.setTime(date);
 	    Date resultDate = calendar.getTime();
 	    String newDate = dateformat.format(resultDate);
 	    boolean flag = true;
 	    
 	    for(int k=0;k<futuredays;k++){
			flag = true;
			calendar.add(Calendar.DATE, 1);
			while(flag){
				if(calendar.get(Calendar.DAY_OF_WEEK)==7){ 	    	
					Report.updateReport("Info",newDate+": is Saturday");
					calendar.add(Calendar.DATE, 2);
				}
				else if(calendar.get(Calendar.DAY_OF_WEEK)==1){
					Report.updateReport("Info",newDate+": is Sunday");
					calendar.add(Calendar.DATE, 1);
				}
				resultDate = calendar.getTime();	   
				
				newDate = dateformat.format(resultDate);
				logger.info("Next date:"+newDate);
				if(getNordeaHolidayList().contains(newDate)){
					Report.updateReport("Info",newDate+": is Nordea Holiday");
					calendar.add(Calendar.DATE, 1);
					resultDate = calendar.getTime(); 
					newDate = dateformat.format(resultDate);
				}
				else
				{
					flag = false;
				}
			}
 	    }
		resultDate = calendar.getTime();
	    newDate = dateformat.format(resultDate); 
        return newDate;
    }
 
    /**
	 * Functionality: Return back dated date in String format considering banking holidays 
	 * @return String
	 * @throws Exception
	 */
    public String getPastDateConsideringBankHoliday(String currentdate,int pastdays) throws Exception{
    	DateFormat dateformat = new SimpleDateFormat("dd.MM.yyyy");
		Calendar calendar = new GregorianCalendar();
    	Date date = dateformat.parse(currentdate); 		
 	    calendar.setTime(date);
 	    Date resultDate = calendar.getTime();
 	    String newDate = dateformat.format(resultDate);
 	    boolean flag = true;
 	    
 	    for(int k=0;k<pastdays;k++){
			flag = true;
			calendar.add(Calendar.DATE, -1);
			 resultDate = calendar.getTime();
		 	 newDate = dateformat.format(resultDate);
			while(flag){
				if(calendar.get(Calendar.DAY_OF_WEEK)==7){ 	    	
					Report.updateReport("Info",newDate+": is Saturday");
					calendar.add(Calendar.DATE, -2);
				}
				else if(calendar.get(Calendar.DAY_OF_WEEK)==1){
					Report.updateReport("Info",newDate+": is Sunday");
					calendar.add(Calendar.DATE, -1);
				}
				resultDate = calendar.getTime();	    
				newDate = dateformat.format(resultDate);
				System.out.println("Next date:"+newDate);
				if(getNordeaHolidayList().contains(newDate)){
					Report.updateReport("Info",newDate+": is Nordea Holiday");
					calendar.add(Calendar.DATE, -1);
					resultDate = calendar.getTime(); 
					newDate = dateformat.format(resultDate);
				}
				else
				{
					flag = false;
				}
			}
 	    }
		resultDate = calendar.getTime();
	    newDate = dateformat.format(resultDate); 
        return newDate;
    }
     
    /**
	 * Functionality: return current date if it is not a nordea holiday else return next working day in String format 
	 * @return String
	 * @throws Exception
	 */
    public String getNextWorkingDay(String currentdate) throws Exception{
    	DateFormat dateformat = new SimpleDateFormat("dd.MM.yyyy");
		Calendar calendar = new GregorianCalendar();
    	Date date = dateformat.parse(currentdate); 		
 	    calendar.setTime(date);
 	    Date resultDate = calendar.getTime();
 	    String newDate = dateformat.format(resultDate);
 	    boolean flag = true;
 	   {
			while(flag){
				if(calendar.get(Calendar.DAY_OF_WEEK)==7){ 	    	
					Report.updateReport("Info",newDate+": is Saturday");
					calendar.add(Calendar.DATE, 2);
				}
				else if(calendar.get(Calendar.DAY_OF_WEEK)==1){
					Report.updateReport("Info",newDate+": is Sunday");
					calendar.add(Calendar.DATE, 1);
				}
				resultDate = calendar.getTime();	    
				newDate = dateformat.format(resultDate);
				logger.info("Next date:"+newDate);
				if(getNordeaHolidayList().contains(newDate)){
					Report.updateReport("Info",newDate+": is Nordea Holiday");
					calendar.add(Calendar.DATE, 1);
					resultDate = calendar.getTime();
					newDate = dateformat.format(resultDate);
				}
				else
				{
					flag = false;
				}
			}
 	    }
		resultDate = calendar.getTime();
	    newDate = dateformat.format(resultDate); 
        return newDate;
    }
    
    /**
	 * Functionality: Return future date in String format without considering banking holidays
	 * @return String
	 * @throws Exception
	 */
    public String getFutureDate(String currentdate,int futuredays) throws Exception{
    	DateFormat dateformat = new SimpleDateFormat("dd.MM.yyyy");
		Calendar calendar = new GregorianCalendar();
    	Date date = dateformat.parse(currentdate); 		
 	    calendar.setTime(date);
 	    calendar.add(Calendar.DATE, futuredays);
 	    Date resultDate = calendar.getTime();
 	    String newDate = dateformat.format(resultDate);
 	    return newDate;
    }
    
    /**
  	 * Functionality: Return past date in String format without considering banking holidays
  	 * @return String
  	 * @throws Exception
  	 */
    public String getPastDate(String currentdate,int pastdays) throws Exception{
    	DateFormat dateformat = new SimpleDateFormat("dd.MM.yyyy");
		Calendar calendar = new GregorianCalendar();
    	Date date = dateformat.parse(currentdate); 		
 	    calendar.setTime(date);
 	    calendar.add(Calendar.DATE, -pastdays);
 	    Date resultDate = calendar.getTime();
 	    String newDate = dateformat.format(resultDate);
 	    System.out.println(newDate);
 	    return newDate;
    }

    /**
	 * Method to rename the file by appending the time stamp.
	 * @param File Path , File Name, New File Name.	 
	 * @return no return value /type
	 */
	public void renameFile(String filePath, String oldFileName)
	{	
		File oldFile = new File(filePath + File.separator + oldFileName); 
		if(oldFile.exists())
		{	
			oldFile.renameTo(new File(filePath + File.separator + oldFileName.split("\\.")[0] + new SimpleDateFormat("_dd-MM-yyyy_HH_mm_ss").format(new Date()) + "." + oldFileName.split("\\.")[1] ));
			logger.info("File rename to: " + filePath + File.separator + oldFileName.split("\\.")[0] + new SimpleDateFormat("_dd-MM-yyyy_HH_mm_ss").format(new Date()) + "." + oldFileName.split("\\.")[1]);
		}else
		{
			logger.info("File does not exist: " + filePath + File.separator + oldFileName);
		}
	}
	
	/**
	 * Method to copy the file and from source directory to destination directory
	 * @param Source File Path , Destination File Path, File Name 
	 * @return no return value /type
	 */
	public void copyFile(String srceFilePath, String destFilePath, String fileName) throws IOException

	{
		File srcFile = new File(srceFilePath + File.separator + fileName);
		File destFile = new File(destFilePath + File.separator + fileName);
		if(srcFile.exists())
		{
			if(destFile.exists())
			{
				renameFile(destFilePath, fileName);
				logger.info("Existing file in shared path with same file name is renamed");
				FileUtils.copyFile(srcFile, destFile);
				logger.info("File pasted successfully in given path" + destFilePath);
				Report.updateReport("INFO", "File pasted successfully in given path: " + destFilePath);
			}
			else
			{
				FileUtils.copyFile(srcFile, destFile);
				logger.info("File pasted successfully in given path" + destFilePath);
				Report.updateReport("INFO", "File pasted successfully in given path: " + destFilePath);
			}	
		}else
		{
			logger.info(fileName + " is not present in mentioned path: " +  srceFilePath);
			Report.updateReport("INFO", fileName + " is not present in mentioned path: " +  srceFilePath);
		}
		
		FileUtils.copyFile(srcFile, destFile);
	}
	
	 /**
	  * Functionality: Return application date and Time
	  * @return String
	  * @throws Exception
	  */
	public String getApplicationDateandTime() throws Exception{
		return Context.local().getPages().getPage(FooterSection.class).getApplicationDateandTime();
	}
	
	/**
	  * Functionality: Return application date
	  * @return String
	  * @throws Exception
	  */
    public String getApplicationDate() throws Exception{
    	return Context.local().getPages().getPage(FooterSection.class).getApplicationDate();
	}
    
    /**
	  * Functionality: Return application time
	  * @return String
	  * @throws Exception
	  */
    public String getApplicationTime() throws Exception{
    	return Context.local().getPages().getPage(FooterSection.class).getApplicationTime();
	}
    /**

	  * Functionality: Returns difference in days between two dates
	  * @return long
      * @throws ParseException 
	  * @throws Exception
	  */
    public long getDateDifference(String curAppDate,String futureDate) throws ParseException {
    	DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    	Date date1=dateFormat.parse(curAppDate); 
    	Date date2=dateFormat.parse(futureDate);
    	long diff=date2.getTime()-date1.getTime();
    	long diffDate=TimeUnit.DAYS.convert(diff,TimeUnit.MILLISECONDS);
    	System.out.println("Days:"+diffDate);
    	return diffDate;
    }
    /**

	  * Functionality: Returns difference in months between two dates
	  * @return int
      * @throws ParseException 
	 
	  */
    public int getMonthDifference(String startDate, String endDate) throws ParseException
    {
    	String strmonth1 = startDate.substring(3,5);
    	String strmonth2 = endDate.substring(3,5);
    	System.out.println(strmonth1);
    	System.out.println(strmonth2);
    	int month1 = Integer.parseInt(strmonth1);
    	int month2 = Integer.parseInt(strmonth2);
    	int diff = month2-month1;
    	System.out.println("****"+diff);
    	return diff;
    }
    	/**
    
	  * Functionality: Return any randomly picked IBAN number from Accounts.properties
	  * @return List
	  * @throws Exception
	  */
    public String getIBANNumber() throws FileNotFoundException, IOException
    {
    	String[] IBANList= Context.global().getLoadPropertiesUtil().fetchValueFromAccountPropsFile("IBANNumber").trim().split(",");		
		Random r = new Random();
		int index = r.nextInt(IBANList.length);
		logger.info(IBANList[index]);
		return IBANList[index];
	}
    /**
	  * Functionality: Add Account number to the customer if there is no account number present(from Customer Accounts tab)
	  * @return List
	  * @throws Exception
	  */
    
    
    public void verifyAddAccountNumber() throws Exception
    {
    	Context.local().getPages().getPage(DataSearchPage.class).clickCustomer();
    	Context.local().getPages().getPage(CustomerPage.class).navigateToAccountsTab();;
    
		if(Context.local().getPages().getPage(CustomerPage.class).fetchAccountNumber().equals(""))
		{
			Context.local().getPages().getPage(CustomerPage.class).clickAccountAdd();
			Context.local().getPages().getPage(CustomerPage.class).setIBAN(getIBANNumber());
			Context.local().getPages().getPage(CustomerPage.class).clickSave();
    	}
    }

    /**
	  * Functionality: For reading values from Tables
	  * @return String
	  * @throws Exception
	  * @author Nitesh Khanna, kapil Kapoor
	  */
    public String fetchDataFromTable(WebElement element, int rowNumber, String columnName) {
	List<WebElement> headerList = element.findElements(By.xpath("./thead/tr//th"));
	LinkedList<String> headerName = new LinkedList<String>();
	for(WebElement ele : headerList) {
		headerName.add(ele.getText());
	}
	int columnNumber = headerName.indexOf(columnName) + 1;
	return element.findElement(By.xpath("./tbody/tr["+rowNumber+"]/td["+columnNumber+"]")).getText().trim();
    } 
    /**
     * Functionality: Get any of the webElement in the table as per requirement with reference to heading
     * @param element
     * @param rowNumber
     * @param columnName
     * @author Nitesh Khanna, kapil Kapoor
     */
    public WebElement getDataFromTable(WebElement element, int rowNumber, String columnName) {
    	List<WebElement> headerList = element.findElements(By.xpath("./thead/tr//th"));
    	LinkedList<String> headerName = new LinkedList<String>();
    	for(WebElement ele : headerList) {
    		headerName.add(ele.getText());
}    	int columnNumber = headerName.indexOf(columnName) + 1;
    	return element.findElement(By.xpath("./tbody/tr["+rowNumber+"]/td["+columnNumber+"]"));
    }

    /**
     * Functionality: get any of the webElement in the table as per requirement with reference to column and row number
     * @param element
     * @param rowNumber
     * @param columnName
     * @author Nitesh Khanna, kapil Kapoor
     */
    public WebElement getDataFromTable(WebElement element, int rowNumber, int columnNumber) {
    	return element.findElement(By.xpath("./tbody/tr["+rowNumber+"]/td["+columnNumber+"]"));
    }
    
    /**
     * Functionality: click link of any of the webElement in the table 
     * @param tableElement
     * @param linkText
     * @author Nitesh Khanna, kapil Kapoor
     */
    public void clickOnLinkInTable(WebElement tableElement, String linkText) {
    	List<WebElement> coverList = tableElement.findElements(By.xpath("./tbody//a[contains(text(),'"+linkText+"')]"));
    	Context.global().getSeleniumUtils().clickOnElement(coverList.get(0), linkText);
    }
    
	/**
	 * Functionality: This method is used to compare the two maps.
	 * @param mapA
	 * @param mapB
	 * @return
	 * @author Nitesh Khanna, kapil Kapoor
	 */
	public boolean compareMapValues(HashMap<String, String> mapA,
			HashMap<String, String> mapB) {
			boolean flag = false;
			for (String key : mapB.keySet()) {
				if (!mapA.get(key).equals(mapB.get(key))) {
					Report.updateReport("INFO", "Cover amount before calculation: " + key + "=" + mapA.get(key) + 
							" " + "after calculation: " + key + "=" + mapB.get(key));
					flag = true;
				}
			}
			return flag;
	}
	
	/**
	 * Functionality: This method is used to check if error box is present on the screen or not.
	 * @return
	 * @throws Exception
	 * @author Nitesh Khanna, kapil Kapoor
	 */
	public boolean verifyErrorBoxIsDisplayed() throws Exception
	{
		if(Context.global().getSeleniumUtils().verifyElementPresent(Context.local().getPages().getPage(ChangeCalculation.class).getErrorBox(),"Error Box"))
		{
			logger.info("Error Box present on the screen: "+Context.local().getPages().getPage(ChangeCalculation.class).getErrorBoxMessage());
			Assert.fail("Error Box displayed with message '"+Context.local().getPages().getPage(ChangeCalculation.class).getErrorBoxMessage()+"'");
			return true;
		}
		else{
			logger.info("Error Box does not present on the screen");
			return false;
		}
	}
	
    public void deleteBeneficiaries() throws Exception{
		List<WebElement> list = Context.local().getPages().getPage(InsuranceClaimsPage.class).fetchBeneficiaries();
		for(int i=0;i<list.size();i++){
			list.get(i).click();
			Context.local().getPages().getPage(InsuranceClaimsPage.class).clickDelete();
			Context.local().getPages().getPage(InsuranceClaimsPage.class).clickRemoveBeneficiary();
			
		}
    }
    
    /**Description: This utility is to increase the given date with one month 
     * @param givenDate
     * @return date
     * @throws Exception
     * @author Nitesh Khanna, kapil Kapoor
     */
    public String increaseDateByMonth(String givenDate) throws Exception {
		SimpleDateFormat dateFrmt = new SimpleDateFormat("dd.MM.yyyy");
		Date date = new Date();
		date=dateFrmt.parse(givenDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, 1);
		try {
			date=dateFrmt.parse(cal.get(Calendar.DAY_OF_MONTH) + "."
			+ (cal.get(Calendar.MONTH) + 1) + "." + cal.get(Calendar.YEAR));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateFrmt.format(date);	
	}
    
}
