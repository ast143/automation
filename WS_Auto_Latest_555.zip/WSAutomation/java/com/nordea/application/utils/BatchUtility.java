package com.nordea.application.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.nordea.framework.Context;
import com.nordea.page.components.FooterSection;
import com.nordea.pages.BatchEntryLogPage;
import com.nordea.pages.DataSearchPage;
import com.nordea.pages.HomeWorkflow;
import com.nordea.utility.LoadPropertiesUtil;
import com.nordea.utility.Report;

public class BatchUtility {


	final static Logger logger = Logger.getLogger(ApplicationUtility.class);
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
	
	/**
	 * Method to be used for fetching the Batch ID
	 * @param batchComment
	 * @return
	 */
	public String fetchBatchID(String batchComment) {
		return batchComment.replaceAll("\\D", "");
	}

	/**
	 * Method to be used for clicking on the batch Link
	 * @param strBatchId
	 */
	public void clickBatchLink(String strBatchId) {
		List<WebElement> listRow = Context.global().getDriver().findElements(By.xpath("//table[@class='scrollTable']//tbody/tr/td[6]"));
			for (int i = listRow.size() - 1; i >= 0; i--) {
			if (listRow.get(i).getText().equalsIgnoreCase(strBatchId)) {
				Context.global().getSeleniumUtils().clickOnElement(listRow.get(i).findElement(By.xpath("//table[@class='scrollTable']//tbody/tr["+ (i + 1)+ "]//td[1]//a")),"Batch Link");
				break;
			}
		}
	}

	/**
	 * Method to be used for fetching the Batch Status 
	 * @param strBatchId
	 * @return
	 */
	public String fetchBatchStatus(String strBatchId) {
		String status = null;
		List<WebElement> listRow = Context.global().getDriver().findElements(By.xpath("//table[@class='scrollTable']//tbody/tr/td[6]"));
			for (int i = listRow.size() - 1; i >= 0; i--) {
			if (listRow.get(i).getText().equalsIgnoreCase(strBatchId)) {
				status = Context.global().getSeleniumUtils().getText(listRow.get(i).findElement(By.xpath("//table[@class='scrollTable']//tbody/tr["+ (i + 1)+ "]//td[5]")));
				break;
			}
		}
			return status;
	}
	
	
	/**
	 * Method to be used for checking if the periodical 
	 * already run for the last day of previous month or not
	 */	
	public boolean checkPeriodicalEventDate() throws Exception {
		String strDate = null;
		List<WebElement> listRow = Context.global().getDriver().findElements(By.xpath("//table[@class='scrollTable']//tbody/tr"));
		for (int count = 0; count < listRow.size(); count++) {
			if ("Periodical".equalsIgnoreCase(Context.global().getSeleniumUtils().getText(listRow.get(count).findElement(By.xpath("//table[@class='scrollTable']//tbody/tr["+ (count + 1)+ "]//td[2]")))))
			{
				strDate = Context.global().getSeleniumUtils().getText(listRow.get(count).findElement(By.xpath("//table[@class='scrollTable']//tbody/tr["+ (count + 1)+ "]//td[1]")));
				break;
			}
		}

		String preMonthLastDate = getPrvsMonthLastDate();		
		
		if (preMonthLastDate.equalsIgnoreCase(strDate)) {
		logger.info("Periodical Already executed for last month");
			return false;
		}
		return true;
	}

	/**
	 * Method to be used for fetching the last day of previous month
	 * @return
	 * @throws Exception
	 */
	public String getPrvsMonthLastDate() throws Exception {
		SimpleDateFormat f =new SimpleDateFormat("dd.MM.yyyy");
		Calendar cal = new GregorianCalendar();
        String dateString = Context.local().getPages().getPage(FooterSection.class).getApplicationDate(); 		
		Date d = f.parse(dateString); 		
 	    cal.setTime(d);
	try {
		d =	f.parse(cal.getActualMaximum(Calendar.DAY_OF_MONTH) + "."
				+ (cal.get(Calendar.MONTH) + 1) + "." + cal.get(Calendar.YEAR));
	} catch (ParseException e) {
		e.printStackTrace();
	}
	return f.format(d);
		
	}
	
	/**
	 * Method to be used for fetching the 
	 * last day of current month
	 * @return
	 * @throws Exception
	 */
	public String getCurrentMonthLastDate() throws Exception {
		SimpleDateFormat dateFrmt = new SimpleDateFormat("dd.MM.yyyy");
		Date applicationDate = new Date();
		String appDate = Context.local().getPages().getPage(FooterSection.class).getApplicationDate();
		applicationDate=dateFrmt.parse(appDate);
		logger.info("Application date : " + dateFrmt.format(applicationDate));
		Calendar cal = Calendar.getInstance();
		cal.setTime(applicationDate);
		cal.add(Calendar.MONTH, 0);
			try {
		applicationDate=	dateFrmt.parse(cal.getActualMaximum(Calendar.DAY_OF_MONTH) + "."
				+ (cal.get(Calendar.MONTH) + 1) + "." + cal.get(Calendar.YEAR));
			} catch (ParseException e) {
		logger.info(e.getMessage());
			}
	return dateFrmt.format(applicationDate);
		
	}
	/**
	   * Validate Periodical Event Report- verify if it contains Policy ID and update the report with proper result.
	   * @param url
	   * @throws Exception
	   */
  public void verifyPeriodicalEventReport(String strPolicy) throws IOException,NoSuchElementException {
		logger.info("Event report verification started ");
		logger.info(Context.global().getDriver().findElement(By.xpath("/PeriodicalEvent-Report/ProductClassifications/ProductClassification/PolicyDetails/PolicyElements/Policy/PolicyNumber")).getText().trim());
		if(Context.global().getDriver().findElement(By.xpath("/PeriodicalEvent-Report/ProductClassifications/ProductClassification/PolicyDetails/PolicyElements/Policy/PolicyNumber")).getText().trim().contains(strPolicy)){
		    Report.updateReport("INFO", "Policy Number : " + Context.global().getDriver().findElement(By.xpath("/PeriodicalEvent-Report/ProductClassifications/ProductClassification/PolicyDetails/PolicyElements/Policy/PolicyNumber")).getText() + " exist in event Report");
		}
		else{
			logger.info("Policy ID does not match");
			Report.updateReport("FAIL","Policy ID does not match");
		}
	}

	/**
	   * Validate Periodical Event Report- NLFI1458
	   * @param url
	   * @throws Exception
	   */
  public void verifyPeriodicalEventReportForRange() throws IOException,Exception {
		logger.info("Event report verification started ");
		try{
			Report.updateReport("INFO", "<style>.comments{width: 100; height: 150px}</style><textarea style=\"font-weight: bold\" class=\"comments\">" + Context.global().getDataFromXML().getEventReportDetails(Context.global().getDriver().getPageSource()) + "</textarea>");
		}
		catch(Exception e)
		{
		logger.info("No policy Numbers found in the Event report");
		}
	}

	/**
	    * Validate Periodical Error Report- verify if it contains Policy ID and update the report with proper result.
	    * @param url
	    * @throws Exception
	    */
 public void verifyPeriodicalErrorReport(String url) throws Exception {
	try{
	logger.info(Context.global().getDriver().findElement(By.xpath("/PeriodicalError-Report/Errors/Error")).getText());
	Report.updateReport("INFO","<style>.comments{width: 100; height: 150px}</style><textarea style=\"font-weight: bold\" class=\"comments\">" + Context.global().getDriver().findElement(By.xpath("/PeriodicalError-Report/Errors/Error")).getText() + "</textarea>");
	Context.global().getDriver().get(url);
	Thread.sleep(1000);
	Context.local().getPages().getPage(BatchEntryLogPage.class).clickHTMLRadioButton();
	Thread.sleep(1000);
	Context.local().getPages().getPage(BatchEntryLogPage.class).clickErrorReportPrint();
	Thread.sleep(2000);
	Report.updateReport("INFO", "Error Report", "error_report");
	} 
	catch(Exception e)
	{
	logger.info(" Policy ID does not exist in Error Report");
	Context.global().getDriver().get(url);
	Thread.sleep(1000);
	Context.local().getPages().getPage(BatchEntryLogPage.class).clickHTMLRadioButton();
	Thread.sleep(1000);
	Context.local().getPages().getPage(BatchEntryLogPage.class).clickErrorReportPrint();
	Thread.sleep(2000);
	Report.updateReport("INFO", "Error Report", "error_report");
	Report.updateReport("INFO", "Policy is not picked in Error Report");
	}
 } 
 
	/**
  * Validate Periodical Error Report
  * @param url
  * @throws Exception
  */
 public void verifyPeriodicalErrorReportForRange(String url) throws Exception {
	   try{
		   logger.info(Context.global().getDriver().findElement(By.xpath("/PeriodicalError-Report/Errors")).getText());
		   Report.updateReport("INFO","<style>.comments{width: 100; height: 150px}</style><textarea style=\"font-weight: bold\" class=\"comments\">" + Context.global().getDataFromXML().getErrorReportDetails(Context.global().getDriver().getPageSource()) + "</textarea>");
		   Context.global().getDriver().get(url);
		   Thread.sleep(1000);
		   Context.local().getPages().getPage(BatchEntryLogPage.class).clickHTMLRadioButton();
		   Thread.sleep(1000);
		   Context.local().getPages().getPage(BatchEntryLogPage.class).clickErrorReportPrint();
		   Thread.sleep(2000);
		   Report.updateReport("INFO", "Error Report", "error_report");
	   } 
	   catch(Exception e)
	   {
		   logger.info(" Policy ID does not exist in Error Report");
		   Context.global().getDriver().get(url);
		   Thread.sleep(1000);
		   Context.local().getPages().getPage(BatchEntryLogPage.class).clickHTMLRadioButton();
		   Thread.sleep(1000);
		   Context.local().getPages().getPage(BatchEntryLogPage.class).clickErrorReportPrint();
		   Thread.sleep(2000);
		   Report.updateReport("INFO", "Error Report", "error_report");
		   Report.updateReport("INFO", "Policy is not picked in Error Report");
	   }
}
 
 /**
  * Validate Linking Event Report- verify if it contains Policy ID and update the report with proper result.
  * @param url
  * @throws Exception
  */
 public void verifyLinkingEventReport(String strPolicy) throws IOException,NoSuchElementException {
		logger.info("Event report verification started ");
		logger.info(Context.global().getDriver().findElement(By.xpath("/LinkingEvent-Report/Events/Event/Policy")).getText().trim());
		if(Context.global().getDriver().findElement(By.xpath("/LinkingEvent-Report/Events/Event/Policy")).getText().trim().contains(strPolicy)){
			Report.updateReport("PASS", "Policy Number : "+Context.global().getDriver().findElement(By.xpath("/LinkingEvent-Report/Events/Event/Policy")).getText() + " exist in event Report");
		   }
		else{
			logger.info("Policy ID does not match");
			Report.updateReport("FAIL", "Policy ID does not match");
		}
	}
 
 /**
  * Validate Linking Error Report- verify if it contains Policy ID and update the report with proper result.
  * @param url
  * @throws Exception
  */
 public void verifyLinkingErrorReport(String url) throws Exception {
		try{
		logger.info(Context.global().getDriver().findElement(By.xpath("/LinkingError-Report/Errors/Error")).getText());
		Report.updateReport("INFO","<style>.comments{width: 100; height: 150px}</style><textarea class=\"comments\">" + Context.global().getDriver().findElement(By.xpath("/LinkingError-Report/Errors/Error")).getText() + "</textarea>");
		Context.global().getDriver().get(url);
		Thread.sleep(1000);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickHTMLRadioButton();
		Thread.sleep(1000);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickErrorReportPrint();
		Thread.sleep(2000);
		Report.updateReport("INFO", "Error Report", "error_report");
		} 
		catch(Exception e)
		{
		logger.info(" Policy ID does not exist in Error Report");
		Context.global().getDriver().get(url);
		Thread.sleep(1000);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickHTMLRadioButton();
		Thread.sleep(1000);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickErrorReportPrint();
		Thread.sleep(2000);
		Report.updateReport("INFO", "Error Report", "error_report");
		Report.updateReport("INFO", "Policy is not picked in Error Report");
		}
	} 
 
	/**
	 * Method to read the file and get the total number of Work Done count for policies
	 * @param File Path , File Name 
	 * @return sum is returned (int) 
	 */
	public int totalPoliciesInTulseFile(String filePath, String fileName) throws IOException
	{
		BufferedReader bufferReader = null;
		FileReader fileReaderr = null;
		Pattern p = Pattern.compile("TULOSTETTU");
		int sum =0;
		try { 
			fileReaderr = new FileReader(filePath + File.separator + fileName);
			bufferReader = new BufferedReader(fileReaderr);
			String sCurrentLine;
			
			while((sCurrentLine=bufferReader.readLine()) !=null)
			{
				Matcher m = p.matcher(sCurrentLine);
				while(m.find()) {
					sum +=Integer.parseInt(sCurrentLine.replaceAll("[^0-9]", ""));
				}
			}
		}catch(IOException e)
		{
			e.printStackTrace();
		}finally
		{
			if(bufferReader!=null){
				bufferReader.close();
			}
			if(fileReaderr!=null)
			{ fileReaderr.close();
			}
		}
		return sum;
	}

	/**
	 * Method to read the file and fetch total and consolidated error report
	 * @param Null
	 * @return  int Count 
	 */
	public int getUniqueErrorLines() throws IOException {
		Map<String, String> map = new HashMap<String, String>();
		String line = "";
		BufferedReader brf = new BufferedReader(new FileReader(new File(LoadPropertiesUtil.configProps.getProperty("Tulse_Batch_FilePath") + File.separator + LoadPropertiesUtil.configProps.getProperty("Periodical_Events_New_Batch_File_Name"))));
		BufferedWriter wrf = new BufferedWriter(new FileWriter(new File(LoadPropertiesUtil.configProps.getProperty("Shared_Reports_Repository") + "errorFile"+ new SimpleDateFormat("_dd-MM-yyyy").format(new Date())  +".txt")));
		Pattern ptr = Pattern.compile("^\\s[0-9]{9}");
		int actualCount = 0;
		
		while((line=brf.readLine()) != null) {
			if(line.contains("TAPAHTUMAA")) {
				line = line.replaceAll("\\D+", "");
				actualCount = Integer.parseInt(line);
				break;
			}
			Matcher mtr = ptr.matcher(line);
			while(mtr.find()) {
				wrf.write(line + "\n");
				if(!line.contains(".")) {
					line = line.replaceAll("\\s+", "#");
					String arr[] = line.split("#");
					if(!map.containsKey(arr[arr.length-1])) {
						map.put(arr[arr.length-1], arr[1]);
					} else {
						map.put(arr[arr.length-1], map.get(arr[arr.length-1])+","+arr[1]);
					}
				}else {
					line = line.replaceAll("\\.", "#");
					String arr[] = line.split("#");
					String text = arr[0].replaceAll("\\s+", ":");
					String keyarr[] = text.split(":");
					String key = keyarr[keyarr.length-1] + "." + arr[1].replaceAll("\\d+ | (\\d+)-(\\d+)\\w","#").trim();
					if(!map.containsKey(key)) {
						map.put(key, keyarr[1]);
					} else {
						map.put(key, map.get(key)+","+keyarr[1]);
					}
				}
			}
		}
		
		int total=0;
		String consolidatedErrors= "";
		Iterator<?> itr = map.entrySet().iterator();
		Report.updateReport("INFO", "<b>Consolidated Errors In Report :</b>");
		while(itr.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = (Map.Entry) itr.next();
			logger.info(pair.getKey() + " = " + pair.getValue().toString().split(",").length);
			total = total + pair.getValue().toString().split(",").length;
			consolidatedErrors +=  pair.getKey() + " = " + pair.getValue().toString().split(",").length + "\n"; 
		}
		
		consolidatedErrors += "Other Errors = " + (actualCount-total) + "\n";
		logger.info("Other Errors = " + (actualCount-total));
		Report.updateReport("INFO","<style>.comments{width: 100; height: 150px}</style><textarea class=\"comments\" style=\"font-weight: bold\">" + consolidatedErrors + "</textarea>");
		logger.info("=================================");
		logger.info("Total Number of Errors = " + total);
		logger.info("=================================");
		wrf.write("=================================" + "\n");
		wrf.write(consolidatedErrors + "\n");
		wrf.write("=================================" + "\n");
		wrf.write("Total Number of Errors = " + total + "\n");
		wrf.write("=================================" + "\n");
		Report.updateReport("INFO", "<b>Total number of policies in error report : <b>" + total);
		wrf.close();
		brf.close();
		return total;
	}
	
	/**
 	 * Method to be used for waiting for batch to complete (maximum wait 3 minutes)
 	 * @param Batch Name
 	 * @throws Exception
 	 * @author Nitesh Khanna, Kapil Kapoor
 	 */
 	public void waitForBatchCompletion(String batchName, String batchId) throws Exception{
 		
 		logger.info("Waiting for "+batchName+" to complete");
 		Context.local().getPages().getPage(DataSearchPage.class).clickHomeWorkFlow();
		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
		Context.local().getPages().getPage(HomeWorkflow.class).clickBatchEntryLog();
		Context.local().getPages().getPage(BatchEntryLogPage.class).selectBatchToRun(batchName);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		Thread.sleep(10000);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		Report.updateReport("INFO","Batch ID :" + batchId);
		int i;
		for(i = 150; i>=0; i--) {
			Thread.sleep(10000);
			if("Completed".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(batchId)) || "Interrupted".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(batchId))) {
				break;
			}
			Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		}
		if(i<0){
			logger.info("Batch status still Incomplete after 3 mintues");
		}
 	}
 	
 	/**
 	 * Method to be used to navigate till EventReport.xml
 	 * @param Batch id
 	 * @throws Exception
 	 * @author Nitesh Khanna, Kapil Kapoor
 	 */
 	public void navigateToXmlEventReport(String batchId) throws Exception{
 		Context.local().getBatchUtilityFunction().clickBatchLink(batchId);
		Thread.sleep(10000);
		String url= Context.global().getDriver().getCurrentUrl();
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickEventReportPrint();
		Thread.sleep(10000);
		Report.updateReport("INFO", "Event Report", "event_report");
		Context.global().getDriver().navigate().to(url);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickXMLRadioButton();
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickEventReportPrint();
		Thread.sleep(5000);
		logger.info("Control switched to Event Report");
 	}
 	
 	/**
 	 * Method to be used to navigate till EventReport.xml for Vasteri Asteri Connection Batch
 	 * @param Batch id
 	 * @throws Exception
 	 */
 	public void navigateToVasteriAsteriConnXmlEventReport(String batchId) throws Exception{
 		Context.local().getBatchUtilityFunction().clickBatchLink(batchId);
		Thread.sleep(10000);
		String url= Context.global().getDriver().getCurrentUrl();
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickVasteriAsteriConnEventReportPrint();
		Thread.sleep(10000);
		Report.updateReport("INFO", "Event Report", "event_report");
		Context.global().getDriver().navigate().to(url);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickXMLRadioButton();
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickVasteriAsteriConnEventReportPrint();
		Thread.sleep(5000);
		logger.info("Control switched to Event Report");
 	}

 	/**
 	  * Validate Vasteri Asteri Connection Event Report- verify if it contains Policy ID and update the report with proper result.
 	  * @param url
 	  * @throws Exception
 	  */
 	 public void verifyVasteriAsteriConnectionEventReport(String strPolicy) throws IOException,NoSuchElementException {
 			logger.info("Event report verification started ");
 			logger.info(Context.global().getDriver().findElement(By.xpath("/LinkingEvent-Report/Events/Event/Policy")).getText().trim());
 			if(Context.global().getDriver().findElement(By.xpath("/LinkingEvent-Report/Events/Event/Policy")).getText().trim().contains(strPolicy)){
 				Report.updateReport("PASS", "Policy Number : "+Context.global().getDriver().findElement(By.xpath("/LinkingEvent-Report/Events/Event/Policy")).getText() + " exist in event Report");
 			   }
 			else{
 				logger.info("Policy ID does not match");
 				Report.updateReport("FAIL", "Policy ID does not match");
 			}
 		}
 	
}
