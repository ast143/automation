package com.nordea.application.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Properties;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.io.RandomAccessFile;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class InvoiceLetterVerification {

	private PDFTextStripper pdfStripper = null;
	private PDDocument pdDoc = null;
	private COSDocument cosDoc = null;
	private int index = 0;

	public String[] getPdfDataByLine(String strPdfFilePath) {
		File pdfFile = new File(strPdfFilePath);
		String txtArr[] = null;

		try {
			PDFParser parser = new PDFParser(new RandomAccessFile(pdfFile, "r"));
			parser.parse();
			cosDoc = parser.getDocument();
			pdfStripper = new PDFTextStripper();
			pdfStripper.setSortByPosition(true);
			pdDoc = new PDDocument(cosDoc);

			String text = pdfStripper.getText(pdDoc);
			txtArr = text.split("\n");
		} catch (IOException e) {
			e.printStackTrace();
		}

		return txtArr;
	}

	public String getSectionData(String[] txtArr, int index, String strHeader) {
		String str = "";
		for (int count = index + 1; count < txtArr.length; count++) {
			if (txtArr[count].contains(strHeader)) {
				this.index = count;
				break;
			} else {
				str = str + txtArr[count];
			}
		}
		return str;
	}

	public String getSectionDataWithSeperator(String[] txtArr, int index,
			String strHeader) {
		String str = "";
		for (int count = index + 1; count < txtArr.length; count++) {
			if (txtArr[count].contains(strHeader)) {
				this.index = count;
				break;
			} else {
				str = str + txtArr[count] + "#";
			}
		}
		return str;
	}

	public LinkedHashMap<String, String> getDataFromInvoiceLetter(
			String strPdfFilePath) throws FileNotFoundException, IOException {
		String txtArr[] = getPdfDataByLine(strPdfFilePath);
		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

		// Fetch Data from Top Left Section
		map.put("TopLeftHeader", txtArr[0].replaceAll("[\\W0-9]+", " ").trim());
		map.put("ProductName", txtArr[1].trim());
		map.put("PolicyId", txtArr[2].split(" ")[1].trim());
		map.put("CreationDate", txtArr[3].trim());
		map.put("CustomerNameInAddress", txtArr[4].trim());

		index = 0;
		String str = "";

		if (map.get("TopLeftHeader").equalsIgnoreCase("Maksu")) {
			// Fetch Address Data
			for (int count = 5; count < txtArr.length; count++) {
				if (txtArr[count].contains("Omistaja:")) {
					index = count;
					break;
				} else {
					str = str + txtArr[count];
				}
			}
			map.put("CustomerAddress", str.replaceAll("\\*\\d{4}", " ").replaceAll("\\s+", " ").trim()); // "[\\W\\s]+" x.replaceAll("\\*\\d{4}", " ").replaceAll("\\s+", " ").trim()
		} else {
			for (int count = 5; count < txtArr.length; count++) {
				if (txtArr[count].contains("�gare:")) {
					index = count;
					break;
				} else {
					str = str + txtArr[count];
				}
			}
			map.put("CustomerAddress", str.replaceAll("\\*\\d{4}", " ").replaceAll("\\s+", " ").trim());
		}

		// Fetch Customer Name
		String arr[] = txtArr[index].split(" ");
		str = "";
		for (int count = 1; count < arr.length; count++) {
			str = str + arr[count] + " ";
		}
		map.put("CustomerName", str.trim());

		// Fetch Customer content section
		str = getSectionData(txtArr, index, "FI91 2478 1800 0000 41");
		// adding to get the data from standard chapters properties file
		map.put("LetterContent", str.replaceAll("\\s+", " ").trim());

		// Fetch Payment value
		map.put("PaymentValue", txtArr[index + 4].split(":")[1].trim());

		return map;
	}

	public String createInvoiceContentUsingIdentifiers(String LetterType)
			throws FileNotFoundException, IOException {
		Properties prop = new Properties();
		if (LetterType.equals("Finnish")) {
			prop.load(new FileInputStream(
					System.getProperty("user.dir")+"\\src\\main\\resources\\invoicechapter\\finnishinvoice.properties")); // Va;idation
																				// only
																				// for
																				// finnishinvoice.properties
			return prop.get("txtDearCustomer_14.12.2011 - 31.12.2099")
					+ " "
					+ prop.get("txtPayment1_01.03.2015 - 31.12.9999")
					+ " "
					+ prop.get("txtMessagesInLetter_01.03.2015 - 31.12.9999")
					+ " "
					+ prop.get("txtContactInfo_01.03.2015 - 31.12.9999")
					+ " "
					+ prop.get("txtFriendlyCr_04.06.2012 - 31.12.2099")
					+ " "
					+ prop.getProperty("txtNordeaLifeInsC_28.08.2007 - 31.12.2099");
		} else {
			prop.load(new FileInputStream(
					System.getProperty("user.dir")+"\\src\\main\\resources\\invoicechapter\\swedishinvoice.properties"));
			return prop.get("txtDearCustomer_14.12.2011 - 31.12.2099")
					+ " "
					+ prop.get("txtPayment1_01.03.2015 - 31.12.9999")
					+ " "
					+ prop.get("txtMessagesInLetter_01.03.2015 - 31.12.9999")
					+ " "
					+ prop.get("txtContactInfo_01.03.2015 - 31.12.9999")
					+ " "
					+ prop.get("txtFriendlyCr_04.06.2012 - 31.12.2099")
					+ " "
					+ prop.getProperty("txtNordeaLifeInsC_28.08.2007 - 31.12.2099");
		}
	}

	public String PDFContentValidation(String ContentFromPDF,
			String ContentFromUI) {
		if (ContentFromPDF.equalsIgnoreCase(
				ContentFromUI)) {
			System.out.println("Passed");
			return "Pass";
		} else {
			System.out.println("Failed");
			return "Fail";
		}

	}
	
//	public static void main(String args[]) throws FileNotFoundException,
//			IOException {
//		InvoiceLetterVerification obj = new InvoiceLetterVerification();
//		LinkedHashMap<String, String> map = obj
//				.getDataFromInvoiceLetter("C:\\Users\\z050302\\Desktop\\Product-58\\58.pdf");
//		System.out.println("TopLeftHeader : " + map.get("TopLeftHeader"));
//		System.out.println("Policy ID : " + map.get("PolicyId"));
//		System.out.println("Creation Date : " + map.get("CreationDate"));
//		System.out.println("Customer Name as mentioned in Address: "
//				+ map.get("CustomerNameInAddress"));
//		System.out.println("Customer Address : " + map.get("CustomerAddress"));
//		System.out.println("Customer Name : " + map.get("CustomerName"));
//		System.out.println("Letter Content : " + map.get("LetterContent"));
//		System.out.println("Payment Value : " + map.get("PaymentValue"));
//		String str = obj.createInvoiceContentUsingIdentifiers("Finnish");
//		System.out.println("*************************************");
//		System.out.println(str);
//		System.out.println("*************************************");
//		System.out.println(map.get("LetterContent").equals(str));
//	}

}