package com.nordea.framework;

/** 
 * Description: local- Objects related to application utility, workflow and pages are provided by local class
 * 
 * Functionality Created By  	: Nitesh Khanna
 * Reviewed By                 	: Deb Behera
 * 
 */
import com.nordea.application.utils.ApplicationUtility;
import com.nordea.application.utils.BatchUtility;
import com.nordea.application.utils.InvoiceLetterVerification;
import com.nordea.application.utils.OfferUtility;
import com.nordea.application.utils.PolicyUtility;
import com.nordea.pages.PageObject;
import com.nordea.workflow.Workflow;

public class Local {

	private ApplicationUtility utility;
	private OfferUtility offerutility;
	private BatchUtility batchutility;
	private PolicyUtility policyutility;
	static private Local local;
	private InvoiceLetterVerification invoice;

	private ThreadLocal<PageObject> pageObj = new ThreadLocal<PageObject>() {
			@Override
			protected PageObject initialValue() {
				return new PageObject();
		}
	};
	private ThreadLocal<Workflow> workflow = new ThreadLocal<Workflow>() {
			@Override
			protected Workflow initialValue() {
				return new Workflow();
		}
	}; 

	static Local getLocal() {
		if (local == null) {
			local = new Local();
		}
		return local;
	}

	public ApplicationUtility getAppUtilityFunction() {
		if (utility == null) {
			setAppUtilityFunction();
		}
		return utility;
	}

	private void setAppUtilityFunction() {
		this.utility = new ApplicationUtility();
	}
	
	public BatchUtility getBatchUtilityFunction() {
		if (batchutility == null) {
			setBatchUtilityFunction();
		}
		return batchutility;
	}

	private void setBatchUtilityFunction() {
		this.batchutility = new BatchUtility();
	}
	
	public OfferUtility getOfferUtilityFunction() {
		if (offerutility == null) {
			setOfferUtilityFunction();
		}
		return offerutility;
	}
	private void setOfferUtilityFunction() {
		this.offerutility = new OfferUtility();
	}
	
	
	public PolicyUtility getPolicyUtilityFunction() {
		if (policyutility == null) {
			setPolicyUtilityFunction();
		}
		return policyutility;
	}
	public void setPolicyUtilityFunction() {
		this.policyutility = new PolicyUtility();
	}

	

	public PageObject getPages() {
		if (pageObj == null) {
			setPages();
		}
		return pageObj.get();
	}

	public void setPages() {
		this.pageObj.set(new PageObject());
	}

	public Workflow getWorkflows() {
		if (workflow == null) {
			setWorkflows();
		}
		return workflow.get();
	}

	public void setWorkflows() {
		this.workflow.set(new Workflow());
	}

	public InvoiceLetterVerification getInvoiceLetterObject() {
		if (invoice == null) {
			setInvoiceLetterObject();
		}
		return invoice;
	}

	public void setInvoiceLetterObject() {
		this.invoice = new InvoiceLetterVerification();
	}

}