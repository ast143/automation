package com.nordea.framework;

/** 
 * Description: Global- Objects related to framework are provided by global class
 * 
 * Functionality Created By  	: Nitesh Khanna
 * Reviewed By                 	: Deb Behera
 * 
 */
import java.io.IOException;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.nordea.utility.FetchDataFromXml;
import com.nordea.utility.FetchDataSetFromExcel;
import com.nordea.utility.FileDownloader;
import com.nordea.utility.LoadPropertiesUtil;
import com.nordea.utility.SeleniumUtils;

public class Global {
	static private Global glb;
	private FileDownloader fileDownload;
	private SeleniumUtils seleniumUtil;
	private LoadPropertiesUtil properties; 
	private ThreadLocal<FetchDataFromXml> fetchXMLDataSet = new ThreadLocal<FetchDataFromXml>() {
		@Override
		protected FetchDataFromXml initialValue() {
			return new FetchDataFromXml();
		}
	};
	private ThreadLocal<RemoteWebDriver> webDriver = new ThreadLocal<RemoteWebDriver>();
	private ThreadLocal<FetchDataSetFromExcel> fetchDataSet = new ThreadLocal<FetchDataSetFromExcel>() {
		@Override
		protected FetchDataSetFromExcel initialValue() {
			return new FetchDataSetFromExcel();
		}
	};

	private ThreadLocal<String> sessionFolderPath = new ThreadLocal<String>(){
		@Override
		protected String initialValue() {
			return System.getProperty("user.dir") + "\\temp";
		}
	};
	private long expectedWaitTime = 50;
	

	static Global getGlobal() {
		if (glb == null) {
			glb = new Global();
		}
		return glb;
	}

	public RemoteWebDriver getDriver() {
		return webDriver.get();
	}

	public synchronized void setDriver(RemoteWebDriver driver) {
		this.webDriver.set(driver);
	}

	public long getExpectedWaitTime() {
		return expectedWaitTime;
	}

	public void setExpectedWaitTime(long waitTimeInSec) {
		this.expectedWaitTime = waitTimeInSec;
	}

	public void closeChromeDriver() throws IOException {
		Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
	}

	public SeleniumUtils getSeleniumUtils() {
		if (seleniumUtil == null) {
			setKeywords();
		}
		return seleniumUtil;
	}

	private void setKeywords() {
		this.seleniumUtil = new SeleniumUtils();
	}

	public FetchDataSetFromExcel getDataSet() {
		if (fetchDataSet == null) {
			setDataSet();
		}
		return fetchDataSet.get();
	}

	public void setDataSet() {
		this.fetchDataSet.set(new FetchDataSetFromExcel());
	}

	public String getSessionFolderPath() {
		return sessionFolderPath.get();
	}

	public void setSessionFolderPath(String session) {
		this.sessionFolderPath.set(session);
	}
	
	public FileDownloader getFileDownloader() {
				if(fileDownload==null) {
					setFileDownloader();
				}
				return fileDownload;
	}
			
	private void setFileDownloader() {
				this.fileDownload = new FileDownloader();
	} 
	
	public FetchDataFromXml getDataFromXML() {
		if (fetchXMLDataSet == null) {
			setDataInXML();
		}
		return fetchXMLDataSet.get();
	}

	public void setDataInXML() {
		this.fetchXMLDataSet.set(new FetchDataFromXml());
	} 

	public LoadPropertiesUtil getLoadPropertiesUtil() {
		if(properties == null) {
		   setLoadPropertiesUtil();
		}
		return properties;
	}
	
	public void setLoadPropertiesUtil() {
		this.properties = new LoadPropertiesUtil();
	} 
	
}