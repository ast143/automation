package com.nordea.framework;

/** 
 * Description: Context- This class is the entry point for objects and provides the global and local objects of application.
 * 
 * Functionality Created By  	: Nitesh Khanna
 * Reviewed By                 	: Debabrata Behera
 * 
*/

public class Context {
	public static Global global() {
		return Global.getGlobal();
	}

	public static Local local() {
		return Local.getLocal();
	}
}
