package com.nordea.page.components;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.pages.Page;

public class CopyCustomerToLISPopup implements Page{
	 
	 @FindBy(xpath = "//table[@class='popUpTable']")
	    WebElement popup;
	 
	 @FindBy(xpath = "//input[@value='Yes']")
	    WebElement copyYes;
	 
	 public CopyCustomerToLISPopup() {
	        PageFactory.initElements(Context.global().getDriver(), this);
	    }
	 
	 public void copyToLIS(){
		 if(Context.global().getSeleniumUtils().verifyElementPresent(this.popup, "Copy to LIS Popup")){
			 Context.global().getSeleniumUtils().clickOnElement(this.copyYes, "Copy to LIS- Yes Option");
		 }
	 }

	 @Override
	public void verifyPageState() {		
	}
}
