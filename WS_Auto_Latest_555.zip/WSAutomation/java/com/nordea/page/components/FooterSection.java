package com.nordea.page.components;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.pages.Page;

/**
 * Description: This page includes footer of LIS application to extract the exact date
 * 
 * 
 * Functionality Created By  	: Debabrata Behera
 * Reviewed By                 	: Kapil Kapoor
 * Review Date                	: 
 * Modified By 				   	: 
 * Last Modified Date        	: 
 * Reviewed By					: 
 * Review Date					: 
*/
public class FooterSection implements Page{

	@FindBy(id = "date")
    WebElement applicationdate;
	
	public FooterSection() {
        PageFactory.initElements(Context.global().getDriver(), this);
    }
	
	public String getApplicationDateandTime(){
		return Context.global().getSeleniumUtils().getText(this.applicationdate);
	}
	
    public String getApplicationDate(){
    	String date = Context.global().getSeleniumUtils().getText(this.applicationdate);
    	date = date.substring(0,10).trim();
    	return date;
	}
    
    public String getApplicationTime(){
    	String date = Context.global().getSeleniumUtils().getText(this.applicationdate);
    	date = date.substring(12,date.length()).trim();
    	return date;
	}
	
	@Override
	public void verifyPageState() {
		// TODO Auto-generated method stub
		
	}

}
