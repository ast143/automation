package com.nordea.page.components;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.pages.Page;
/**
 * Description: This page includes Left panel objects.
 * 
 * 
 * Functionality Created By  	: Kapil Kapoor
 * Reviewed By                 	: Nitesh Khanna
 * Review Date                	: 
 * Modified By 				   	: 
 * Last Modified Date        	: 
 * Reviewed By					: 
 * Review Date					: 
*/
public class LHN implements Page {

	@FindBy(linkText = "Data search")
	private WebElement lnkDataSearch;
	
	@FindBy(linkText = "Home / workflow")
	private WebElement lnkHomeWorkflow;
	
	@FindBy(linkText = "Customer")
	private WebElement lnkCustomer;
	
	@FindBy(linkText = "New customer")
	private WebElement lnkNewCustomer;
	
	@FindBy(linkText = "Convert customer")
	private WebElement lnkConvertCustomer;
	
	@FindBy(linkText = "Customer roles")
	private WebElement lnkCustomerRoles;
	
	@FindBy(linkText = "Risk Query")
	private WebElement lnkRiskQuery;
	
	@FindBy(linkText = "Calculator")
	private WebElement lnkCalculator;
	
	@FindBy(linkText = "New life insurance calculation")
	private WebElement lnkLifeInsCal;
	
	@FindBy(linkText = "New pension insurance calculation")
	private WebElement lnkPensionInsCal;
	
	@FindBy(linkText = "Offer")
	private WebElement lnkOffer;
	
	@FindBy(linkText = "New offer")
	private WebElement lnkNewOffer;
	
	@FindBy(linkText = "Policy")
	private WebElement lnkPolicy;
	
	@FindBy(linkText = "Event insured")
	private WebElement lnkEventInsured;
	
	@FindBy(linkText = "Event view")
	private WebElement lnkEventView;
	
	@FindBy(linkText = "Change calculations")
	private WebElement lnkChangeCal;
	
	@FindBy(linkText = "Claim")
	private WebElement lnkClaim;
	
	@FindBy(linkText = "Insurance claims")
	private WebElement lnkInsuranceClaims;
	
	@FindBy(linkText = "Claim settlements")
	private WebElement lnkClaimSettlements;
	
	@FindBy(linkText = "Payments")
	private WebElement lnkPayments;
	
	@FindBy(linkText = "Payment List")
	private WebElement lnkPaymentList;
	
	@FindBy(linkText = "New installment")
	private WebElement lnkNewInstallment;
	
	@FindBy(linkText = "Installments")
	private WebElement lnkInstallments;
	
	@FindBy(linkText = "Mass Handling")
	private WebElement lnkMassHandling;
	
	@FindBy(linkText = "Investments")
	private WebElement lnkInvestments;
	
	@FindBy(linkText = "New investment")
	private WebElement lnkNewInvestment;
	
	@FindBy(linkText = "Enter prices")
	private WebElement lnkEnterPrices;
	
	@FindBy(linkText = "Linking")
	private WebElement lnkLinking;
	
	@FindBy(linkText = "Price correction")
	private WebElement lnkPriceCorrection;
	
	@FindBy(linkText = "Investment prices")
	private WebElement lnkInvestmentPrices;
	
	@FindBy(linkText = "Investment mergers")
	private WebElement lnkInvestmentMergers;
	
	@FindBy(linkText = "Reporting")
	private WebElement lnkReporting;
	
	@FindBy(linkText = "Management")
	private WebElement lnkManagement;
	
	@FindBy(linkText = "Control data")
	private WebElement lnkControlData;
	
	@FindBy(linkText = "Products")
	private WebElement lnkProducts;
	
	@FindBy(linkText = "Policy terms")
	private WebElement lnkPolicyTerms;
	
	@FindBy(linkText = "Tariff")
	private WebElement lnkTariff;
	
	@FindBy(linkText = "View tariff")
	private WebElement lnkViewTariff;
	
	@FindBy(linkText = "Covers")
	private WebElement lnkCovers;
	
	@FindBy(linkText = "Portfolio profiles")
	private WebElement lnkPortfolioProfiles;
	
	@FindBy(linkText = "Compensation types")
	private WebElement lnkCompensationTypes;
	
	@FindBy(linkText = "Tax table roles")
	private WebElement lnkTaxTableRoles;
	
	@FindBy(linkText = "In English")
	private WebElement lnkInEnglish;
	
	@FindBy(linkText = "Suomeksi")
	private WebElement lnkInFinnish;
	
	@FindBy(linkText = "P� svenska")
	private WebElement lnkInSwedish;

	public LHN() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}

	public void clickDataSearch() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkDataSearch, "Data search link");
	}

	public void clickHomeWorkFlow() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkHomeWorkflow, "Home / workflow link");
	}
	
	public void clickCustomer() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkCustomer, "Customer link");
	}
	
	public void clickNewCustomer() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkNewCustomer, "New Customer link");
	}

	public void clickCovertCustomer() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkConvertCustomer, "Convert customer link");
	}
	
	public void clickCustomerRoles() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkNewCustomer, "Customer roles link");
	}
	
	public void clickRiskQuery() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkNewCustomer, "Risk Query link");
	}
	
	public void clickCalculator() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkCalculator, "Calculator link");
	}

	public void clickNewLifeInsCal() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkLifeInsCal, "New life insurance calculation link");
	}
	
	public void clickNewPensionInsCal() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkPensionInsCal, "New pension insurance calculation link");
	}
	
	public void clickOffer() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkOffer, "Offer link");
	}
	
	public void clickNewOffer() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkNewOffer, "New offer link");
		if(Context.global().getSeleniumUtils().verifyElementPresent(this.lnkNewOffer, "New offer link")){
			Context.global().getSeleniumUtils().clickOnElement(this.lnkNewOffer, "New offer link");
		}
	}
	
	public void clickPolicy() throws InterruptedException {
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(lnkPolicy, 30);
		Context.global().getSeleniumUtils().clickOnElement(this.lnkPolicy, "Policy link");
		Context.global().getSeleniumUtils().waitForPageToLoad(30);
	}
	
	public void clickEventInsured() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEventInsured, "Event insured link");
	}

	public void clickEventView() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEventView, "Event view link");
		if(Context.global().getSeleniumUtils().verifyElementPresent(this.lnkEventView, "Event view link")){
			Context.global().getSeleniumUtils().clickOnElement(this.lnkEventView, "Event view link");
		}
	}
	
	public void clickChangeCalculations() throws InterruptedException {
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(lnkChangeCal, 30);
		Context.global().getSeleniumUtils().clickOnElement(this.lnkChangeCal, "Change calculations link");
		Context.global().getSeleniumUtils().waitForPageToLoad(10);
	}
	
	public void clickClaim() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkClaim, "Claim link");
	}
	
	public void clickInsuranceClaim() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkInsuranceClaims, "Insurance claims link");
	}
	
	public void clickClaimSettlements() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkClaimSettlements, "Claim settlements link");
	}
	
	public void clickPayments() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkPayments, "Payments link");
	}
	
	public void clickPaymentList() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkPaymentList, "Payment list link");
	}
	
	public void clickNewInstallment() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkNewInstallment, "New installment link");
	}
	
	public void clickInstallments() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkInstallments, "Installments link");
	}
	
	public void clickInvestments() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkInvestments, "Investments link");
	}
	
	public void clickNewInvestment() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkNewInvestment, "New investment link");
	}
	
	public void clickEnterPrices() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "Enter prices link");
	}
	
	public void clickLinking() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkLinking, "Linking link");
	}
	
	public void clickPriceCorrection() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "Price correction link");
	}
	
	public void clickInvestmentPrices() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkInvestmentPrices, "Investment prices link");
	}
	
	public void clickInvestmentMergers() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "Investment mergers link");
	}
	
	public void clickReporting() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkReporting, "Reporting link");
	}
	
	public void clickManagement() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkManagement, "Management link");
	}
	
	public void clickControlData() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkControlData, "Control data link");
	}
	
	public void clickProducts() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkProducts, "Products link");
	}
	
	public void clickPolicyTerms() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "Policy terms link");
	}
	
	public void clickTariff() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "Tariff link");
	}
	
	public void clickViewTariff() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "View tariff link");
	}

	public void clickCovers() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "Covers link");
	}
	
	public void clickPortfolioProfiles() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "Portfolio profiles link");
	}
	
	public void clickCompensationTypes() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "Compensation types link");
	}
	
	public void clickTaxTableRoles() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkEnterPrices, "Tax table roles link");
	}	
	public void clickEnglish() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkInEnglish, "In English");
	}
	
	public void clickFinnish() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkInFinnish, "In Finnish");
	}
	
	public void clickSwedish() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkInSwedish, "In Swedish");
	}

	@Override
	public void verifyPageState() {
     //
	}
}
