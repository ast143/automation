package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;


/** 
 * Description: This page includes all the links for starting the batch runs
 * Navigation: Home/WorkFlow > Operations > Start batch Runs
 * 
 * 
 * 
 * Functionality Created By  	: Kapil Kapoor
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017 
*/

public class StartBatchRunPage implements Page {

	@FindBy(linkText= "Allocating the e-invoice authorization material")
	private WebElement lnkAllocatingAuthorizationMaterial;

	@FindBy(linkText= "Annuals batch")
	private WebElement lnkAnnualsBatch;
	
	@FindBy(linkText="ASKA+LAPA job")	
	private WebElement lnkASKALAPAJob;
	
	@FindBy(linkText="Asteri - Vasteri") 
	private WebElement lnkAsteriVasteri;
	
	@FindBy(linkText="Cancel previous direct debit request")
	private WebElement lnkCancelPrevDirectDebitReq;
	
	@FindBy(linkText="Cancel Received Payments")
	private WebElement lnkCancelReceivedPaymnt;
	
	@FindBy(linkText="Claim continuous compensation") 
	private WebElement lnkClaimContComp;
	
	@FindBy(linkText="Claim finalization")
	private WebElement lnkClaimFinal;
	
	@FindBy(linkText="Claim Payment Bank Response")
	private WebElement lnkClaimPayBankRes;
	
	@FindBy(linkText="Claim Payment Processing") 
	private WebElement lnkClaimPayProcess;
	
	@FindBy(linkText="Commission calculation") 
	private WebElement lnkCommCalc;
	
	@FindBy(linkText="Commission collection") 
	private WebElement lnkCommCollect;
	
	@FindBy(linkText="Commission payment") 
	private WebElement lnkCommPay;
	
	@FindBy(linkText="Common Printout Batch") 
	private WebElement lnkCommPrinBatch;
	
	@FindBy(linkText="Cover updation")
	private WebElement lnkCoverUpdat;
	
	@FindBy(linkText="Create DDebit Cancellation") 
	private WebElement lnkCreateDDebitCancel;
	
	@FindBy(linkText="Creating Charge Requests")
	private WebElement lnkCreatChargReq;
	
	@FindBy(linkText="Creating direct debit requests") 
	private WebElement lnkCreateDirectDebitReq;
	
	@FindBy(linkText="Creating the e-invoice charging material")
	private WebElement lnkCreateInvoiceCharg;
	
	@FindBy(linkText="Customer bonus for policies Pension period started before 2005")
	private WebElement lnkCustBonusPolPenPer2005;
	
	@FindBy(linkText="Customer Compression") 
	private WebElement lnkCustCompr;
	
	@FindBy(linkText="Customer Information DW, Daily") 
	private WebElement lnkCustInformDW;
	
	@FindBy(linkText="Direct Debit Allocation")
	private WebElement lnkDirectDebtAlloc;
	
	@FindBy(linkText="Direct Debit Proxies")
	private WebElement lnkDirectDebtProx;
	
	@FindBy(linkText="DW_connection Seller Info")
	private WebElement lnkDWConnSellInfo;
	
	@FindBy(linkText="DW_month_connection")
	private WebElement lnkDWMonConnec;
	
	@FindBy(linkText="DW_month_connection_includesCommissionFile")
	private WebElement lnkDWMonConnecIncludesComm;
	
	@FindBy(linkText="DW_week_connection")
	private WebElement lnkDWWeekConnec;
	
	@FindBy(linkText="DW-conectnion, daily")
	private WebElement lnkDWConnec;
	
	@FindBy(linkText="DW Premium")
	private WebElement lnkDWPremium;

	@FindBy(linkText="Fatca CCS")
	private WebElement lnkFatcaCCS;

	@FindBy(linkText="Fund rate-connection")
	private WebElement lnkFundRateConnection;

	@FindBy(linkText="Generic DW batch interface")
	private WebElement lnkGenericDWBatchInterface;

	@FindBy(linkText="Health declaration reminder") 
	private WebElement lnkHealthDeclReminder;
	
	@FindBy(linkText="Index increase") 
	private WebElement lnkIndexIncrease;

	@FindBy(linkText="INFO-v�litys")
	private WebElement lnkInfoValitys;

	@FindBy(linkText="Investment cost updating batch")
	private WebElement lnkInvstCstUpdtBtch;

	@FindBy(linkText="Invoice Reminder")
	private WebElement lnkInvcRem;

	@FindBy(linkText="Invoicing")
	private WebElement lnkInvcng;

	@FindBy(linkText="Invoicing Connection")
	private WebElement lnkInvcgConn;

	@FindBy(linkText="Lapsation")
	private WebElement lnkLapsation;

	@FindBy(linkText="Linking batch")
	private WebElement lnkLinkngBtch;

	@FindBy(linkText="Loan Cover claims")
	private WebElement lnkLoanCvrClaim;

	@FindBy(linkText="Mass Correction")
	private WebElement lnkMassCorrection;

	@FindBy(linkText="Mass interest code change") 
	private WebElement lnkMassIntrCodeChng;

	@FindBy(linkText="Minimum loading fee")
	private WebElement lnkMinLoadngFee;

	@FindBy(linkText="Notification and Expiry of Policy") 
	private WebElement lnkNotfExpPolicy;

	@FindBy(linkText="Notifications of pensions to Kela")
	private WebElement lnkNotfPensionKela;

	@FindBy(linkText="Notify Customer Waiting Pension Start Decision")
	private WebElement lnkNotfCustPenStrtDec;

	@FindBy(linkText="Notify Customer With End Of Savings")
	private WebElement lnkNotfCustEndSavng;

	@FindBy(linkText="NTS mass Investment plan change batch")
	private WebElement lnkNTSMassInvstPlanBtch;

	@FindBy(linkText="NTS mass savings allocation batch")
	private WebElement lnkNTSMassSavngAllocBtch;

	@FindBy(linkText="Omega Interface")
	private WebElement lnkOmgaIntrf;

	@FindBy(linkText="Organisation data transfer UNFINISHED")
	private WebElement lnkOrgDataTransUnfinished;

	@FindBy(linkText="Payment and Payment Fee")
	private WebElement lnkPayFee;

	@FindBy(linkText="PB1 Policy Create And Modify Info") 
	private WebElement lnkPolCrtModfInfo;

	@FindBy(linkText="PB2 Money Transfer And Reqt For Money Info")
	private WebElement lnkMoneyTransfReqMoneyinfo;

	@FindBy(linkText="PB3 Money Received and Policy Saving Info")
	private WebElement lnkMoneyRecvdPolSavInfo;

	@FindBy(linkText="PB4 Money Tranfer And Reqt For Money Ack Info")
	private WebElement lnkMoneyTransfReqtMoneyAckInfo;

	@FindBy(linkText="PB5 Policy Savings Value")
	private WebElement lnkPolySavngVal;

	@FindBy(linkText="Pension Forecast") 
	private WebElement lnkPensForecast;
	
	@FindBy(linkText="Pension start") 
	private WebElement lnkPenStart;

	@FindBy(linkText="Periodical Events New") 
	private WebElement lnkPerdEvntNew;

	@FindBy(linkText="Periodical Report")
	private WebElement lnkPerdRep;

	@FindBy(linkText="Policy data verification")
	private WebElement lnkPolDataVerf;

	@FindBy(linkText="Policy Renewal")
	private WebElement lnkPolRenewal;

	@FindBy(linkText="Premium Guarantee Technical Provision")
	private WebElement lnkPremGuaranteeTechProv;

	@FindBy(linkText="Prima connection")
	private WebElement lnkPrimaConn;

	@FindBy(linkText="Prima connection New")
	private WebElement lnkPrimaConnNew;

	@FindBy(linkText="Prima Interface")
	private WebElement lnkPrimaIntf;

	@FindBy(linkText="Private Banking Allocationservice")
	private WebElement lnkPrvtBankngAllcatServc;

	@FindBy(linkText="Receive Payments")
	private WebElement lnkRecPayment;

	@FindBy(linkText="Receiver Info, e-invoice")
	private WebElement lnkRecInfoInvc;

	@FindBy(linkText="Receive tax information")
	private WebElement lnkRecTaxInfo;

	@FindBy(linkText="Risk Invoicing Update")
	private WebElement lnkRiskInvcUpdt;

	@FindBy(linkText="Savings allocation execution batch")
	private WebElement lnkSavngAllocExeBtch;

	@FindBy(linkText="Savings and Surrender DW Monthly") 
	private WebElement lnkSavSurrDWMonthly;

	@FindBy(linkText="Start Default Pension Decision")
	private WebElement lnkStrtDefPensDec;

	@FindBy(linkText="Tax request batch")
	private WebElement lnkTaxReqBtch;

	@FindBy(linkText="Terminate Policy With End Of Savings") 
	private WebElement lnkTermPolEndSavng;

	@FindBy(linkText="Vasteri - Asteri") 
	private WebElement lnkVasteriAsteri;

	@FindBy(linkText="Vasteri-Asteri connection") 
	private WebElement lnkVasteriAsteriConn;

	@FindBy(linkText="Withdrawal Claim Automation")
	private WebElement lnkWithdrawalClaimAutomn;
	
	@FindBy(xpath= "//div[@class='commentbox']")
	private WebElement batchID;
	
	public StartBatchRunPage() {
	
	        PageFactory.initElements(Context.global().getDriver(), this); 
	    }
	    
	
	public void clickAllocatingTheEInvoiceAuthorizationMaterial() {
		Context.global().getSeleniumUtils().clickOnElement(lnkAllocatingAuthorizationMaterial, "Allocating the e-invoice authorization material");
	}
	
	public void clickAnnualsBatch() {
		Context.global().getSeleniumUtils().clickOnElement(lnkAnnualsBatch, "Annuals batch");
	}
	
	public void clickASKALAPAJob() {
		Context.global().getSeleniumUtils().clickOnElement(lnkASKALAPAJob, "ASKA+LAPA job");
	}
	
	public void clickAsteriVasteri() {
		Context.global().getSeleniumUtils().clickOnElement(lnkAsteriVasteri, "Asteri - Vasteri");
	}
	
	public void clickCancelPreviousDirectDebitRequest() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCancelPrevDirectDebitReq, "Cancel previous direct debit request");
	}
	
	
	public void clickCancelReceivedPayments() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCancelReceivedPaymnt, "Cancel Received Payments");
	}
	
	
	public void clickClaimContinuousCompensation() {
		Context.global().getSeleniumUtils().clickOnElement(lnkClaimContComp, "Claim continuous compensation");
	}
	
	
	public void clickClaimFinalization() {
		Context.global().getSeleniumUtils().clickOnElement(lnkClaimFinal, "Claim finalization");
	}
	
	public void clickClaimPaymentBankResponse() {
		Context.global().getSeleniumUtils().clickOnElement(lnkClaimPayBankRes, "Claim Payment Bank Response");
	}
	
	public void clickClaimPaymentProcessing() {
		Context.global().getSeleniumUtils().clickOnElement(lnkClaimPayProcess, "Claim Payment Processing");
	}
	
	public void clickCommissionCalculation() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCommCalc, "Commission calculation");
	}
	
	public void clickCommissionCollection() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCommCollect, "Commission collection");
	}
	
	public void clickCommissionPayment() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCommPay, "Commission payment");
	}
	
	public void clickCommonPrintoutBatch() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCommPrinBatch, "Common Printout Batch");
	}
	
	public void clickCoverUpdation() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCoverUpdat, "Cover updation");
	}
	
	public void clickCreateDDebitCancellation() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCreateDDebitCancel, "Create DDebit Cancellation");
	}
	
	public void clickCreatingChargeRequests() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCreatChargReq, "Creating Charge Requests");
	}
	
	public void clickCreatingDirectDebitRequests() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCreateDirectDebitReq, "Creating direct debit requests");
	}
	
	public void clickCreatingTheEInvoiceChargingMaterial() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCreateInvoiceCharg, "Creating the e-invoice charging material");
	}
	
	public void clickCustomerBonusPoliciesPensionPeriodStartedBefore2005() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCustBonusPolPenPer2005, "Customer bonus for policies Pension period started before 2005");
	}
	
	public void clickCustomerCompression() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCustCompr, "Customer Compression");
	}
	
	public void clickCustomerInformationDWDaily() {
		Context.global().getSeleniumUtils().clickOnElement(lnkCustInformDW, "Customer Information DW, Daily");
	}
	
	public void clickDirectDebitAllocation() {
		Context.global().getSeleniumUtils().clickOnElement(lnkDirectDebtAlloc, "Direct Debit Allocation");
	}
	
	public void clickDirectDebitProxies() {
		Context.global().getSeleniumUtils().clickOnElement(lnkDirectDebtProx, "Direct Debit Proxies");
	}
	
	public void clickDWConnectionSellerInfo() {
		Context.global().getSeleniumUtils().clickOnElement(lnkDWConnSellInfo, "DW_connection Seller Info");
	}
	
	public void clickDWMonthConnection() {
		Context.global().getSeleniumUtils().clickOnElement(lnkDWMonConnec, "DW_month_connection");
	}
	
	public void clickDWMonthConnectionIncludesCommissionFile() {
		Context.global().getSeleniumUtils().clickOnElement(lnkDWMonConnecIncludesComm, "DW_month_connection_includesCommissionFile");
	}
	
	public void clickDWWeekConnection() {
		Context.global().getSeleniumUtils().clickOnElement(lnkDWWeekConnec, "DW_week_connection");
	}
	
	public void clickDWConectnion() {
		Context.global().getSeleniumUtils().clickOnElement(lnkDWConnec, "DW-conectnion, daily");
	}
	
	public void clickDWPremium() {
		Context.global().getSeleniumUtils().clickOnElement(lnkDWPremium, "DW Premium");
	}
	
	public void clickFatcaCCS() {
		Context.global().getSeleniumUtils().clickOnElement(lnkFatcaCCS, "Fatca CCS");
	}
	
	public void clickFundRateConnection() {
		Context.global().getSeleniumUtils().clickOnElement(lnkFundRateConnection, "Fund rate-connection");
	}
	
	public void clickGenericDWBatchInterface() {
		Context.global().getSeleniumUtils().clickOnElement(lnkGenericDWBatchInterface, "Generic DW batch interface");
	}
	
	public void clickHealthDeclarationReminder() {
		Context.global().getSeleniumUtils().clickOnElement(lnkHealthDeclReminder, "Health declaration reminder");
	}
	
	public void clickIndexIncrease() {
		Context.global().getSeleniumUtils().clickOnElement(lnkIndexIncrease, "Index increase");
	}
	
	public void clickInfoValitys() {
		Context.global().getSeleniumUtils().clickOnElement(lnkInfoValitys, "INFO-v�litys");
	}
	
	public void clickInvestmentCostUpdatingBatch() {
		Context.global().getSeleniumUtils().clickOnElement(lnkInvstCstUpdtBtch, "Investment cost updating batch");
	}
	
	public void clickInvoiceReminde() {
		Context.global().getSeleniumUtils().clickOnElement(lnkInvcRem, "Invoice Reminde");
	}
	
	public void clickInvoicing() {
		Context.global().getSeleniumUtils().clickOnElement(lnkInvcng, "Invoicing");
	}	
	
	public void clickInvoicingConnection() {
		Context.global().getSeleniumUtils().clickOnElement(lnkInvcgConn, "Invoicing Connection");
	}
	
	public void clickLapsation() {
		Context.global().getSeleniumUtils().clickOnElement(lnkLapsation, "Lapsation");
	}
	
	public void clickLinkingBatch() {
		Context.global().getSeleniumUtils().clickOnElement(lnkLinkngBtch, "Linking batch");
	}
	
	public void clickLoanCoverClaims() {
		Context.global().getSeleniumUtils().clickOnElement(lnkLoanCvrClaim, "Loan Cover claims");
	}
	
	public void clickMassCorrection() {
		Context.global().getSeleniumUtils().clickOnElement(lnkMassCorrection, "Mass Correction");
	}
	
	public void clickMassInterestCodeChange() {
		Context.global().getSeleniumUtils().clickOnElement(lnkMassIntrCodeChng, "Mass interest code change");
	}
	
	public void clickMinimumLoadingFee() {
		Context.global().getSeleniumUtils().clickOnElement(lnkMinLoadngFee, "Minimum loading fee");
	}
	
	public void clickNotificationAndExpiryOfPolicy() {
		Context.global().getSeleniumUtils().clickOnElement(lnkNotfExpPolicy, "Notification and Expiry of Policy");
	}
	
	public void clickNotificationsOfPensionsToKela() {
		Context.global().getSeleniumUtils().clickOnElement(lnkNotfPensionKela, "Notifications of pensions to Kela");
	}
	
	public void clickNotifyCustomerWaitingPensionStartDecision() {
		Context.global().getSeleniumUtils().clickOnElement(lnkNotfCustPenStrtDec, "Notify Customer Waiting Pension Start Decision");
	}
	
	public void clickNotifyCustomerWithEndOfSavings() {
		Context.global().getSeleniumUtils().clickOnElement(lnkNotfCustEndSavng, "Notify Customer With End Of Savings");
	}
	
	public void clickNTSMassInvestmentPlanChangeBatch() {
		Context.global().getSeleniumUtils().clickOnElement(lnkNTSMassInvstPlanBtch, "NTS mass Investment plan change batch");
	}
	
	public void clickNTSMassSavingsAllocationBatch() {
		Context.global().getSeleniumUtils().clickOnElement(lnkNTSMassSavngAllocBtch, "NTS mass savings allocation batch");
	}
	
	public void clickOmegaInterface() {
		Context.global().getSeleniumUtils().clickOnElement(lnkOmgaIntrf, "Omega Interface");
	}
	
	public void clickOrganisationDataTransferUNFINISHED() {
		Context.global().getSeleniumUtils().clickOnElement(lnkOrgDataTransUnfinished, "Organisation data transfer UNFINISHED");
	}
	
	public void clickPaymentAndPaymentFee() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPayFee, "Payment and Payment Fee");
	}
	
	public void clickPB1PolicyCreateAndModifyInfo() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPolCrtModfInfo, "PB1 Policy Create And Modify Info");
	}
	
	public void clickPB2MoneyTransferAndReqtForMoneyInfo() {
		Context.global().getSeleniumUtils().clickOnElement(lnkMoneyTransfReqMoneyinfo, "PB2 Money Transfer And Reqt For Money Info");
	}
	
	public void clickPB3MoneyReceivedAndPolicySavingInfo() {
		Context.global().getSeleniumUtils().clickOnElement(lnkMoneyRecvdPolSavInfo, "PB3 Money Received and Policy Saving Info");
	}
	
	public void clickPB4MoneyTranferAndReqtForMoneyAckInfo() {
		Context.global().getSeleniumUtils().clickOnElement(lnkMoneyTransfReqtMoneyAckInfo, "PB4 Money Tranfer And Reqt For Money Ack Info");
	}
	
	public void clickPB5PolicySavingsValue() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPolySavngVal, "PB5 Policy Savings Value");
	}
	
	public void clickPensionForecast() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPensForecast, "Pension Forecast");
	}
	
	public void clickPensionStart() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPenStart, "Pension start");
	}

	public void clickPeriodicalEventsNew() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPerdEvntNew,"Periodical Events New");
	}
	
	public void clickPeriodicalReport() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPerdRep,"Periodical Report");
	}
	
	public void clickPolicyDataVerification() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPolDataVerf,"Policy data verification");
	}
	
	public void clickPolicyRenewal() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPolRenewal,"Policy Renewal");
	}
	
	public void clickPremiumGuaranteeTechnicalProvision() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPremGuaranteeTechProv,"Premium Guarantee Technical Provision");
	}
	
	public void clickPrimaConnection() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPrimaConn,"Prima connection");
	}
	
	public void clickPrimaConnectionNew() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPrimaConnNew,"Prima connection New");
	}
	
	public void clickPrimaInterface() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPrimaIntf,"Prima Interface");
	}
	
	public void clickPrivateBankingAllocationservice() {
		Context.global().getSeleniumUtils().clickOnElement(lnkPrvtBankngAllcatServc,"Private Banking Allocationservice");
	}
	
	public void clickReceivePayments() {
		Context.global().getSeleniumUtils().clickOnElement(lnkRecPayment,"Receive Payments");
	}
	
	public void clickReceiverInfoEInvoice() {
		Context.global().getSeleniumUtils().clickOnElement(lnkRecInfoInvc,"Receiver Info, e-invoice");
	}
	
	public void clickReceiveTaxInformation() {
		Context.global().getSeleniumUtils().clickOnElement(lnkRecTaxInfo,"Receive tax information");
	}
	
	public void clickRiskInvoicingUpdate() {
		Context.global().getSeleniumUtils().clickOnElement(lnkRiskInvcUpdt,"Risk Invoicing Update");
	}
	
	public void clickSavingsAllocationExecutionBatch() {
		Context.global().getSeleniumUtils().clickOnElement(lnkSavngAllocExeBtch,"Savings allocation execution batch");
	}
	
	public void clickSavingsAndSurrenderDWMonthly() {
		Context.global().getSeleniumUtils().clickOnElement(lnkSavSurrDWMonthly,"Savings and Surrender DW Monthly");
	}
	
	public void clickStartDefaultPensionDecision() {
		Context.global().getSeleniumUtils().clickOnElement(lnkStrtDefPensDec,"Start Default Pension Decision");
	}
	
	public void clickTaxRequestBatch() {
		Context.global().getSeleniumUtils().clickOnElement(lnkTaxReqBtch,"Tax request batch");
	}
	
	public void clickTerminatePolicyWithEndOfSavings() {
		Context.global().getSeleniumUtils().clickOnElement(lnkTermPolEndSavng,"Terminate Policy With End Of Savings");
	}
	
	public void clickVasteriAsteri() {
		Context.global().getSeleniumUtils().clickOnElement(lnkVasteriAsteri,"Vasteri - Asteri");
	}
	
	public void clickVasteriAsteriConnection() {
		Context.global().getSeleniumUtils().clickOnElement(lnkVasteriAsteriConn,"Vasteri-Asteri connection");
	}
	
	public void clickWithdrawalClaimAutomation() {
		Context.global().getSeleniumUtils().clickOnElement(lnkWithdrawalClaimAutomn,"Withdrawal Claim Automation");
	}
	
	public String fetchBatchID() {
		return Context.local().getBatchUtilityFunction().fetchBatchID(Context.global().getSeleniumUtils().getText(batchID));		
	}


	@Override
	public void verifyPageState() {
		//
		
	}
	
}