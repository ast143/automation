package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: The pages refers the elements for all the events for different products.
 * 
 * 
 * Functionality Created By : Snehal Bahulekar
 * Reviewed By 				: Kapil kapoor
 * Modified By 				: Mithen Kadam
 * Last Modified Date  	 	: 21/04/2017
 * Reviewed By				: Poonam Joshi
 * Review Date				: 27/04/2017
 */

public class EventInsured implements Page {

	@FindBy(linkText = "Event insured")
	private WebElement lnkEventInsured;

	@FindBy(linkText = "Surrender")
	private WebElement lnkEISurrender;
	
	@FindBy(linkText = "Withdrawal")
	private WebElement lnkEIWithdrawal;
	
	@FindBy(linkText = "Premium return")
	private WebElement lnkEIPremiumreturn;
	
	@FindBy(linkText = "Policy cancellation")
	private WebElement lnkEIPolicyCancellation;
	
	@FindBy(linkText = "Death event")
	private WebElement lnkEIDeathEvent;
	
	@FindBy(linkText = "Permanent disability")
	private WebElement lnkEIPermanentDisability;
	
	@FindBy(linkText = "Permanent accidental handicap event")
	private WebElement lnkEIPermanentAccidentalHandicap;
	
	@FindBy(linkText = "Critical illness event")
	private WebElement lnkEICriticalIllness;
	
	
	

	public EventInsured() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}

	public void clickEventInsured() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEventInsured, "Event Insured");
	}

	public void clickSurrender() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEISurrender, "Surrender");

	}
	public void clickWithdrawal() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEIWithdrawal, "Withdrawal");

	}
	public void clickPremiumReturn() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEIPremiumreturn, "Premium return");

	}
	
	public void clickPolicyCancellation() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEIPolicyCancellation, "Policy Cancellation");

	}
	public void clickDeathEvent() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEIDeathEvent, "Death Event");

	}
	public void clickPermanentDisability() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEIPermanentDisability, "Permanent Disability");

	}
	public void clickPermanentAccidentalHandicap() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEIPermanentAccidentalHandicap, "Permanent Accidental Handicap");

	}
	public void clickCriticalIllnessEvent() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEICriticalIllness, "Critical Illness Event");

	}

	

	
	@Override
	public void verifyPageState() {
		// 
	}
}
