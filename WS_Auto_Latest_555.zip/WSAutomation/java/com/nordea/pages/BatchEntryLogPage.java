package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/** 
 * Description: This page includes all the web elements needed for running Linking Batch
 * Navigation: Home/WorkFlow > Operations > Start batch Runs > Linking Batch / Periodical Events New
 * 
 * 
 * 
 * Functionality Created By  	: Kapil Kapoor
 * Reviewed By                 	: Nitesh Khanna
 * Review Date                	: 27/02/2017
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017
*/


public class BatchEntryLogPage implements Page{

	@FindBy(name= "beginDate")
	private WebElement txtBeginDate;
	
	@FindBy(name= "beginTime")
	private WebElement txtBeginTime;
	
	@FindBy(name= "endingDate")
	private WebElement txtEndingDate;
	
	@FindBy(name= "endingTime")
	private WebElement txtEndingTime;
	
	@FindBy(name= "batchSymbol")
	private WebElement drpRun;
	
	@FindBy(name= "submit")
	private WebElement btnFind;

	@FindBy(xpath= "//td[contains(text(),'event report')]/..//input")
	private WebElement btnEventRptPrint;
	
	@FindBy(xpath= "//td[contains(text(),'error report')]/..//input")
	private WebElement btnErrorRpt;
	
	@FindBy(xpath= "//td[contains(text(),'Tapahtumalista - Nordea Vasteri - Asteri palveluyh')]/..//input")
	private WebElement btnEventRptVasterAsteriConnPrint;
	
	@FindBy(xpath= "//td[contains(text(),'Virhelista - Nordea Vasteri - Asteri palveluyhteys')]/..//input")
	private WebElement btnErrorRptVasterAsteriConnPrint;
	
	@FindBy(name= "statusReport")
	private WebElement btnStatusReport;
	
	@FindBy(xpath= "//th[contains(text(),'Progress')]/..//td[1]")
	private WebElement elmProgress;
	
	@FindBy(xpath= "//input[@value='004']")
	private WebElement rdbXML;
	
	@FindBy(xpath= "//input[@value='003']")
	private WebElement rdbHTML;
	
	@FindBy(xpath= "//input[@value='002']")
	private WebElement rdbPDF;
	
	@FindBy(name= "BatchLogEntryForm")
	private WebElement form;
	
	@FindBy(xpath = "//th[contains(text(),'Total work')]/following-sibling::td[1]")
	private WebElement elmTotalWork;
	
	@FindBy(name= "indexedFieldCredentialLevel[0]")
	private WebElement drpAuthorizationlevel;
	
	public BatchEntryLogPage()
	{
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public void clickBeginDate(String strText)
	{
		Context.global().getSeleniumUtils().enterText(txtBeginDate, "Begin Date", strText);
	}
	
	public void clickBeginTime(String strText)
	{
		Context.global().getSeleniumUtils().enterText(txtBeginTime, "Begin Time", strText);
	}
	
	public void clickEndDate(String strText)
	{
		Context.global().getSeleniumUtils().enterText(txtEndingDate, "End Date", strText);
	}
	
	public void clickEndTime(String strText)
	{
		Context.global().getSeleniumUtils().enterText(txtEndingTime, "End Time",strText);
	}
	
	public void selectBatchToRun(String drpdownValue)
	{
		Context.global()
		.getSeleniumUtils()
		.selectValueFromDropDown(drpRun, "visibleText",
				drpdownValue);
	}
	
	public void clickFind()
	{
		Context.global().getSeleniumUtils().clickOnElement(btnFind, "Find");
	}
	
	public void clickEventReportPrint()
	{	
		Context.global().getSeleniumUtils().setAttributeValue("arguments[0].setAttribute('target', '_self')", form);
		Context.global().getSeleniumUtils().clickOnElement(btnEventRptPrint, "Event Report");
	} 
	
	public void clickVasteriAsteriConnEventReportPrint()
	{	
		Context.global().getSeleniumUtils().setAttributeValue("arguments[0].setAttribute('target', '_self')", form);
		Context.global().getSeleniumUtils().clickOnElement(this.btnEventRptVasterAsteriConnPrint, "Vasteri Asteri Connection Event Report");
	}
	
	public void clickVasteriAsteriConnErrorReportPrint()
	{	
		Context.global().getSeleniumUtils().setAttributeValue("arguments[0].setAttribute('target', '_self')", form);
		Context.global().getSeleniumUtils().clickOnElement(this.btnErrorRptVasterAsteriConnPrint, "Vasteri Asteri Connection Error Report");
	}
	
	public void clickErrorReportPrint()
	{	
		Context.global().getSeleniumUtils().setAttributeValue("arguments[0].setAttribute('target', '_self')", form);
		Context.global().getSeleniumUtils().clickOnElement(btnErrorRpt, "Error Report");
	}
	
	public void clickStatusReport()
	{
		Context.global().getSeleniumUtils().clickOnElement(btnStatusReport, "Status Report");
	}
	
	public String fetchProgressPercentage()
	{
		return Context.global().getSeleniumUtils().getText(elmProgress);
		
	}
	
	public void clickXMLRadioButton()
	{
		Context.global().getSeleniumUtils().clickOnElement(rdbXML, "XML");
	}
	
	public void clickPDFRadioButton()
	{
		Context.global().getSeleniumUtils().clickOnElement(rdbPDF, "PDF");
	}
	
	public void clickHTMLRadioButton()
	{
		Context.global().getSeleniumUtils().clickOnElement(rdbHTML, "HTML");
	}

	public int fetchTotalWork()
	{
		return Integer.parseInt(Context.global().getSeleniumUtils().getText(elmTotalWork).trim());
	}
	
	@Override
	public void verifyPageState() {
		//		
	}
	
	public void selectAuthorizationLevel(String drpdownValue)
	{
		Context.global()
		.getSeleniumUtils()
		.selectValueFromDropDown(drpAuthorizationlevel, "visibleText",
				drpdownValue);
	}
	
}
