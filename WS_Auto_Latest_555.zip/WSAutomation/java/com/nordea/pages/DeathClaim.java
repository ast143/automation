package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/** Description : The pages refers all elements till acceptance. It contains elements for Risk and Endownment product.
 * 
 * 
 * Functionality Created By  	: Snehal Bahulekar
 * Reviewed By                 	: Kapil Kapoor
 * Creation Date               	: 07/04/2017
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017
*/
public class DeathClaim implements Page {

	@FindBy(id ="date")
	private WebElement elmApplicationDate;
	
	@FindBy(name= "eventDate")									
	private WebElement txtDeathDate;
	
	@FindBy(name= "notificationDate")									
	private WebElement txtNotificationDate;	
	
	// For Endownment Product 
	
	@FindBy(name= "changeInsured")									
	private WebElement btnChangeInsured;	
	
	@FindBy(xpath = "//tr[2]/td[1]/a")									
	private WebElement lnkCoinsured;
	
	@FindBy(name= "return")									
	private WebElement btnReturn;
	
	@FindBy(name= "claimantId")									
	private WebElement txtClaimantId;
	
	@FindBy(name= "claimantName")									
	private WebElement txtClaimantName;
	
	@FindBy(name= "receiverId")									
	private WebElement txtReceiverId;
	
	@FindBy(name= "receiverName")									
	private WebElement txtReceiverName;
	
	@FindBy(name= "findClaimant")									
	private WebElement btnfindClaimant;
	
	@FindBy(name= "findReceiver")									
	private WebElement btnfindReceiver;
	
	@FindBy(name="continue")
	private WebElement btnContinue;
	
	@FindBy(xpath="//div[@class='commentbox']")
	private WebElement eleCommentBox;

	@FindBy(name="abort")
	private WebElement btnAbort;
	
	@FindBy(name="indexedSelectedCovers[0]")
	private WebElement chkDeathBenefit;
	
	@FindBy(xpath="//tr/th[contains(text(),'Claim amount')]/../td[1]")
	private WebElement elmDeathAmount;
	
	@FindBy(xpath="//tr/td[contains(text(),'Death benefit')]/../td[3]")
	private WebElement elmDeathCoverAmount;
	
	@FindBy(id="coverSpecificClaims.yes")
	private WebElement rdbEDBYes;
	
	@FindBy(id="coverSpecificClaims.no")
	private WebElement rdbEDBNo;
	
	@FindBy(name="back")
	private WebElement btnBack;
	
	@FindBy(xpath = "//tr/th[contains(text(),'Claim amount')]/../td[1]")
	private WebElement elmClaimAmountonAcceptance;
	
	@FindBy(name="accept")
	private WebElement btnAccept;

	
	
	public DeathClaim(){
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public String fetchApplicationDate() {
		String date = Context.global().getSeleniumUtils()
				.getText(this.elmApplicationDate);
		date = date.substring(0,10).trim();
    	return date;
		
	}
	public void setDeathDate(String deathDate){
    	Context.global().getSeleniumUtils().enterText(this.txtDeathDate,"DeathDate",deathDate);
    }
	
	public void setNotificationDate(String notificationDate){
    	Context.global().getSeleniumUtils().enterText(this.txtNotificationDate,"NotificationDate", notificationDate );
    }
	
	public void clickChangeInsured() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnChangeInsured, "Change Insured");
	}
	public void clickCoInsured() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkCoinsured, "Coinsured is Selected");
	}
	public void clickReturn() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnReturn, "Return");
	}
	
	public void setClaimantId(String claimantId){
		Context.global().getSeleniumUtils().clearText(this.txtClaimantId, "Claimant ID is Cleared");
    	Context.global().getSeleniumUtils().enterText(this.txtClaimantId, "ClaimantId",claimantId);
    }
	
	
	public void setClaimantName(String claimantName ){
		Context.global().getSeleniumUtils().clearText(this.txtClaimantName, "ClaimantName is Cleared");
    	Context.global().getSeleniumUtils().enterText(this.txtClaimantName, "ClaimantName",claimantName);
    }
	
	public void setReceiverId(String receiverId){
		Context.global().getSeleniumUtils().clearText(this.txtReceiverId, "Receiver ID is Cleared");
    	Context.global().getSeleniumUtils().enterText(this.txtReceiverId,"ReceiverId",receiverId);
    }
	
	public void setReceiverName(String receiverName){
		Context.global().getSeleniumUtils().clearText(this.txtReceiverName, "Receiver Name is Cleared");
    	Context.global().getSeleniumUtils().enterText(this.txtReceiverName,"receiverName",receiverName);
    }
	
	public void clickFindClaimant() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnfindClaimant, "Find Claimant");
	}
	
	public void clickFindReceiver() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnfindReceiver, "Find Receiver");
	}
	public void clickContinue() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnContinue, "Continue");
	}
	
	public void clickAbort() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAbort, "Abort");
	}
	
	public void checkDeathBenefit() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.chkDeathBenefit, "Check Death Benefit");
	}
	public void selectEDBYes() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.rdbEDBYes, "Select EDB Yes");
	}
	
	public void selectEDBNo() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.rdbEDBNo, "Select EDB No");
	}
	
	public String fetchAmount() {
		return Context.global().getSeleniumUtils()
				.getText(this.elmDeathAmount);
	}
	
	public String fetchCoverAmount() {
		return Context.global().getSeleniumUtils()
				.getText(this.elmDeathCoverAmount);
	}
	public void clickBack() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnBack, "Back");
	}
	
	public void clickAccept() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAccept, "Accept");
	}
	
	public boolean verifyCommentBoxDisplay()
	{
		return Context.global().getSeleniumUtils().verifyElementPresent(this.eleCommentBox, "CommentBox");	
	}
	
	public String fetchAmountonAcceptance() {
		return Context.global().getSeleniumUtils()
				.getText(this.elmClaimAmountonAcceptance);
	}

	@Override
	public void verifyPageState() {
		//	
	}
	
	
	
}


