package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: The pages refers the elements from Settlement creation to
 * approval
 * 
 * 
 * 
 * Functionality Created By : Snehal Bahulekar Reviewed By : Kapil Kapoor Review
 * Date : 07/04/2017 Modified By : Last Modified Date : Reviewed By : Review
 * Date :
 */

public class NewClaimSettlement implements Page {

	@FindBy(name = "selectIndemnee")
	private WebElement btnFindIndemnee;

	@FindBy(name = "abort")
	private WebElement btnAbort;

	@FindBy(name = "continue")
	private WebElement btnContinue;

	@FindBy(xpath = "//td[1]/a")
	private WebElement lnkSelectIndemnee;

	@FindBy(xpath = "(//th[contains(text(),'Handler')]//ancestor::tr//input)[1]")
	private WebElement txtHandler1;

	@FindBy(name = "handler")
	private WebElement txtHandler;

	@FindBy(name = "back")
	private WebElement btnBack;

	@FindBy(linkText = "//a[text()='Permanent disability']")
	private WebElement lnkPermanentDisability;

	@FindBy(xpath = "//a[contains(text(),'Death benefit')]")
	private WebElement lnkDeathBenefit;

	@FindBy(xpath = "//tbody/tr[1]/td[2]/a[contains(text(),'Death benefit, private')]/../../td[7]")
	private WebElement elmDeathBenefitAmount;

	@FindBy(xpath ="//tbody/tr[2]/td[contains(text(),'Withholding tax')]/../td[7]")
	private WebElement elmWithholdingTax;
	
	@FindBy(xpath = "//a[contains(text(),'Critical Illness')]")
	private WebElement lnkCriticalillness;

	@FindBy(xpath = "//a[contains(text(),'PermanentAccidental')]")
	private WebElement lnkPermanentAccidental;

	@FindBy(linkText = "Savings capital")
	private WebElement lnkSavingsCapital;

	@FindBy(xpath = "//th[contains(text(),'IBAN')]/../td[1]")
	private WebElement elmBankAccount;

	@FindBy(xpath = "//a[text()='Settlement detail']")
	private WebElement tabSettlementDetail;

	@FindBy(xpath = "//a[text()='Posting information']")
	private WebElement lnkPostingInformation;

	@FindBy(xpath = "//a[text()='Withholding tax']")
	private WebElement lnkWithholdingtax;

	@FindBy(name = "selectedCovers")
	private WebElement chkSelectedCovers;

	@FindBy(name = "accept")
	private WebElement btnAccept;

	@FindBy(xpath = "//a[text()='Settlement']")
	private WebElement tabSettlement;

	@FindBy(xpath = "//a[text()='Approvers']")
	private WebElement lnkApprovers;

	public NewClaimSettlement() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}

	public void clickFindIndemnee() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnFindIndemnee, "Find Indemnee");
	}

	public void clickSelectIndemnee() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkSelectIndemnee, "Select Indemnee");
	}

	public void clickAbort() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAbort, "Abort");
	}

	public void clickContinue() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnContinue, "Continue");
	}

	public void setHandler(String strText) {
		Context.global().getSeleniumUtils().clearText(txtHandler, "Handler is cleared");
		Context.global().getSeleniumUtils()
				.enterText(this.txtHandler, "Handler", strText);
	}

	public void clickBack() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnBack, "Back");
	}

	public void clickSelectedCovers() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.chkSelectedCovers, "Selected Covers");
	}

	public void clickDeathBenefit() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkDeathBenefit, "Death Benefit Link");
	}

	public String fetchDeathBenefitAmount() {

		return Context.global().getSeleniumUtils()
				.getText(this.elmDeathBenefitAmount);
	}

	public String fetchWithholdingTax() {

		return Context.global().getSeleniumUtils()
				.getText(this.elmWithholdingTax);
		
	}
	public void clickPD() {
		Context.global()
				.getSeleniumUtils()	
				.clickOnElement(this.lnkPermanentDisability,
						"Permanent Disability");
	}

	public void clickCI() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkCriticalillness, "Critical illness");
	}

	public void clickPA() {
		Context.global()
				.getSeleniumUtils()
				.clickOnElement(this.lnkPermanentAccidental,
						"Permanent Accidental Handicapped");
	}

	public void clickSC() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkSavingsCapital, "Saving capital");
	}

	public boolean verifyPDLink() {
		return Context.global().getSeleniumUtils()
				.verifyElementPresent(this.elmBankAccount, "Bank account");
	}

	public void clickTabSettlement() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.tabSettlement, "Settlement");
	}

	public void clickTabSettlementDetail() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.tabSettlementDetail, "Settlement Details");
	}

	public void clickPostingInformation() {
		Context.global()
				.getSeleniumUtils()
				.clickOnElement(this.lnkPostingInformation,
						"Posting Information");
	}

	public void clickWithholdingTax() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkWithholdingtax, "Withholding tax");
	}

	public void clickApprovers() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkApprovers, "Approvers");
	}

	@Override
	public void verifyPageState() {

	}
}
