/** 
 * Description: This page includes all the links for starting the batch runs
* Navigation: Home/WorkFlow > Operations > Start batch Runs
* 
 * 
 * 
 * Functionality Created By                  : Mayank Jain
* Reviewed By                         : Nitesh Khanna
* Review Date                          : 30/01/2017
* Modified By                                                                           : 
 * Last Modified Date             : 
 * Reviewed By                                                                         : 
 * Review Date                                                                          : 
*/

package com.nordea.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.nordea.framework.Context;

public class IndividualBatches implements Page
{
	
	@FindBy(id = "policyMin")
	private WebElement txtPolicyMin;
	
	@FindBy(id = "policyMax")
	private WebElement txtPolicyMax;
	
	@FindBy(name = "runDate")
	private WebElement txtRunDate;
	
	@FindBy(name = "queryStartDate")
	//private WebElement txtStartDate;
	
	//@FindBy(id = "datebox1")
    private WebElement txtStartDate;
	
	@FindBy(name = "queryEndDate")
	private WebElement txtEndDate;
	
	@FindBy(name = "offerMin")
	private WebElement txtOfferMin;
	
	@FindBy(name = "offerMax")
	private WebElement txtOfferMax;
	
	@FindBy(name = "NFI_TRANSFER_FOLDER")
	private WebElement txtDirectory;
	
	@FindBy(name = "fileName")
	private WebElement txtfileName;
	
	@FindBy(name = "NFI_RECEIPT_FILE_NAME")
	private WebElement txtReceiptfileName;
	
	@FindBy(name ="NFI_PRODUCT_LIST")
	private WebElement txtProductList;
	
	//-----------------------------------functions-----------------------------------
	
	public void enterMinValue(String InvoicingPolicyMinField)
	{	
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyMin, "Invoicing policy Min", InvoicingPolicyMinField);
    }
	
	public void enterMaxValue(String InvoicingPolicyMaxField)
	{	
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyMax, "Invoicing policy Max", InvoicingPolicyMaxField);
    }
	
	public void enterNEPMinValue(String InvoicingPolicyMinField)
	{
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyMin, "NEP policy Min", InvoicingPolicyMinField);
    }
	
	public void enterNEPMaxValue(String InvoicingPolicyMaxField)
	{
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyMax, "NEP policy Max", InvoicingPolicyMaxField);
    }
	
	public void enterAllocatingEInvoiceValue(String HandlingDate)
	{
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyMax, "Allocating E-Invoice Handling Date", HandlingDate);
    }
	
	public void enterStartDate(String VACStartDate)
	{	
		//Context.global().getSeleniumUtils().clearText(this.txtStartDate, "Vasteri Asteri connection Start date");
		
		Context.global().getDriver().findElement(By.name("queryStartDate")).clear();
		Context.global().getDriver().findElement(By.name("queryStartDate")).sendKeys(VACStartDate);
		
    	//Context.global().getSeleniumUtils().enterText(this.txtStartDate, "Vasteri Asteri connection Start date", VACStartDate);
    }
	
	public void enterEndDate(String VACEndDate)
	{	
		Context.global().getDriver().findElement(By.name("queryEndDate")).clear();
		Context.global().getDriver().findElement(By.name("queryEndDate")).sendKeys(VACEndDate);
    	//Context.global().getSeleniumUtils().enterText(this.txtEndDate, "Vasteri Asteri connection End date", VACEndDate);
    }
	
	public void enterProductList(String ProductList)
	{	
		//Context.global().getSeleniumUtils().clearText(this.txtProductList,"Vasteri Asteri product list");
    	//Context.global().getSeleniumUtils().enterText(this.txtProductList,"Vasteri Asteri product list", ProductList);
		
		Context.global().getDriver().findElement(By.name("NFI_PRODUCT_LIST")).clear();
		Context.global().getDriver().findElement(By.name("NFI_PRODUCT_LIST")).sendKeys("9");
    	
    	
    }
	
	public void enterRunDate(String RunDate)
	{	
    	Context.global().getSeleniumUtils().enterText(this.txtRunDate, "Run date", RunDate);
    }
	
	public void enterOfferMin(String HDReminderOfferMin)
	{	
    	Context.global().getSeleniumUtils().enterText(this.txtOfferMin, "HD Reminder Offer Min", HDReminderOfferMin);
    }
	
	public void enterOfferMax(String HDReminderOfferMax)
	{	
    	Context.global().getSeleniumUtils().enterText(this.txtOfferMax, "HD Reminder Offer Min", HDReminderOfferMax);
    }
	
	public void enterAsteriVasteriDirectory(String AsteriVasteriDirectoryTxt)
	{	
    	Context.global().getSeleniumUtils().enterText(this.txtDirectory, "Asteri-Vasteri Directory", AsteriVasteriDirectoryTxt);
    }
	
	public void enterAsteriVasteriFileName(String AsteriVasteriFileNameTxt)
	{	
    	Context.global().getSeleniumUtils().enterText(this.txtfileName, "Asteri-Vasteri File Name", AsteriVasteriFileNameTxt);
    }
	
	public void enterAsteriVasteriReceiptFileName(String AsteriVasteriReceiptTxt)
	{	
    	Context.global().getSeleniumUtils().enterText(this.txtReceiptfileName, "Asteri-Vasteri Receipt File Name", AsteriVasteriReceiptTxt);
    }
	
	public void enterReceivePayments(String ReceivePaymentsFileName)
	{	
    	Context.global().getSeleniumUtils().enterText(this.txtfileName, "Receive Payments File Name", ReceivePaymentsFileName);
    }

	@Override
	public void verifyPageState() {
		// TODO Auto-generated method stub
		
	}
}
