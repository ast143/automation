package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: ChangeCalculation - It will perform various change calculations pertaining to 
 * Change Calculation in Investment Plan.
 
 * Functionality Created By  	: Neville Menezes
 * Reviewed By                 	: Mithen Kadam			
 * Review Date                	: 14/04/2017	
 * Modified By 				   	: Mithen Kadam 
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017 
 * 
*/

public class ChangeCalPensionInvestmentPlan {
	/**
     *  Application Page : Investment Plan
     */
	@FindBy(linkText = "Investment plan")
    private WebElement lnkInvestmentPlan;
	
	@FindBy(linkText = "Special prices")
    private WebElement lnkSpecialPrices;
	
	@FindBy(xpath ="//input[@value='New']")
    private WebElement btnNew;
	
	public ChangeCalPensionInvestmentPlan() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	/**
     * Methods for Investment Plan
     */
	public void clickSpecialPrices(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkSpecialPrices, "Special Prices");
	}
	
	public void clickInvestmentPlan(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkInvestmentPlan, "InvestmentPlan");
	}
	
	public void clickNew() {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnNew, "New");
    }
	
}