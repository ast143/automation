package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;


/**
 * Description: PolicyFurtherDetails - This Page contains all objects related to
 * policy further details tab.
 * Navigation to this page is by clicking on LHN >> Policy >>Further details.
 * 
 * Abbreviations
 * VAEIC = View account events including cancelled
 * 
 * 
 * Functionality Created By  	: Atluri Vinay Kumar
 * Reviewed By                 	: Debabrata Behera
 * Review Date                	: 28/04/2017
 * Modified By 				   	: 
 * Last Modified Date        	: 
 * Reviewed By					: 
 * Review Date					: 
*/

public class PolicyFurtherDetails implements Page{
	
	@FindBy(linkText="Further details")
	private WebElement tabFurtherDetails;
	
	@FindBy(name="editAdditionalInformation")
	private WebElement btnEditAdditionalInfo;
	
	@FindBy(name="ratingBenefitCode")
	private WebElement drpRatingBenefit;
	
	@FindBy(name="reinsuranceTreaty")
	private WebElement drpReinsuranceTreaty;
	
	@FindBy(name="reinsuranceCode")
	private WebElement drpReinsuranceCode;
	
	@FindBy(name="customershipGroupCode")
	private WebElement drpCustomershipGroupCode;

	@FindBy(name="policyBasedTariffCode")
	private WebElement drpPolicyBasedTariff;

	@FindBy(id="irrevocableBeneficiaryClause.yes")
	private WebElement rdbIrrevocableBenfYes;

	@FindBy(id="irrevocableBeneficiaryClause.no")
	private WebElement rdbIrrevocableBenfNo;

	@FindBy(name="taxCode")
	private WebElement drpBasisOfTaxation;
	
	@FindBy(name="markUnfinished")
	private WebElement chkMarkPolicyUnfinished;
	
	@FindBy(name="resAddPremiums")
	private WebElement drpRestrictAddPremium;
	
	@FindBy(name="addTermAcceptance")
	private WebElement chkAddTermAcceptance;
	
	@FindBy(name="sequenceCode")
	private WebElement drpSequencing;

	@FindBy(name="defaultChannel")
	private WebElement drpDefaultChannel;

	@FindBy(name="oldPolicyNumber")
	private WebElement txtOldPolicyNumber;

	@FindBy(name="changeCode")
	private WebElement drpChangeCode;

	@FindBy(name="newPolicyNumber")
	private WebElement txtNewPolicyNumber;

	@FindBy(name="changeCode2")
	private WebElement drpChangeCode2;
	
	@FindBy(name="addPledge")
	private WebElement btnAddPledge;
	
	@FindBy(name="save")
	private WebElement btnSave;

	@FindBy(name="cancel")
	private WebElement btnCancel;
	
	@FindBy(name="pledgeCode")
	private WebElement drpPledgeCode;
	
	@FindBy(name="customerId")
	private WebElement txtCustomerId;

	@FindBy(name="pledgeHolder")
	private WebElement txtPledgeHolder;

	@FindBy(name="findHolderByIdentifier")
	private WebElement btnFindHolder;

	@FindBy(name="findHolderByName")
	private WebElement btnFindName;

	@FindBy(name="amount")
	private WebElement txtAmount;

	@FindBy(name="endDate")
	private WebElement txtEndDate;

	@FindBy(name="description")
	private WebElement elmDescription;

	@FindBy(name="editAdditionalInformationDescription")
	private WebElement btnAddPolicyDescription;

	@FindBy(name="policyDescription")
	private WebElement elmPolicyDescription;
	
	@FindBy(name="addIndex")
	private WebElement btnAddIndex;

	@FindBy(name="targetCode")
	private WebElement drpTarget;

	@FindBy(name="indexTableIdentifier")
	private WebElement drpIndexTable;

	@FindBy(name="increasePercent")
	private WebElement txtIncreasePercent;

	@FindBy(name="effectiveDate")
	private WebElement txtEffectiveDate;

	@FindBy(name="expiryDate")
	private WebElement txtExpiryDate;

	@FindBy(name="delete")
	private WebElement btnDelete;

	@FindBy(name="addTerm")
	private WebElement btnAddPolicyTerm;

	@FindBy(name="termSelected")
	private WebElement drpSelectPolicyTerm;

	@FindBy(name="validityEndDate")
	private WebElement txtpolicyTermEndDate;

	@FindBy(name="savePolicyTerm")
	private WebElement btnsavePolicyTerm;

	@FindBy(name="getTermDates")
	private WebElement btnGetTermDates;
	
	@FindBy(name="addPolicyInterestRate")
	private WebElement btnAddInterestRate;

	@FindBy(name="interestRateId")
	private WebElement drpInterestCode;

	@FindBy(name="findInterestRateInfoById")
	private WebElement btnFindInterestRate;

	@FindBy(name="effectiveDate")
	private WebElement txtInterestEffDate;

	@FindBy(name="expiryDate")
	private WebElement txtInterestEndDate;
	
	public PolicyFurtherDetails(){
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public void clickFurtherDetailsTab(){
	    Context.global().getSeleniumUtils().clickOnElement(this.tabFurtherDetails, "further details Tab");
    }
	
	public  void clickEditAdditionalInfo(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnEditAdditionalInfo, "edit additional information button");
	}
   
	public  void selectRatingBenefit(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpRatingBenefit, "visibleText", value);
	}
	
	public  void selectReinsuranceTreaty(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpReinsuranceTreaty, "visibleText", value);
	}
	
	public  void selectContractMethod(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpReinsuranceCode, "visibleText", value);
	}
	
	public  void selectCustomershipGroup(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpCustomershipGroupCode, "visibleText", value);
	}
	
	public  void selectPolicySpecificTariff(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpPolicyBasedTariff, "visibleText", value);
	}
	
	public  void clickIrrevocableBenfYes(){
		 Context.global().getSeleniumUtils().clickOnElement(this.rdbIrrevocableBenfYes, "irrevocableBeneficiary clause Yes radio button");
	}
	
	public  void clickIrrevocableBenfNo(){
		 Context.global().getSeleniumUtils().clickOnElement(this.rdbIrrevocableBenfNo, "irrevocableBeneficiary clause No radio button");
	}
	
	public  void selectBasisOfTaxation(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpBasisOfTaxation, "visibleText", value);
	}
	
	public  void clickPolicyMarkUnfinished(){
		 Context.global().getSeleniumUtils().clickOnElement(this.chkMarkPolicyUnfinished, "mark policy as unfinished checkbox");
	}
   
	public  void selectRestrictAddPremium(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpRestrictAddPremium, "visibleText", value);
	}
   
	public  void clickAddTermAcceptance(){
		 Context.global().getSeleniumUtils().clickOnElement(this.chkAddTermAcceptance, "additional term acceptance checkbox");
	}
	
	public String fetchIXproductNo(){
		return Context.global().getDriver().findElementByXPath("//th[contains(text(),'IX Product Number')]//following-sibling::td[1]").getText().trim();
	}
	
	public  void selectSequencing(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpSequencing, "visibleText", value);
	}
	
	public  void selectDefaultChannel(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpDefaultChannel, "visibleText", value);
	}
	
	public  void selectChangeCode(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpChangeCode, "visibleText", value);
	}
	
	public  void selectChangeCode2(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpChangeCode2, "visibleText", value);
	}
   
	public  void enterOldPolicyNo(String policyNo){
		 Context.global().getSeleniumUtils().enterText(this.txtOldPolicyNumber, "old policy number", policyNo);
	}
	
	public  void enterNewPolicyNo(String policyNo){
		 Context.global().getSeleniumUtils().enterText(this.txtNewPolicyNumber, "new policy number", policyNo);
	}
	
	public String fetchLisCovertedDate(){
		return Context.global().getDriver().findElementByXPath("//th[contains(text(),'LIS converted date')]//following-sibling::td[1]").getText().trim();
	}
	
	public String fetchServiceCode(){
		return Context.global().getDriver().findElementByXPath("//th[contains(text(),'Service Code')]//following-sibling::td[1]").getText().trim();
	}
	
	public  void clickSave(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "save button");
	}
	
	public  void clickCancel(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnCancel, "cancel button");
	}
	
	public  void clickAddPledge(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddPledge, "add pledge button");
	}
	
	public  void selectPledgeCode(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpPledgeCode, "visibleText", value);
	}
  
	public  void enterCustomerId(String custId){
		 Context.global().getSeleniumUtils().enterText(this.txtCustomerId, "customer id", custId);
	}
	
	public  void enterHolderName(String holderName){
		 Context.global().getSeleniumUtils().enterText(this.txtPledgeHolder, "holder name", holderName);
	}
	
	public  void clickFindIdentifier(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnFindHolder, "find identifier button");
	}
	
	public  void clickFindHolderName(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnFindName, "find holder name button");
	}
	
	public  void enterTextamount(String amount){
		 Context.global().getSeleniumUtils().enterText(this.txtAmount, "amount", amount);
	}
	
	
	public  void enterEnddate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtEndDate, "end date", date);
	}
	
	public  void enterDescription(String value){
		 Context.global().getSeleniumUtils().enterText(this.elmDescription, "description",value);
	}
	
	public  void clickAddPolicyDescripton(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddPolicyDescription, "add policy description button");
	}
	
	public  void enterPolicyDescription(String value){
		 Context.global().getSeleniumUtils().enterText(this.elmPolicyDescription, "policy description",value);
	}
	
	public  void clickAddIndex(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddIndex, "add index button");
	}
	
	public  void selectIndexTarget(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpTarget, "visibleText", value);
	}
	
	public  void selectIndexTable(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpIndexTable, "visibleText", value);
	}
	
	public  void enterIncreasedPercent(String value){
		 Context.global().getSeleniumUtils().enterText(this.txtIncreasePercent, "index increased percent",value);
	}
	
	public  void enterIndexStartDate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtEffectiveDate, "index effective date",date);
	}
	
	public  void enterIndexEndDate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtExpiryDate, "index end date",date);
	}
	
	public  void clickDelete(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnDelete, "delete button");
	}
	
	public  void clickAddPolicyTerm(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddPolicyTerm, "add policy term button");
	}
	
	public  void selectPolicyTerm(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpSelectPolicyTerm, "visibleText", value);
	}
	
	public  void enterPolicyTermEndDate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtpolicyTermEndDate, "policy term end date",date);
	}
	
	public  void clickSavePolicyTerm(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnsavePolicyTerm, "save policy term button");
	}
	
	public  void clickGetTermDates(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnGetTermDates, "get term dates button");
	}
	
	public  void clickAddInterestRate(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddInterestRate, "add interest rate button");
	}
	
	public  void selectInterestRateId(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpInterestCode, "visibleText", value);
	}
	
	public  void clickFindInterestRate(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnFindInterestRate, "find interest rate button");
	}
	
	public  void enterInterestStartDate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtInterestEffDate, "interest rate start date",date);
	}
	
	public  void enterInterestEndDate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtInterestEndDate, "interest rate end date",date);
	}
	
	public String fetchInterestName(){
		return Context.global().getDriver().findElementByXPath("//th[contains(text(),'Interest name')]//following-sibling::td[1]").getText().trim();
	}
	
	public String fetchInterestRate(){
		return Context.global().getDriver().findElementByXPath("//th[contains(text(),'Interest rate')]//following-sibling::td[1]").getText().trim();
	}
	
	@Override
	public void verifyPageState() {
		//
		
	}

}
