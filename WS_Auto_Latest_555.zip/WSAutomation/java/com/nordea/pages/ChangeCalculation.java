package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;


/**
 * Description: ChangeCalculation - It will perform various Change Calculations pertaining to a policy life cycle 
 
 * Functionality Created By  	: Neville Menezes
 * Reviewed By                 	: Mithen Kadam	
 * Review Date                	: 14/04/2017
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017
 * 
*/
public class ChangeCalculation implements Page{
	/**		    
	    *   Application Page :  All
	    */
	@FindBy(name="add")
	private WebElement btnAdd;
	
	@FindBy(linkText="Change of cover")
	private WebElement lnkChangeCover;
	
	@FindBy(linkText="Change of repayment plan")
	private WebElement lnkChangeRepaymentPlan;
	
	@FindBy(xpath="//table[@class='scrollTable']")
	private WebElement table;
	
	@FindBy(xpath="//input[@value='Continue']")
	private WebElement btnContinue;
	
	/**		    
	    *   Application Page : Covers Tab
	    */
	
	@FindBy(name="coverEffectiveDate")
	private WebElement txtCoverEffectiveDate;
	
	@FindBy(name="coverExpiryDate")
	private WebElement txtCoverExpiryDate;
	
	@FindBy(xpath ="//input[@value='Cancel']")
    private WebElement btnCancel;
	
	/**		    
	    *   Application Page : Printing Tab
	    */
	
	@FindBy(linkText="Block printouts")
	private WebElement lnkBlockPrintouts;
	
	@FindBy(linkText="Printouts")
	private WebElement lnkPrintouts;
	
	@FindBy(name="indexedPrintChosen[0]")
	private WebElement chkPolicyChangeRequest;
	
	@FindBy(linkText="Policy Change Request")
	private WebElement lnkPolicyChangeRequest;
	
	@FindBy(linkText="Print the health declaration")
	private WebElement lnkPrintHD;
	
	@FindBy(name="indexedPrintChosen[0]")
	private WebElement chkHDForm;
	
	@FindBy(name = "reject")
    private WebElement btnReject;
	
	@FindBy(xpath ="//input[@value='Return']")
    private WebElement btnReturn;
	
	@FindBy(name="submit")
	private WebElement btnSubmit;
	
	@FindBy(linkText="Annual development of cover premiums")
	private WebElement lnkAnnualDevCoverPremiums;
	
	@FindBy(xpath ="//input[@value='Accept']")
	private WebElement btnAccept;

	@FindBy(linkText="View Details")
	private WebElement lnkViewDetails;
	
	@FindBy(name="indexedFieldPaymentQuantityPA[0]")
	private WebElement txtNumberYear;
	
	@FindBy(xpath="//input[@name='beneficiaryDelete[0]']")
	private WebElement btndeletebeneficiary;	
	
	@FindBy(xpath="//input[@name='durationMonths']")
	private WebElement txtDurationMonths;	
	
	@FindBy(xpath="//input[@value='Count start and end date']")
	private WebElement btnCountStartEndDate;	

	@FindBy(xpath="//input[@value='Save']")
	private WebElement btnSave;	
	
	@FindBy(xpath="//input[@name='calculate']")
	private WebElement btnCalculate;
	
	@FindBy(name="submit")
	private WebElement btnYes;
	
	@FindBy(xpath= "//div[@class='commentbox']")
	private WebElement commentBox;
	
	@FindBy(xpath="//div[@class='errorbox']")
	private WebElement errorBox;
	
	public ChangeCalculation() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	/**
	 * Methods for ALL
	 */

	public void clickAdd(){
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(btnAdd, 30);
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAdd, "Add");
	}
	
	public void clickChangeCover() throws InterruptedException{
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(lnkChangeCover, 5);
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkChangeCover, "Change of cover");
		Context.global().getSeleniumUtils().waitForPageToLoad(10);
	}
	
	public void clickChangeRepaymentPlan(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkChangeRepaymentPlan, "Change of repayment plan");
	}
	
	 public void clickContinue(){
		    Context.global().getSeleniumUtils().clickOnElement(this.btnContinue, "Continue");
	    }
	/**
	 * Methods for Covers tab
	 */
	
	public void setCoverEffectiveDate(String coverEffectiveDate) {
		Context.global().getSeleniumUtils().clearText(this.txtCoverEffectiveDate, "Cover Effective Date");
		Context.global().getSeleniumUtils()
				.enterText(this.txtCoverEffectiveDate, "Cover Effective Date",coverEffectiveDate);
	}
	
	public String getCoverEffectiveDate() {
		return Context.global().getSeleniumUtils()
				.getAttributeValue(this.txtCoverEffectiveDate, "value");
	}
	
	public void setCoverExpiryDate(String coverExpiryDate) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtCoverExpiryDate, "Cover Expiry Date", coverExpiryDate);
	}
	
	public String getCoverExpiryDate() {
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(txtCoverExpiryDate, 5);
		return Context.global().getSeleniumUtils()
		.getAttributeValue(this.txtCoverExpiryDate, "value");
	}
	
	public void clickCancel() {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCancel, "cancel");
    }
	
	/**
	 * Methods for Printing tab
	 */
	
	public void clickblockPrintouts(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkBlockPrintouts, "BlockPrintouts");
	}
	
	
	public void clickPrintouts(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkPrintouts, "Printouts");
	}
	
    
    public void checkPolicyChangeRequest(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.chkPolicyChangeRequest, "Policy Change Request");
	}
    
    public void clickPolicyChangeRequestLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkPolicyChangeRequest, "Printouts");
	}
    
    public void clickPrintHD(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkPrintHD, "Print Health Declaration Link");
	}
    
    public void checkHD(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.chkHDForm, "Health Declaration Form");
	}
    
    
    public void clickReject() {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnReject, "reject");
    }
	
	public void clickReturn() {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnReturn, "return");
    }
	
	public void clickEdit(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnSubmit, "Edit");
	}

	public void clickAnnualDevCoverPremiums(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkAnnualDevCoverPremiums, "Annual Development Of Cover Premiums");
	}

	
	public void clickAccept(){
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(btnAccept, 30);
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAccept, "Accept");
	}
	
	
	public void clickViewDetails(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkViewDetails, "View Details");
	}
	
	public void setFrequency(String frequency) {
		Context.global().getSeleniumUtils().clearText(this.txtNumberYear, "Frequency");
		Context.global().getSeleniumUtils()
				.enterText(this.txtNumberYear, "Frequency", frequency);
	}
	
	public WebElement getTable() {
		return table;
	}

    public void clickdeletebeneficiary() {
    	Context.global().getSeleniumUtils().clickOnElement(this.btndeletebeneficiary, "Delete Beneficiary");
    }
    
    public int getDurationMonths() {
    	return Integer.parseInt(Context.global().getSeleniumUtils().getAttributeValue(this.txtDurationMonths, "value"));
    }
    
    public void setDurationMonths(String durationMonths) {
    	Context.global().getSeleniumUtils().clearText(this.txtDurationMonths, "Duration Months");
    	Context.global().getSeleniumUtils()
		.enterText(this.txtDurationMonths, "Duration Months",durationMonths);
    }
	
    public void clickCountStartEndDate() {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCountStartEndDate, "Count Start And End Date");
    }
    
    public void clickSave() {
    	Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(btnSave, 5);
    	Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "Save");
    }
    
    public void clickCalculate() throws InterruptedException {
    	Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(btnCalculate, 5);
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCalculate, "Calculate");
    	Context.global().getSeleniumUtils().waitForPageToLoad(10);
    }
    
	public void clickYes(){
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(btnYes, 5);
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnYes, "Yes");
	}
	
	public String fetchChangeCalcID() {
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(commentBox, 5);
		Context.global().getSeleniumUtils().enterText(commentBox, "Calculation ID", "");
		return Context.local().getBatchUtilityFunction().fetchBatchID(Context.global().getSeleniumUtils().getText(commentBox));		
	}
	
	public WebElement getCommentBox() {
		return commentBox;		
	}
	
	public WebElement getErrorBox() {
		return errorBox;		
	}
	
	public String getErrorBoxMessage() {
		return Context.global().getSeleniumUtils().getText(errorBox);	
	}
	
	@Override
	public void verifyPageState() {
		// 
	}
	
}
	
