package com.nordea.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;


/** 
 * Description: This page contains web elements and methods for complete flow of offer creation for different product
 * Navigating to this page by clicking on 'offer' tabs in the LHN 
 * 
 * 
 * Naming convention guidelines
 * PageName+WebElementName  
 * DB=Death Benefit
 * PD=Permanent Disability
 * PAH=Permanent Accidental Handicap
 * CI=Critical Illness 
 * Functionality			 	: Will be called as per requirement.
 * Functionality Created By  	: Snehal Bahulekar
 * Reviewed By                 	: Mithen Kadam
 * Review Date                	: 27/12/2016
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017 
*/

public class OfferBasicPage extends LHN implements Page  {
		
		/**
		 * Application Page : Basic Tab
		 */
	
	    @FindBy(xpath = "//input[@name='indexedFieldSellerPartyName[0]']")
	    private WebElement txtBasicSalesPersonName;
	    
	    @FindBy(name = "indexedFieldSellerPartyIdentifier[0]")
	    private WebElement txtBasicSalesPersonId;
	    
	    @FindBy(xpath = "//input[@name='indexedFieldSellerPartyIdentifier[1]']")
	    private WebElement txtBasicBranchOfficeId;
	    
	    @FindBy(xpath = "//input[@name='findSellerParty[0]']")
	    private WebElement btnBasicSalesPersonNameFind;
	    
	    @FindBy(xpath = "//input[@name='findSellerParty[1]']")
	    private WebElement btnBasicBranchOfficeFind;	    
	      
	    @FindBy(name = "addRepresentative")
	    private WebElement btnAddRepresentative;
	   		    
	    @FindBy(name = "fieldNames[1]")
	    private WebElement txtName;
	    
	    @FindBy(name = "indexedFieldIdentityNumber[1]")
	    private WebElement txtIdentifier;
	    
	    @FindBy(name = "nameSearch")
	    private WebElement btnFindName;
	    
	    @FindBy(name = "identifierSearch")
	    private WebElement btnIdentifier;
	    
	    @FindBy(name="indexedFieldCredentialLevel[1]")
	    private WebElement drpAuthorizationlevel;    
	    		    		    
	    @FindBy(name = "addPayer")
	    private WebElement btnAddPayer;
	    
	    @FindBy(name="payerName")
	    private WebElement txtPayerName;	   
	    
	    @FindBy(name = "payerIdentifier")
	    private WebElement txtPayerIdentifier;
	    
	    @FindBy(name = "findPayerByIdentifier")
	    private WebElement btnFindPayerIdentifier;
	    
	    @FindBy(name = "findPayerByName")
	    private WebElement btnFindPayerName;
	   
	    @FindBy(name="pledge")
	    private WebElement btnBasicPledging;
	    
	    @FindBy(name="savePledging")
	    private WebElement btnCustomerLoansSave;
	    
	    @FindBy(name = "firstPaymentDueDate")
	    private WebElement txtFirstPaymentDueDate;
	    
	    @FindBy(name = "offerEffectiveDate")
	    private WebElement txtOfferEffectiveDate;
	    
	    @FindBy(name = "offerExpiryDate")
	    private WebElement txtOfferExpiryDate;
	    
	    @FindBy(name = "customershipGroupCode")
	    private WebElement drpCustomershipGroup;
	    
	    @FindBy(name = "nlfCustomershipGroup")
	    private WebElement drpNLFCustomershipGroup;
	    
	    @FindBy(name = "policyExpiryDate")
	    private WebElement txtPolicyExpDate;
	       
	    @FindBy(xpath = "//input[@name='continue']")
	    private WebElement btnCoverContinue;
	    
	    @FindBy(xpath = "//div[@class='errorbox']")
	    private WebElement eleErrorBox;
	    
	    @FindBy(xpath = "//div[@class='commentbox']")
	    private WebElement eleCommentBox;
	    
	    
	    public OfferBasicPage() {
	        PageFactory.initElements(Context.global().getDriver(), this); 
	    }
	    
	    
	    /**
	     * Methods for Basic Tabs
	     */
	    
	    public void setSalesPerson(String salesPerson){
	    	Context.global().getSeleniumUtils().enterText(this.txtBasicSalesPersonName, salesPerson, "SalesPersonName");
	    }
	    
	    public void setSalesPersonId(String basicSalesPersonId) {
	    	Context.global().getSeleniumUtils().enterText(this.txtBasicSalesPersonId, "SalesPersonID", basicSalesPersonId);
	    }
	    
	    public void setBranchOfficeId(String branchOffice){
		    Context.global().getSeleniumUtils().enterText(this.txtBasicBranchOfficeId, "BranchOfficeId", branchOffice);
	    }
	    public void clickSalesPersonNameFind(){
		    Context.global().getSeleniumUtils().clickOnElement(this.btnBasicSalesPersonNameFind, "SalesPersonNameFind");
	    }
	    public void clickBranchOfficeFind(){
		    Context.global().getSeleniumUtils().clickOnElement(this.btnBasicBranchOfficeFind, "BranchOfficeFind");
	    }
	    
	    public void clickAddRepresentative() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnAddRepresentative, "Add Representative button");	    	
	    }	    
	    
	    public void setName(String representativeName){
	    	Context.global().getSeleniumUtils().enterText(this.txtName,representativeName, "Name field");
    	}	
	    
	    public void setIdentifier(String representativeIdentifier){
	    	Context.global().getSeleniumUtils().enterText(this.txtIdentifier,representativeIdentifier, "Identifier field");
    	}
	    
	    public void clickFindName() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnFindName, "Find Name");	    	
	    }
	    
	    public void clickFindIdentifier() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnIdentifier, "Find Identifier");	    	
	    }
	    
	    public void clickAuthorizationLevelDropdown(String addAuthorizationDropdownValue){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpAuthorizationlevel, "visibleText", addAuthorizationDropdownValue);
	    }
	    
	    public void setPayerName(String payerName){
	    	Context.global().getSeleniumUtils().enterText(this.txtPayerName,payerName, "Payer field");
    	}
	    
	    public void setPayerIdentifier(String payerIdentifier){
	    	Context.global().getSeleniumUtils().enterText(this.txtPayerIdentifier,payerIdentifier, "Identifier field");
    	}
	    
	    public void clickFindPayerIdentifier() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnFindPayerIdentifier, "Find button");	    	
	    }
	   
	    public void clickFindPayerName() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnFindPayerName, "Find button");	    	
	    }
	    
	    public void clickAddPayer() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnAddPayer, "Add Payer button");	    	
	    }	    
	    	    	    
	    public void clickBasicPledging() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnBasicPledging, "pledge button");	    	
	    }
	    
	    public boolean verifyPledgingButton() {
	    	return Context.global().getSeleniumUtils().verifyElementPresent(this.btnBasicPledging, "pledge button");
	    	
	    }
	    
	    
	    public void clickCustLoansSave() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnCustomerLoansSave, "save Pledging button");	    	
	    }	 
	    	
	    public void setFirstPaymentDueDate(String firstPaymentDueDate){
	    	Context.global().getSeleniumUtils().enterText(this.txtFirstPaymentDueDate,firstPaymentDueDate, "First Premium Due Date field");
    	}
	   	   
	    public void setOfferEffectiveDate(String offerEffectiveDate){
	    	Context.global().getSeleniumUtils().enterText(this.txtOfferEffectiveDate,offerEffectiveDate, "Effective Date field");
    	}
	    
	    public void setOfferExpieryDate(String offerExpiryDate){
	    	Context.global().getSeleniumUtils().enterText(this.txtOfferExpiryDate,offerExpiryDate, "Expiry Date field");
    	}
	    
	    public void clickCustomershipGroupCodeDropdown(String customerShipGroup){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpCustomershipGroup, "visibleText", customerShipGroup);
	    }
	    
	    public void clickNLFCustomershipGroupDropdown(String nlfCustomerShipGroup){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpNLFCustomershipGroup, "visibleText", nlfCustomerShipGroup);
	    }
	    	       
	    
	    public void setPolicyExpDate(String policyExpDate){
	    	Context.global().getSeleniumUtils().enterText(this.txtPolicyExpDate,policyExpDate, "Policy End Date field");
    	}
	    
	    public void clickContinue(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnCoverContinue, "Continue");
	    }
	    
	    public boolean verifyErrorBox(){
	    	return Context.global().getSeleniumUtils().verifyElementPresent(this.eleErrorBox, "Error box");
	    }
	      
	    public String fetchErrorText(){
	    	return Context.global().getSeleniumUtils().getText(this.eleErrorBox);
	    }
	    	    
	    public boolean verifyCommentBox(){
	    	return Context.global().getSeleniumUtils().verifyElementPresent(this.eleCommentBox, "Error box");
	    }
	    
	    public String fetchCommentText(){
	    	return Context.global().getSeleniumUtils().getText(this.eleCommentBox);
	    }
	    
	    
		@Override
		public void verifyPageState() {
			//
		}
}
