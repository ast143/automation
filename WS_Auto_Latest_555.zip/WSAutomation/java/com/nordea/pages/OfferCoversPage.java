package com.nordea.pages;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;


/** 
 * Description: This page contains web elements and methods for complete flow of offer creation for different product
 * Navigating to this page by clicking on 'offer' tabs in the LHN 
 * 
 * 
 * Naming convention guidelines
 * PageName+WebElementName  
 * DB=Death Benefit
 * PD=Permanent Disability
 * PAH=Permanent Accidental Handicap
 * CI=Critical Illness 
 * Functionality			 	: Will be called as per requirement.
 * Functionality Created By  	: Snehal Bahulekar
 * Reviewed By                 	: Mithen Kadam
 * Review Date                	: 27/12/2016
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017
*/

public class OfferCoversPage extends LHN implements Page  {
		/**		    
	    *   Application Page : Covers Tab
	    */
	    
	    @FindBy(xpath = "//a[text()='Death benefit']")
	    private WebElement lnkCoverDB;
	    
	    @FindBy(xpath = "//a[text()='Permanent disability']")
	    private WebElement lnkCoverPD;
	    
	    @FindBy(xpath = "//a[text()='Permanent accidental handicap']")
	    private WebElement lnkCoverPAH;
	    
	    @FindBy(xpath = "//a[text()='Critical illness']")
	    private WebElement lnkCoverCI;
	    
	    @FindBy(xpath = "//a[contains(text(),'Death cover (savings)')]")
	    private WebElement lnkCoverDCS;
	    
	    @FindBy(xpath = "//a[text()='Critical illness']/../../td[11]/input")
	    private WebElement eleDeleteCoverCI;
	    
	    @FindBy(xpath = "//a[text()='Permanent accidental handicap']/../../td[11]/input")
	    private WebElement eleDeleteCoverPAH;
	    
	    @FindBy(xpath = "//a[text()='Permanent disability']/../../td[11]/input")
	    private WebElement eleDeleteCoverPD;
	    
	    @FindBy(xpath = "//a[text()='Death benefit']/../../td[11]/input")
	    private WebElement eleDeleteCoverDB;
	    
	    @FindBy(xpath = "//a[text()='Death or permanent disability caused by an accident, Private']/../../td[11]/input")
	    private WebElement eleDeleteCoverDPDCAP; 
	   
	    @FindBy(xpath = "//a[text()='Death or permanent disability caused by an accident, Private']/../../td[10]//tr")
	    private List<WebElement> eleDPDCAPBenificiaryList;
	    
	    @FindBy(xpath = "//a[text()='Death or permanent disability caused by an accident, Corporate']/../../td[10]//tr")
	    private List<WebElement> eleDPDCACBenificiaryList;
	    
	    @FindBy(xpath = "//a[text()='Death or permanent disability caused by an accident, Corporate']/../../td[11]/input")
	    private WebElement eleDeleteCoverDPDCAC;
	    
	    @FindBy(name = "coverDelete[0]")
	    private WebElement eleDeleteCoverSC;
	    
	    @FindBy(name = "coverDelete[1]")
	    private WebElement eleDeleteCoverDCS;
	    
	    @FindBy(linkText = "Savings capital")
	    private WebElement lnkSavingCapitalCover;
	    
	    @FindBy(linkText = "Death cover (savings)")
	    private WebElement lnkDeathSavingCover;
	    
	    @FindBy(name = "firstPremiumAmount")
	    private WebElement txtFirstPremiumAmount;
	    
	    @FindBy(xpath = "//input[@name='coverAmount']")
	    private WebElement txtCoverAmount;
	    
	    @FindBy(xpath = "//input[@name='premiumAmount']")
	    private WebElement txtCoverPremiumAmount;
	    
	    @FindBy(xpath = "//input[@name='calculatePremium']")
	    private WebElement btnCoverCalculate;
	    
	    @FindBy(xpath = "//input[@name='coverAddBeneficiary']")
	    private WebElement btnCoverAddBeneficiary;
	    
	    @FindBy(xpath = "//input[@name ='beneficiaryAdd']")
	    private WebElement btnCoverAddBeneficiaryAdd;
	    
	    @FindBy(xpath = "//select[@name='addedBeneficiaryCode']")
	    private WebElement drpCoverAddBeneficiary;
	    
	    @FindBy(name = "freeText")
	    private WebElement txtFreeText;
	    	    
	    @FindBy(xpath = "//input[@name='continue']")
	    private WebElement btnContinue;
		   	    
	    @FindBy(name="coverBindingMethodCode")
	    private WebElement drpCoverBindingMethod;
	    
	    @FindBy(name="decreasedAmount")
	    private WebElement txtDecreasedAmount;
	    
	    @FindBy(name = "beneficiaryCancel")
	    private WebElement btnBeneficiaryCancel;
	    
	    @FindBy(name = "coverCancel")
	    private WebElement btnCoverCancel;
	    
	    @FindBy(name = "beneficiaryIdentifier")
	    private WebElement txtNamedBenificiarycode;
	    
	    @FindBy(name = "beneficiaryName")
	    private WebElement txtNamedBenificiaryName;
	    
	    @FindBy(name = "namedBenefiarySpec")
	    private WebElement txtNamedBenificiaryDesc;
	    
	    @FindBy(name = "findBeneficiaryByIdentifier")
	    private WebElement btnFindBeneficiaryCode;
	    
	    @FindBy(name = "findBeneficiaryByName")
	    private WebElement btnFindBeneficiaryName; 
	    	    
	    @FindBy(id = "smoker.yes")
		private WebElement rdbCoverSmokeYes;
	    
	    @FindBy(id = "smoker.no")
		private WebElement rdbCoverSmokeNo;
	    
	    @FindBy(xpath = "//a[text()='Death or permanent disability caused by an accident, Private']")
	    private WebElement lnkCoverDeathorPDbyAccidentPrivate;
	    
	    @FindBy(xpath="//th[contains(text(),'Cover Type')]/../..//td/select[@name='addedAccidentalEventType']")
	    private WebElement drpCoverType;
	    
	    @FindBy(xpath="//th[contains(text(),'Turvalaji')]/../..//td/select[@name='addedAccidentalEventType']")
	    private WebElement drpCoverTypeinFinnish;
	    
	    @FindBy(xpath="//th[contains(text(),'Skyddsslag')]/../..//td/select[@name='addedAccidentalEventType']")
	    private WebElement drpCoverTypeinSwedish;
	  
	    @FindBy(xpath = "//a[text()='Death or permanent disability caused by an accident, Corporate']")
	    private WebElement lnkCoverDeathorPDbyAccidentCorporate;
	    
	    @FindBy(xpath = "//input[@value='Add cover']")
	    private WebElement btnAddCover;

	    @FindBy(name = "coverPercent")
	    private WebElement txtCoverPercent;
	    
	    @FindBy(id = "c1")
	    private WebElement chkInheritanceCover;
	    
	    @FindBy(name = "addedCoverCode")
	    private WebElement drpAddCover;   
	    
	    @FindBy(name = "beneficiaryDelete[0]")
	    private WebElement eleBeneficiaryDelete;
	    
	    @FindBy(xpath = "//input[@value='Save']")
	    private WebElement btnSave;
	    
	    @FindBy(xpath= "//div[@class='commentbox']")
	    private WebElement eleCampaignMsg;
	    
	    @FindBy(id = "smoker.no")
	    private WebElement rbdSmokerNo;
	    
	    @FindBy(id = "smoker.yes")
	    private WebElement rbdSmokerYes;
	    
	    @FindBy(name = "newAdd")
	    private WebElement btnAddInsured;
	    
	    @FindBy(name = "insuredIdentifier")
	    private WebElement txtInsuredIdentifier;
	    
	    @FindBy(name = "findInsuredByIdentifier")
	    private WebElement btnFindInsuredIdentifier;
	    
	    @FindBy(name = "coverAdd")
	    private WebElement btnAddCoverCorporate;
	    
	    @FindBy(xpath = "//input[@value='Add']")
	    private WebElement btnAdd;
	    
	    public OfferCoversPage() {
	        PageFactory.initElements(Context.global().getDriver(), this); 
	    }
	    
	    
	    public void clickDB(){
		    Context.global().getSeleniumUtils().clickOnElement(this.lnkCoverDB, "Death Benefit");
	    }
	    public void clickPD(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.lnkCoverPD, "Permanent Disability");
	    }
	    public void clickPAH(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.lnkCoverPAH, "Permanent Accidental Handicap");
	    }
	    public void clickCI(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.lnkCoverCI, "Critical Illness");
	    }
	    public void clickDCS(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.lnkCoverDCS, "Death Cover Savings");
	    }
	    
	    public void deleteBeneficiary(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.eleBeneficiaryDelete, "delete Beneficiary");
	    }
	    
	    public void deletePD(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverPD, "delete PD");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.eleDeleteCoverPD, "delete PD icon")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverPD, "delete PD");
	    	}	    	
	    }
	    public void deletePAH(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverPAH, "delete PAH");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.eleDeleteCoverPAH, "delete PAH")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverPAH, "delete PAH");
	    	}
	    }	   
	    public void deleteCI(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverCI, "delete CI");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.eleDeleteCoverCI, "delete CI icon ")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverCI, "delete CI");
	    	}	    	
	    }	    
	    public void deleteDB(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverDB, "delete DB");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.eleDeleteCoverDB, "delete DB icon")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverDB, "delete DB");
	    	}
	    	
	    }
	    public void deleteSC(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverSC, "delete SC");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.eleDeleteCoverSC, "delete SC")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverSC, "delete SC");
	    	}
	    }
	    public void deleteDCS(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverDCS, "delete SC");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.eleDeleteCoverDCS, "delete SC")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverDCS, "delete SC");
	    	}
	    }
	    public void deleteDPDCAP(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverDPDCAP, "delete DPDCAP");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.eleDeleteCoverDPDCAP, "delete DPDCAP")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverDPDCAP, "delete DPDCAP");
	    	}
	    }	    
	    	    
	    public void deleteDPDCAC(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverDPDCAC, "delete DPDCAC");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.eleDeleteCoverDPDCAC, "delete DPDCAC")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.eleDeleteCoverDPDCAC, "delete DPDCAC");
	    	}
	    }
	    	    
	    public void clickContinue(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnContinue, "Continue");
	    }
	    public void setCoverAmount(String coverCoverAmount){
	    	Context.global().getSeleniumUtils().clearText(this.txtCoverAmount, "CoverAmount");
	    	Context.global().getSeleniumUtils().enterText(this.txtCoverAmount, "CoverAmount", coverCoverAmount);
    	}
	    public void setPremiumAmount(String coverPremiumAmount){
	    	Context.global().getSeleniumUtils().enterText(this.txtCoverPremiumAmount, coverPremiumAmount, "PremiumAmount");
    	}
	    public void clickCalcPremiumAmount(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnCoverCalculate, "CalcPremiumAmount");
	    }
	    public void clickAddBeneficiary(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnCoverAddBeneficiary, "AddBeneficiary");
	        if(Context.global().getSeleniumUtils().verifyElementPresent(this.btnCoverAddBeneficiary, "AddBeneficiary")){
	        	Context.global().getSeleniumUtils().clickOnElement(this.btnCoverAddBeneficiary, "AddBeneficiary");
	        }
	    }
	   
	    public void selectAddBeneficiary(String beneficiary){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpCoverAddBeneficiary, "visibleText", beneficiary);
	    }
	    public void setFreeTextGroupName(String freeTextGroupName){
	    	Context.global().getSeleniumUtils().enterText(this.txtFreeText, "Free Text Group Name", freeTextGroupName);
	    }
	    public void clickAddBeneficiaryAdd(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnCoverAddBeneficiaryAdd, "AddBeneficiaryAdd");
	    }	   	    
	   
		public void selectCoverBindingMethod(String addCoverBindingMethod){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpCoverBindingMethod, "visibleText", addCoverBindingMethod);
	    }
	        	
		 public void setDecreasedAmount(String decreasedAmount){
			 	Context.global().getSeleniumUtils().clearText(this.txtDecreasedAmount, "Decreased Amount field");
		    	Context.global().getSeleniumUtils().enterText(this.txtDecreasedAmount,"Decreased Amount field",decreasedAmount );
	    } 
	        	    
	    public void setFreetext(String freetext){
	    	Context.global().getSeleniumUtils().enterText(this.txtFreeText,"freeText",freetext );
    	}
	    
	    public void clickBeneficiaryCancel() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnBeneficiaryCancel, "beneficiary Cancel button");	    	
	    }	
	    
	    public void clickCoverCancel() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnCoverCancel, "cover Cancel button");	    	
	    }
	    
	    public void setNamedBenificiaryCode(String namedBenificiaryCode){
	    	Context.global().getSeleniumUtils().enterText(this.txtNamedBenificiarycode,"beneficiaryIdentifier", namedBenificiaryCode);
    	}
	    
	    public void setNamedBenificiaryName(String namedBenificiaryName){
	    	Context.global().getSeleniumUtils().enterText(this.txtNamedBenificiaryName,"beneficiaryName", namedBenificiaryName);
    	}   
	    
	    public void setNamedBenificiaryDesc(String namedBenificiaryDescription){
	    	Context.global().getSeleniumUtils().enterText(this.txtNamedBenificiaryDesc,"namedBenefiarySpec", namedBenificiaryDescription);
    	}   
	    
	    public void clickBeneficiaryCodeFind() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnFindBeneficiaryCode, "beneficiary by code Find button");	    	
	    }
	    
	    public void clickBeneficiaryNameFind() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnFindBeneficiaryName, "beneficiary by Name Find button");	    	
	    }
	    
	    public void clickSmokerYes(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.rdbCoverSmokeYes, " Yes radio button");
	    }
	    
	    public void clickSmokerNo(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.rdbCoverSmokeNo, "No radio button");
	    }
	    	    
	    public void clickDeathorPDbyAccidentPrivate() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.lnkCoverDeathorPDbyAccidentPrivate, "Death or Permanent Disablity by Accident,Private link");
	    }
	    
	    public void clickDeathorPDbyAccidentCorporate() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.lnkCoverDeathorPDbyAccidentCorporate, "Death or Permanent Disablity by Accident,Corporate link");
	    }
	    
	    public boolean isDPDCAPDisplayed(){
	    	return Context.global().getSeleniumUtils().verifyElementPresent(this.lnkCoverDeathorPDbyAccidentPrivate, "Death or Permanent Disablity by Accident,Private link");
	    }
	    
	    public boolean isDPDCACDisplayed(){
	    	return Context.global().getSeleniumUtils().verifyElementPresent(this.lnkCoverDeathorPDbyAccidentCorporate, "Death or Permanent Disablity by Accident,Corporate link");
	    }
	    
        public boolean isCoverTypeDropdownDisplayed(){
        	return Context.global().getSeleniumUtils().verifyElementPresent(this.drpCoverType,"Cover Type Dropdown");
	    }
        
        public boolean isCoverTypeDropdownDisplayedinFinnish(){
        	return Context.global().getSeleniumUtils().verifyElementPresent(this.drpCoverTypeinFinnish,"Cover Type Dropdown in Finnish");
	    }
        
        public boolean isCoverTypeDropdownDisplayedinSwedish(){
        	return Context.global().getSeleniumUtils().verifyElementPresent(this.drpCoverTypeinSwedish,"Cover Type Dropdown in Swedish");
	    }
        
        public String fetchSelectedOptionCoverTypeDropdown(){
        	return Context.global().getSeleniumUtils().getSelectedOptionfromDropdown(this.drpCoverType,"Cover Type Dropdown Default Value");
	    }
        
        public String fetchSelectedOptionCoverTypeDropdownFinnish(){
        	return Context.global().getSeleniumUtils().getSelectedOptionfromDropdown(this.drpCoverTypeinFinnish,"Cover Type Dropdown Default Value Finnish");
	    }
        
        public String fetchSelectedOptionCoverTypeDropdownSwedish(){
        	return Context.global().getSeleniumUtils().getSelectedOptionfromDropdown(this.drpCoverTypeinSwedish,"Cover Type Dropdown Default Value Swedish");
	    }
        
        public List<String> fetchAllOptionsCoverTypeDropdown(){
        	return Context.global().getSeleniumUtils().getAllOptionsfromDropdown(this.drpCoverType,"Cover Type Dropdown");
	    }
        
        public List<String> fetchAllOptionsCoverTypeDropdownFinnish(){
        	return Context.global().getSeleniumUtils().getAllOptionsfromDropdown(this.drpCoverTypeinFinnish,"Cover Type Dropdown Finnish");
	    }
        
        public List<String> fetchAllOptionsCoverTypeDropdownSwedish(){
        	return Context.global().getSeleniumUtils().getAllOptionsfromDropdown(this.drpCoverTypeinSwedish,"Cover Type Dropdown Swedish");
	    }
	      	            
	    public void selectCoverType(String addCoverTypeValue){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpCoverType, "visibleText", addCoverTypeValue);
	    }
	  
	    public void clickAddCover() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnAddCover, "AddCover button");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.btnAddCover, "AddCover button")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.btnAddCover, "AddCover button");
	    	}
	    }
	    
	    public boolean verifyAddCoverButtonPresent(){
	    	return Context.global().getSeleniumUtils().verifyElementPresent(btnAddCover, "Add cover button");
	    }	    
	    
	    public void setCoverPercent(String coverPercent){
	    	Context.global().getSeleniumUtils().enterText(this.txtCoverPercent,"Cover Percent field", coverPercent);
    	}  
	   	   
	    public void clickInheritanceCover(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.chkInheritanceCover, "Inheritance Cover checkbox");
	    }
	    
	    public void selectAddCover(String addCoverValue){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpAddCover, "visibleText", addCoverValue);
	    }
	    
	    public void clickSavingCapitalCover() {
	    	Context.global().getSeleniumUtils().clickOnElement(lnkSavingCapitalCover, "Saving Capital Cover");
	    }	    
	    public void clickDeathSavingCover() {
	    	Context.global().getSeleniumUtils().clickOnElement(lnkDeathSavingCover, "Death Saving Cover");
	    }
	    
	    public void setFirstPremiumAmount(String premiumAmount) {
	    	Context.global().getSeleniumUtils().clearText(this.txtFirstPremiumAmount, "First Premium Amount");
	    	Context.global().getSeleniumUtils().enterText(this.txtFirstPremiumAmount,  "First Premium Amount", premiumAmount);
	    } 
	   
	    public void clickSave(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "Save Button");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.btnSave, "Save Button")){
	    		Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "Save Button");
	    	}
	    }	    
	    
	    public boolean verifyCampaignMsg(){
	    	return Context.global().getSeleniumUtils().verifyElementPresent(this.eleCampaignMsg, "verifyCampaignMsg" );
	    }
	    
	    public void clickAddInsured() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnAddInsured, "AddInsured button");	    	
	    }
	    
	    public void setInsuredIdenfier(String insuredID){
	    	Context.global().getSeleniumUtils().enterText(this.txtInsuredIdentifier,"InsuredIdentifier field", insuredID);
    	}  
	    
	    public void clickFindInsuredIdentifier() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnFindInsuredIdentifier, "InsuredIdentifier Find button");	    	
	    }
	    
	    public void clickAddCoverCorporate() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnAddCoverCorporate, "Add Cover button");	    	
	    }
	    
	   
	    public void setSmokerStatus(String smokerStatus){
	    	if("NO".equalsIgnoreCase(smokerStatus)){
	    	Context.global().getSeleniumUtils().clickOnElement(this.rbdSmokerNo, "SmokerStatusNo");
	    	}
	    	else{
	    		Context.global().getSeleniumUtils().clickOnElement(this.rbdSmokerYes, "SmokerStatusYes");	
	    	}
	    }	
	    
		public List<String> fetchDPDCAPBeneficiaryList(){
	    	List<String> beneficiaryList = new ArrayList<String>();
	    	for(int i=0;i< this.eleDPDCAPBenificiaryList.size();i++){
	    		beneficiaryList.add(Context.global().getSeleniumUtils().getText(this.eleDPDCAPBenificiaryList.get(i)));
	    	}
	    	return beneficiaryList;
	    }
			
		public List<String> fetchDPDCACBeneficiaryList(){
	    	List<String> beneficiaryList = new ArrayList<String>();
	    	for(int i=0;i< this.eleDPDCACBenificiaryList.size();i++){
	    		beneficiaryList.add(Context.global().getSeleniumUtils().getText(this.eleDPDCACBenificiaryList.get(i)));
	    	}
	    	return beneficiaryList;
	    }
		
		public void clickAdd(){
		    	Context.global().getSeleniumUtils().clickOnElement(this.btnAdd, "Add button");	    	
		}
		
		@Override
		public void verifyPageState() {
			//
		}
}
