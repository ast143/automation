package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: The pages refers the elements till acceptance of surrender
 * 
 * 
 * Functionality Created By : Snehal Bahulekar
 * Reviewed By 				: Kapil Kapoor
 * Creation Date 			: 27/03/2017
 * Review Date 				: 04/04/2017
 * Modified By 				: Mithen Kadam
 * Last Modified Date 		: 21/04/2017
 * Reviewed By				: Poonam Joshi
 * Review Date				: 27/04/2017
 */

public class Surrender implements Page {
	
	@FindBy(name = "surrenderOrder")
	private WebElement drpEISurrenderOrder;
	
	@FindBy(name = "surrenderAmount")
	private WebElement txtEISurrenderAmount;	
	
	@FindBy(name="submit")
	private WebElement btnEICount;
	
	@FindBy(name="cancel")
	private WebElement btnEIReturn;
	
	@FindBy(xpath="//th[contains(text(),'Surrender amount')]/../td[1]")
	private WebElement elmEISurrenderAmount ;
	
	@FindBy(name="submitEventInsured")
	private WebElement btnEIAccept;
	
	@FindBy(name="cancelEventInsured")
	private WebElement btnCancelEIReturn;
	
	@FindBy(name="org.apache.struts.taglib.html.CANCEL")
	private WebElement btnClaimHandlingPopupNo;
	
	@FindBy(xpath="//th[contains(text(),'Insurance claim')]/a")
	private WebElement lnkClaimId;
	
	@FindBy(xpath="//tr[4]/th/a")
	private WebElement lnkSettlementId;
	
	public Surrender() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}

	
	public void selectSurrenderOrder(String drpdownValue) {
		Context.global()
				.getSeleniumUtils()
				.selectValueFromDropDown(drpEISurrenderOrder, "visibleText",
						drpdownValue);
	}
	
	public void setHandler(String surrenderAmount){
	    Context.global().getSeleniumUtils().enterText(this.txtEISurrenderAmount,surrenderAmount,"Surrender Amount" );
	}
	
	public void clickCount() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnEICount, "Event Insured Count");

	}
	public void clickReturn() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnEIReturn, "Event Insured Return");

	}
	
	public void fetchSurrenderAmount(){
	    Context.global().getSeleniumUtils().getText(this.elmEISurrenderAmount);
	}
	public void clickAccept() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnEIAccept, "Event Insured Accept");

	}
	public void clickEICancelReturn() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnCancelEIReturn, "Cancel Event Insured Return");

	}
	


	
	@Override
	public void verifyPageState() {

		
	}

	
	
	

}


