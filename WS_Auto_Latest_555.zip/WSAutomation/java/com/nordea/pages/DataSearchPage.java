package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.page.components.CopyCustomerToLISPopup;
import com.nordea.page.components.LHN;


/** 
 * DataSearchPage- This page has five searching fields
 * Customer ID, Name, Policy Number, Offer ID, Claim Number 
 * Navigating to this page after login to application 
 * 
 * Functionality Created By  	: Debabrata Behera
 * Reviewed By                 	: Kapil Kapoor
 * Review Date                	: 16/01/2017
 * Modified By 				   	: Kapil Kapoor (Correcting Naming Convention & Giving definition to the page)
 * Last Modified Date        	: 16/01/2017
 * Reviewed By					: Nitesh Khanna
 * Review Date					: 17/01/2017
*/

public class DataSearchPage extends LHN implements Page {

	@FindBy(id = "NordeaSearchType1")
	private WebElement rdbCustomerSearch;
	
	@FindBy(id = "NordeaSearchCriteria1")
	private WebElement txtCustomerSearch;
	
	@FindBy(id = "NordeaSearchType2")
	private WebElement rdbNameSearch;
	
	@FindBy(id = "NordeaSearchCriteria2")
	private WebElement txtNameSearch;
	
	@FindBy(id = "NordeaSearchType3")
	private WebElement rdbPolicyNumberSearch;
	
	@FindBy(id = "NordeaSearchCriteria3")
	private WebElement txtPolicyNumber;
	
	@FindBy(id = "NordeaSearchType4")
	private WebElement rdbOfferID;
	
	@FindBy(id = "NordeaSearchCriteria4")
	private WebElement txtOfferID;
	
	@FindBy(id = "NordeaSearchType5")
	private WebElement rdbClaimNumberSearch;
	
	@FindBy(id = "NordeaSearchCriteria5")
	private WebElement txtClaimNumberSearch;
	
	@FindBy(xpath = "//input[@value = 'Find']")
	private WebElement btnFind;
	
	@FindBy(linkText="Interested parties")
	private WebElement lnkInterestedParties;
	
	@FindBy(linkText="Holder")
	private WebElement lnkHolder;
	
	@FindBy(linkText="Data search")
	private WebElement lnkDataSearch;
	
	@FindBy(linkText = "Event insured")	//mayank
	private WebElement lnkEventInsured;
	
	@FindBy(linkText = "Mode's manual change")	//mayank
	private WebElement lnkModesmanualchange;
	
	@FindBy(name= "mode")	//mayank
	private WebElement drpModeManualChangeState;
	
	@FindBy(name= "end")	//mayank
	private WebElement txtEndDate;
	
	@FindBy(name= "Terminated")	//mayank
	private WebElement lnkTerminated;
	
	//@FindBy(xpath = "//h2")
	//private WebElement title;
	

	public DataSearchPage() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}

	/*public String getTitle() {
		return Context.global().getSeleniumUtils()
				.getText(this.title);
	}*/
	
	public void clickTerminated(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkTerminated, "Terminated");
	}
	
	public void clickModesManualChange(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkModesmanualchange, "Data Search");
	}
	
	public void clickEventInsured(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEventInsured, "Data Search");
	}
	
	public void clickDataSearch(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkDataSearch, "Data Search");
	}
	
	public void clickInterestedParties(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkInterestedParties, "Interested Parties");
	}
	
	public void clickHolder(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkHolder, "Holder");
	}

	public void searchByCustomerID(String custId) throws Exception {
		Context.global()
				.getSeleniumUtils()
				.clickOnElement(this.rdbCustomerSearch,
						"Customer ID Search Radio Button");
		Context.global().getSeleniumUtils()
				.enterText(this.txtCustomerSearch, "Customer ID", custId);
		clickFind();
		Context.local().getPages().getPage(CopyCustomerToLISPopup.class).copyToLIS();
	}

	public void searchByName(String name) {
		Context.global()
				.getSeleniumUtils()
				.clickOnElement(this.rdbNameSearch,
						"Customer Name Search Radio Button");
		Context.global().getSeleniumUtils()
				.enterText(this.txtNameSearch, "Customer Name", name);
		clickFind();
	}

	public void searchByPolicy(String policy) {
		Context.global()
				.getSeleniumUtils()
				.clickOnElement(this.rdbPolicyNumberSearch,
						"Policy Search Radio Button");
		Context.global().getSeleniumUtils()
				.enterText(this.txtPolicyNumber, "Policy", policy);
		clickFind();
	}

	public void searchByOfferID(String offerId) {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.rdbOfferID, "Offer Search Radio Button");
		Context.global().getSeleniumUtils()
				.enterText(this.txtOfferID, "Offer ID", offerId);
		clickFind();
	}

	public void searchByClaimNumber(String claimNumber) {
		Context.global()
				.getSeleniumUtils()
				.clickOnElement(this.rdbClaimNumberSearch,
						"Claim Search Radio Button");
		Context.global()
				.getSeleniumUtils()
				.enterText(this.txtClaimNumberSearch, "Claim Number",
						claimNumber);
		clickFind();
	}

	public void clickFind() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnFind, "Find");
	}
@Override
	public void verifyPageState() {
	//
	}
	
}
