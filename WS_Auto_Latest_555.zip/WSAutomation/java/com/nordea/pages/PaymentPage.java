package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: Event View - This Page is for payment events. Payment are to be done through 
 * this page and can be verified from the same page.
 * Navigation to this page is by clicking on LHN >> Policy >> Events View
 * 
 * Abbreviations
 * VAEIC = View account events including cancelled
 * 
 * 
 * Functionality Created By  	: Kapil Kapoor
 * Reviewed By                 	: Debabrata Behera
 * Review Date                	: 24/04/2017
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017 
*/
public class PaymentPage implements Page {								
	
	@FindBy(linkText= "View events")									
	private WebElement lnkViewEvents;
	
	@FindBy(linkText= "View letters")									
	private WebElement lnkViewLetters;
	
	@FindBy(linkText= "Payment and accounting reporting")				
	private WebElement lnkPaymentAccntReport;
	
	@FindBy(linkText= "View payment events")							
	private WebElement lnkPaymentEvents;
					
	@FindBy(linkText= "View account events")							
	private WebElement lnkAccntEvents;
	
	@FindBy(linkText= "View account events including cancelled")		
	private WebElement lnkVAEIC;	
	
	@FindBy(linkText= "View policy summary")							
	private WebElement lnkPolicySummary;
	
	@FindBy(linkText= "Attribute history")								
	private WebElement lnkAttributeHistory;	
	
	@FindBy(linkText= "Event history")									
	private WebElement lnkEventHistory;
	
	/*Element under View payment event tab STARTS*/
	
	@FindBy(xpath= "//h2[contains(text(), 'Invoiced payments')]/../div[4]//tbody/tr/td[1]")
	private WebElement lnkPaymentDate;
	
	@FindBy(xpath= "//h2[contains(text(), 'Invoiced payments')]/../div[4]//tbody/tr/td[5]")
	private WebElement elmInvoiceMode;
	
	@FindBy(name= "resendPayment")
	private WebElement btnResendPayment;
	
	/*Elements under create premium button STARTS*/
	
	@FindBy(name= "create")
	private WebElement btnCreate;
	
	@FindBy(name= "searchAccountNumber")
	private WebElement btnSearchAccntNo;
	
	@FindBy(name= "//table/tbody/tr/td[1]")
	private WebElement lnkAccountNumber;
	
	@FindBy(name= "submit")
	private WebElement btnSave;
	
	@FindBy(name= "createPremium")
	private WebElement btnCreatePremium;
	
	@FindBy(name= "org.apache.struts.taglib.html.CANCEL")
	private WebElement btnCancel;
	
	@FindBy(name= "submit")
	private WebElement btnOk;
	
	/*Elements under create premium button ENDS*/	
	
	/*Elements under Cancel direct debit payment button STARTS*/
	
	@FindBy(name= "cancelPremium")
	private WebElement btnCancelPremium;	
	
	@FindBy(name= "submit")
	private WebElement btnYes;
	
	/*Elements under Cancel direct debit payment button ENDS*/
	
	/*Element under View payment event tab END*/
	
	/* Incoming Payment elements */
	
	@FindBy(linkText="Operations")
	private WebElement lnkOperations;
	
	@FindBy(xpath="//input[@value='Add']")
	private WebElement btnAdd;
	
	@FindBy(name="paymentDate")
	private WebElement txtPaymentDate;
	
	@FindBy(name="amount")
	private WebElement txtAmount;
	
	@FindBy(name="searchAccountNumber")
	private WebElement btnFindAccountNumber;
	
	
	@FindBy(name="policyNumberExternal")
	private WebElement txtPolicyNumber;
	
	@FindBy(xpath="//th[contains(text(),\"Invoicer's account\")]/../../following-sibling::tbody//a")
	private WebElement lnkInvoicerAccount;
	
	public PaymentPage(){
			PageFactory.initElements(Context.global().getDriver(), this);
	}
	
    public void clickViewEvents(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkViewEvents, "View events");
    }
	
    public void clickViewletters(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkViewLetters, "View letters");    	
    }
    
    public void clickPaymentAndAccountingReporting(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkPaymentAccntReport, "Payment and accounting reporting");  
    }
	
    public void clickViewPaymentEvents(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkPaymentEvents, "View payment events");  
    }
    
    public void clickViewAccountEvents(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkAccntEvents, "View account events");  
    }
    
    public void clickViewAccountEventsIncludingCancelled(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkVAEIC, "View account events including cancelled");
    }
    
    public void clickViewPolicySummary(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkPolicySummary, "View policy summary");
    }
    
    public void clickAttributeHistory(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkAttributeHistory, "Attribute History");
    }
    
    public void clickEventHistory(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkEventHistory, "Event History");
    }
    
    public void clickPaymentDate(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkPaymentDate, "Payment Date Link");
    }
    
    public String fetchInvoiceMode(){
    	return Context.global().getSeleniumUtils().getText(this.elmInvoiceMode);
    }
    
    public void clickResendPayment(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnResendPayment, "Resend Button");
    }
    
    public void clickCreatePremium(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCreate, "Create Premium");
    }
    
    public void clickFind(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnSearchAccntNo, "Find");
    }
    
    public void clickAccntNoLink(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkAccountNumber, "Nordea Account Number");
    }
    
    public void clickSave(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkAccountNumber, "Save");
    }
  
    public void clickSaveAndCreatePremium(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCreatePremium, "Save And Create Premium");
    }
    
    public void clickCancel(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCancel, "Cancel");
    }
    
    public void clickOk(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnOk, "Ok");
    }
    
    public void clickCancelDirectDebitPayment(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCancelPremium, "Cancel direct debit payment");
    }
    
    public void clickYes(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnYes, "Yes");
    }
    
    /* Incoming Payment element methods */
    
    public void clickOperations(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkOperations, "Operation link");
    }

    public void clickAdd(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnAdd, "Add");
    }
    
    public void setPaymentDate(String date){
    	Context.global().getSeleniumUtils().enterText(this.txtPaymentDate,"Date",date);
    }
    
    public void setAmount(String inPaymentAmount){
    	Context.global().getSeleniumUtils().clearText(this.txtAmount,"Amount");
    	Context.global().getSeleniumUtils().enterText(this.txtAmount,"Amount",inPaymentAmount);
    }
    
    public String getAmount(){
    	return Context.global().getSeleniumUtils().getAttribute(txtAmount, "value");
    }
    
    
    public void clickFindAccountNumber(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnFindAccountNumber, "Find Account Number");
    }
    
    public void setPolicyNumber(String policyNumber){
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyNumber,"Policy Number",policyNumber);
    }
   
    public void clickInvoicerAccountLink(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkInvoicerAccount,"Invoicer Account Number" );
    }
    

    @Override
	public void verifyPageState() {
		// TODO Auto-generated method stub
		
	}

}
