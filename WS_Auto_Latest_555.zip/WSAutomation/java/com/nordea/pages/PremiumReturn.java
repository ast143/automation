package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: The page refers the elements for premium return event till acceptance
 * 
 * 
 * Functionality Created By : Pavan Kadam
 * Reviewed By 				: Snehal Bahulekar
 * Review Date 				: 06/04/2017
 * Modified By 				: 
 * Last Modified Date		: 
 * Reviewed By 				: 
 * Review Date 				:
 */

public class PremiumReturn implements Page {

	@FindBy(name = "selectAll")
	private WebElement btnSelectAll;
	
	@FindBy(name = "abort")
	private WebElement btnAbort;
	
	@FindBy(name ="continue")
	private WebElement btnContinue;
	
	@FindBy(name = "eventType")
	private WebElement drpEventType;
	
	@FindBy(name ="outpaymentReasonCode")
	private WebElement drpOutpayment;
	
	@FindBy(name = "claimAmount")
	private WebElement txtClaimAmount;
	
	@FindBy(name ="back")
	private WebElement btnBack;
	
	@FindBy(name = "correctionType")
	private WebElement drpCorrectionType;
	
	@FindBy(name = "accept")
	private WebElement btnAccept;
	
	@FindBy(name = "indexedPremiumSelected[0]")
	private WebElement chkPremiumSelect;

	
	public PremiumReturn() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public void clickSelectAll() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnSelectAll, "Select All Premium");
	}
	
	public void clickAbort(){
		Context.global().getSeleniumUtils().clickOnElement(this.btnAbort, "Abort Action");
	}
	
	public void clickContinue(){
		Context.global().getSeleniumUtils().clickOnElement(this.btnContinue, "Click On Continue");
	}
	
	public void selectEventType(String drpdownValue){
		Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpEventType, "visibleText", drpdownValue);
	}

	public void selectOutPayment(String drpdownValue){
		Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpOutpayment, "visibleText", drpdownValue);
	}
	
	public void fetchClaimAmount()
	{
		Context.global().getSeleniumUtils().getText(this.txtClaimAmount);
	}
	public void clickBack(){
		Context.global().getSeleniumUtils().clickOnElement(this.btnBack, "Click On Back");
	}
	
	public void selectCorrectionType(String drpdownValue){
		Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpCorrectionType, "visibleText", drpdownValue);
	}
	
	public void clickAccept(){
		Context.global().getSeleniumUtils().clickOnElement(this.btnAccept, "Click On Accept");
	}
	
	public void checkPremiumSelect(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPremiumSelect, "Premium Select");
    }
	
	@Override
	public void verifyPageState() {
		// 
	}
	
}
