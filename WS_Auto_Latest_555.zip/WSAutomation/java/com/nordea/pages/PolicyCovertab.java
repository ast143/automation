package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: Event View - This Page is for fetching all information from policy cover tab.
 * Navigation to this page is by clicking on LHN >> Policy >>policy
 * 
 * Abbreviations
 * VAEIC = View account events including cancelled
 * 
 * 
 * Functionality Created By  	: Atluri Vinay Kumar
 * Reviewed By                 	: Debabrata Behera
 * Review Date                	: 28/04/2017
 * Modified By 				   	: 
 * Last Modified Date        	: 
 * Reviewed By					: 
 * Review Date					: 
*/

public class PolicyCovertab implements Page {

	@FindBy(linkText="Covers")
	private WebElement tabCovers;
	
	@FindBy(linkText="Payment plan")
	private WebElement tabPaymentPlan;
	
	@FindBy(linkText="Investment plan")
	private WebElement tabInvestmentPlan;
	
	@FindBy(linkText="Printing")
	private WebElement tabPrintouts;
	
	@FindBy(xpath="//form[contains(@action,'lisPolicyPaymentPlan')]/input[@name='submit']")
	private WebElement btnPaymentPlanEdit;

	@FindBy(xpath="//form[contains(@action,'RegularPaymentPlan')]/input[@name='submit']")
	private WebElement btnRgrlPaymentPlanEdit;

	@FindBy(xpath="//form[contains(@action,'IrregularPaymentPlan')]/input[@name='submit']")
	private WebElement btnSngllPaymentPlanEdit;
	
	@FindBy(name="paymentPlanCategoryCode")
	private WebElement drpPaymentPlan;
	
	@FindBy(name="paymentMethodCode")
	private WebElement drpPaymentMethod;
	
	@FindBy(name="submit")
	private WebElement btnSave; //same value for accept and edit also
	
	@FindBy(name="cancel")
	private WebElement btnCancel;
	
	@FindBy(name="addRegularPaymentRow")
	private WebElement btnAddRegularPaymentPlan;

	@FindBy(name="addIrregularPaymentRow")
	private WebElement btnAddSinglePaymentPlan;
	
	@FindBy(name="newInvestmentPlan")
	private WebElement btnAddNewInstPlan;
	
	@FindBy(name="effectiveDate")
	private WebElement txtStartDateInvPlan;
	
	@FindBy(name="expiryDate")
	private WebElement txtEndDateInvPlan;
	
	@FindBy(name="addInvestments")
	private WebElement btnAddInvestments;
	
	@FindBy(xpath="//a[contains(text(),'Extra Payment Invoice')]")
	private WebElement lnkExtraPaymentInv;
	
	@FindBy(xpath="//a[contains(text(),'Block printouts')]")
	private WebElement lnkBlockPrintouts;
	
	@FindBy(name="block")
	private WebElement btnBlockPrintoutSave;
	
	@FindBy(name="return")
	private WebElement btnReturn;
	
	@FindBy(name="viewDate")
	private WebElement txtPrintViewDate;
	
	@FindBy(name="print")
	private WebElement btnPrint;	
	
	
	public PolicyCovertab(){
		PageFactory.initElements(Context.global().getDriver(), this);
	}	
    
    public void clickCoversTab(){
	    Context.global().getSeleniumUtils().clickOnElement(this.tabCovers, "Covers Tab");
    } 
    
    public void clickPaymentPlanTab(){
	    Context.global().getSeleniumUtils().clickOnElement(this.tabPaymentPlan, "payment plan tab");
    }
    
    public void clickEditPaymentPlan(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnPaymentPlanEdit, "edit payment plan tab");
    }
    
    public void clickEditRegularPaymentPlan(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnRgrlPaymentPlanEdit, "edit regular payment plan tab");
    }
    
    public void clickEditSinglePaymentPlan(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnSngllPaymentPlanEdit, "edit singlr payment plan tab");
    }
    
    public  void selectPaymentPlan(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpPaymentPlan, "visibleText", value);
	}
    
    public  void selectPaymentMethod(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpPaymentMethod, "visibleText", value);
	}
	
    public  void clickSave(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "save button");
	}
    
    public  void clickCancel(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnCancel, "cancel button");
	}
    
    public  String fetchPremiumDueDate(){
		 return Context.global().getDriver().findElementByXPath("//th[contains(text(),'First premium due date')]//following-sibling::td[1]").getText().trim();
	}
    
    public  String fetchPaymentPlan(){
		 return Context.global().getDriver().findElementByXPath("//th[contains(text(),'Payment plan classification')]//following-sibling::td[1]").getText().trim();
	}
    
    public  String fetchFirstPremiumAmount(){
		 return Context.global().getDriver().findElementByXPath("//th[contains(text(),'First premium amount')]//following-sibling::td[1]").getText().trim();
	}
    
    public  String fetchInsuranceYearlyPremium(){
		 return Context.global().getDriver().findElementByXPath("//th[contains(text(),'Insurance year premium')]//following-sibling::td[1]").getText().trim();
	}
    
    public  String fetchPaymentMethod(){
		 return Context.global().getDriver().findElementByXPath("//th[contains(text(),'Payment method')]//following-sibling::td[1]").getText().trim();
	}
    
    public  void clickAddRegularPlan(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddRegularPaymentPlan, "add regular payment plan button");
	}
    
    public  void clickAddSingleRegularPlan(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddSinglePaymentPlan, "add single payment plan button");
	}
    
    public void clickInvPlanTab(){
	    Context.global().getSeleniumUtils().clickOnElement(this.tabInvestmentPlan, "investment plan tab");
    }
    
    public  void clickNewInvstPlan(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddNewInstPlan, "add new investment plan button");
	}
    
    public  void enterInvStartDate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtStartDateInvPlan, "Investment plan start date", date);
	}
    
    public  void enterInvEndDate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtEndDateInvPlan, "Investment plan end date", date);
	}
    
    public  void clickAddInvestments(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddInvestments, "add new investments button");
	}
    
    public  void clickExtraPaymentInv(){
		 Context.global().getSeleniumUtils().clickOnElement(this.lnkExtraPaymentInv, "extra payment invoice link");
	}
    
    public void clickPrintingTab(){
	    Context.global().getSeleniumUtils().clickOnElement(this.tabPrintouts, "printouts tab");
    }
    public  void clickBlockPrintouts(){
		 Context.global().getSeleniumUtils().clickOnElement(this.lnkBlockPrintouts, "block printout link");
	}
    
    public  void enterPrintingDate(String date){
    	Context.global().getDriver().findElementByName("viewDate").clear();
		Context.global().getSeleniumUtils().enterText(this.txtPrintViewDate, "printing date", date);
	}
    
    public  void clickPrintButton(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnPrint, "print button");
	}
	
	@Override
	public void verifyPageState() {
		//	
	}

}
