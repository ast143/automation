package com.nordea.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: PolicyFurtherDetails - This Page contains all objects related to
 * payment plan details tab.
 * Navigation to this page is by clicking on LHN >> Policy >>Further details.
 * 

 * 
 * 
 * Functionality Created By  	: Neville Menezes
 * Reviewed By                 	: Mithen Kadam
 * Review Date                	: 
 * Modified By 				   	: 
 * Last Modified Date        	: 
 * Reviewed By					: 
 * Review Date					: 
*/

public class PaymentPlan implements Page {
	
	@FindBy(linkText="Payment plan")
	private WebElement lnkPaymentPlan;
	
	@FindBy(xpath="//h2[contains(text(), 'Regular premiums')]//following-sibling::div[1]//tr/td[6]/a")
	private List<WebElement> lnkViewDetails;
	
	@FindBy(name="back")
	private WebElement btnReturn;

	public PaymentPlan(){
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	 public void clickPaymentPlanTab(){
		    Context.global().getSeleniumUtils().clickOnElement(this.lnkPaymentPlan, "Payment Plan Tab");
	    }
	
	 public void clickUpdatedViewDetails(){
		 int viewDetailscount = this.lnkViewDetails.size();
		    Context.global().getSeleniumUtils().clickOnElement(this.lnkViewDetails.get(viewDetailscount-1), "ViewDetails");
	    }
	 
	 public void clickReturn(){
		    Context.global().getSeleniumUtils().clickOnElement(this.btnReturn, "Return");
	    }
	 
	 
	
	@Override
	public void verifyPageState() {
		// TODO Auto-generated method stub
		
	}

}
