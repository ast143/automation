package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/** 
 * Description: ITLoginPage- This page is the login page for the IT Server Application
 * 
 * 
 * Functionality Created By  	: Debabrata Behera
 * Reviewed By                 	: Nitesh Khanna
 * Creation Date                : 10/12/2016
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017
*/

public class ITLoginPage implements Page {

	@FindBy(xpath = "//input[@name='j_username']")
	private WebElement txtUsername;
	
	@FindBy(xpath = "//input[@name='j_password']")
	private WebElement txtPassword;
	
	@FindBy(xpath = "//input[@type='submit']")
	private WebElement btnAccept;
	
	public ITLoginPage() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}

	public void setUserid(String userid) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtUsername, "Username", userid);
	}

	public void setPassword(String pwd) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtPassword, "Password", pwd);
	}

	public void clickLogin() throws InterruptedException {		
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAccept, "Submit");		
	}
	
	@Override
	public void verifyPageState() {
		//
	}
}
