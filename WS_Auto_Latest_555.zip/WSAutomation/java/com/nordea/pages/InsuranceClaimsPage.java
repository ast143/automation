package com.nordea.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: This Page is Insurance claims page  
 * Navigation : Claim > Insurance Claims
 * 
 * 
 * Functionality Created By  	: Snehal Bahulekar
 * Reviewed By                 	: Kapil kapoor
 * Review Date                	: 06/04/2017
 * Modified By 				   	: 
 * Last Modified Date        	: 
 * Reviewed By					: 
 * Review Date					: 
*/
public class InsuranceClaimsPage implements Page{

	@FindBy(name="org.apache.struts.taglib.html.CANCEL")
	private WebElement btnClaimHandlingPopupNo;
	
	@FindBy(xpath="//input[@class='buttonYes']")
	private WebElement btnClaimHandlingPopupYes;
	
		
	@FindBy(linkText="Basic")									
	private WebElement lnkBasic;
	
	@FindBy(name="continue")									
	private WebElement btnContinue;
	
	@FindBy(name="accept")									
	private WebElement btnAccept;
	
	@FindBy(name="claimActType")
	private WebElement drpProcessingType;
	
	@FindBy(name="handler")
	private WebElement txthandler;
		
	@FindBy(linkText="Further details")									
	private WebElement lnkFurtherDetails;	
	
	@FindBy(linkText="Covers")									
	private WebElement lnkCovers;
	
	@FindBy(linkText="//a[text()='Permanent disability']")
	private WebElement lnkPermanentDisability;
	
	@FindBy(xpath= "//a[contains(text(),'Death benefit')]")
	private WebElement lnkDeathBenefit;
	
	@FindBy(xpath= "//a[contains(text(),'Critical Illness')]")
	private WebElement lnkCriticalillness;
	
	@FindBy(xpath= "//a[contains(text(),'PermanentAccidental')]")
	private WebElement lnkPermanentAccidental;
	
	@FindBy(linkText="Savings capital")									
	private WebElement lnkSavingsCapital;
	
	@FindBy(linkText="Beneficiaries")									
	private WebElement lnkBeneficiary;
	
	@FindBy(xpath = "//th[@title='Beneficiary']/../../../tbody/tr/td[1]/a")
	private  List<WebElement> lnkBeneficiaries;
		
	@FindBy(name="submit" )
	private WebElement btnRemoveBeneficiary; 
	
	@FindBy(name="coverBeneficiaryCode")									
	private WebElement drpBeneficiaryCode;
	
	@FindBy(name="beneficiaryIdentifier")									
	private WebElement txtBeneficiary;
	
	@FindBy(name="findBeneficiary")									
	private WebElement btnfindBeneficiary;
	
	@FindBy(xpath="//a[text()='Insured']")
	private WebElement lnkInsured;
	
	@FindBy(name="beneficiaryInsuredRelation")									
	private WebElement drpInsuredRelation;
	
	@FindBy(name="beneficiaryDisplayPercent")									
	private WebElement txtSharePercentage;
	
	@FindBy(name="findPayeeAccountNumber")									
	private WebElement btnFindPayeeAccountNumber;
	
	@FindBy(name="saveBeneficiary")									
	private WebElement btnSaveBeneficiary;
	
	@FindBy(xpath="//input[@value='Delete']")									
	private WebElement btnDelete;
	
	@FindBy(xpath="//input[@value='Add']")									
	private WebElement btnAdd;
	
	@FindBy(linkText="Parties")									
	private WebElement lnkParties;
	
	@FindBy(linkText="Clarifications")									
	private WebElement lnkClarifications;
	
	@FindBy(linkText="Modes")									
	private WebElement lnkModes;                 
	
	@FindBy(xpath="//input[@value='Edit']")									
	private WebElement btnEdit;
	
	@FindBy(xpath="//input[@value='Cancel claim')]")									
	private WebElement btnCancelClaim;
	
	@FindBy(xpath="//input[@value='Reject')]")									
	private WebElement btnReject;
	
	@FindBy(xpath="//input[@value='Return']")									
	private WebElement btnReturn;
	
	@FindBy(xpath="//input[@value='Create claim settlement']")									
	private WebElement btnCreateClaimSettlement;
	
	@FindBy(xpath="//input[contains(text(),'View settlements')]")									
	private WebElement btnViewSettlements;
	
	@FindBy(xpath="//tbody/tr/td[2]")
	private WebElement elmCoverAmount;
	
	@FindBy(xpath="//th[contains(text(),'Insurance claim')]/a[1]")
	private WebElement lnkClaimId;
	
	@FindBy(xpath="//tr[4]/th/a")
	private WebElement lnkSettlementId;
	
	@FindBy(name="save")
	private WebElement btnSave;
	
	@FindBy(xpath = "//tr[2]/td[contains(text(),'Total')]/../td[2]")
	private WebElement elmTotalCoverAmount;
	
	@FindBy(xpath = "//tr[3]/td[contains(text(),'Allocated')]/../td[2]")
	private WebElement elmAllocatedCoverAmount;
	
	public InsuranceClaimsPage(){
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public void clickClaimPopupYes() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnClaimHandlingPopupYes, "Automatic Claim Handling Yes");

	}
	
	public void clickClaimPopupNo() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnClaimHandlingPopupNo, "Automatic Claim Handling No");

	}
	public void clickClaimId() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkClaimId, "Claim ID");

	}
	
	public String fetchClaimId()
	{
		return Context.global().getSeleniumUtils().getText(lnkClaimId);
	}
	
	public void clickSettlementId() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkSettlementId, "Settlement ID");

	}
	public void clickBasic(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkBasic, "Basic");
    }
	
	
	public void clickContinue(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnContinue, "Continue");
    }
	
	public void clickSave(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "Save");
    }
	
	public void selectProcessingType()
	{
		Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpProcessingType, "visibleText", "Handler");
	}
	
	public void setHandler(String handler)
	{
		Context.global().getSeleniumUtils().clearText(this.txthandler, "Cleared handler");
		Context.global().getSeleniumUtils().enterText(this.txthandler,"Handler", handler);
	}
	
	public void clickFurtherDetails(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkFurtherDetails, "Further Details");
    }
	
	public void clickCovers(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkCovers, "Covers");
    }
	
	public boolean verifyDeathBenefitLink()
	{
		return Context.global().getSeleniumUtils().verifyElementPresent(this.lnkDeathBenefit,"Death Benefit link");
	}
	public boolean verifyPermanentDisabilityLink()
	{
		return Context.global().getSeleniumUtils().verifyElementPresent(this.lnkPermanentDisability,"Permanent Disability Link");
	}
	
	public void clickDeathBenefit(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkDeathBenefit, "Death Benefit Link");
    }
	public void clickBeneficieryLink(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkBeneficiary, "Beneficieries");
    }
	
	public void clickPermanentDisabilityCover(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkPermanentDisability, "Permanent Disability");
    } 
	
	public void clickCriticalIllnessCover(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkCriticalillness, "Critical illness");
    }
	public void clickPermanentAccidentalCover(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkPermanentAccidental, "Permanent Accidental Handicapped");
    }
	public void clickSavingsCapital(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkSavingsCapital, "Saving capital");
    }
	
	public List<WebElement> fetchBeneficiaries()
	{
		return this.lnkBeneficiaries;
	}
	
	public void clickRemoveBeneficiary(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnRemoveBeneficiary, "Beneficiary is Removed ");
    }
	
	public void selectBeneficiaryCode()
	{
		Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpBeneficiaryCode, "visibleText", "Named");
	}
	
	public void setBeneficiaryIdentifier(String BeneficiaryId)
	{
		Context.global().getSeleniumUtils().enterText(this.txtBeneficiary,"Beneficiary ID", BeneficiaryId);
	}

	public void clickFindBeneficiary()
	{
	    Context.global().getSeleniumUtils().clickOnElement(this.btnfindBeneficiary, "Find Beneficiary");
    }
	
	public void selectInsuredRelation(String Relation)
	{
		Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpInsuredRelation, "visibleText", Relation);
	}
	
	public void setSharePercentage(String SharePercentage)
	{
		Context.global().getSeleniumUtils().enterText(this.txtSharePercentage,"Share Percentage", SharePercentage);
	}
	public void clickFindPayeeAccountNumber()
	{
	    Context.global().getSeleniumUtils().clickOnElement(this.btnFindPayeeAccountNumber, "Find Beneficiary Account Number");
    }
	
	public void clickSaveBeneficiary()
	{
	    Context.global().getSeleniumUtils().clickOnElement(this.btnSaveBeneficiary, "Save Beneficiary");
    }
	
	public String fetchTotalCoverAmount()
	{
		 return Context.global().getSeleniumUtils().getText(this.elmTotalCoverAmount);
		
	}
	
	public String fetchAllocatedCoverAmount()
	{
		 return Context.global().getSeleniumUtils().getText(this.elmAllocatedCoverAmount);
		
	}
	
	
	public void clickDelete()
	{
	    Context.global().getSeleniumUtils().clickOnElement(this.btnDelete, "Delete");
    }
	
	public void clickAdd(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnAdd, "Add");
    }
	
	public void clickParties(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkParties, "Parties");
    }
	
	public void clickClarifications(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkClarifications, "Clarifications");
    } 
	
	public void clickModes(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkModes, "Modes");
    }
	
	public void clickEdit(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnEdit, "Edit");
    }
	
	public void clickCancelClaim(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnCancelClaim, "CancelClaim");
    }
	
	public void clickReject(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnReject, "Reject");
    }
	
	public void clickReturn(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnReturn, "Return");
    }
	
	public void clickAccept(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnAccept, "Accept");
    }
	
	public void clickCreateClaimSettlement(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnCreateClaimSettlement, "CreateClaimSettlement");
    }
	
	public void clickViewSettlements(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnViewSettlements, "CreateViewSettlements");
    }
	public String fetchCoverAmount(){
	    return Context.global().getSeleniumUtils().getText(this.elmCoverAmount);
    }
	public boolean verifyInsuredPresent()
	{
	 return Context.global().getSeleniumUtils().verifyElementPresent(lnkInsured, "Insured");
	}
	
	@Override
	public void verifyPageState() {

		
	}
	
	
}
