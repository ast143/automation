package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;


/** 
 * Description: NewOfferPage - This page contains all the links to select the desired product.
 * Navigating to this page by clicking on 'New offer' tabs in the LHN 
 * 
 * Functionality Created By  	: Kapil Kapoor
 * Reviewed By                 	: Debabrata Behera
 * Creation Date               	: 22/12/2016
 * Modified By 				   	: Kapil Kapoor (Correcting Naming Convention)
 * Last Modified Date        	: 16/01/2017
 * Reviewed By					: Debabrata Behera
 * Review Date					: 17/01/2017
*/

public class NewOfferPage implements Page {

	@FindBy(xpath = "//a[text()='3']")
	private WebElement lnkProduct3;
	
	@FindBy(xpath = "//a[text()='4']")
	private WebElement lnkProduct4;
	
	@FindBy(xpath = "//a[text()='5']")
	private WebElement lnkProduct5;
	
	@FindBy(xpath = "//a[text()='6']")
	private WebElement lnkProduct6;
	
	@FindBy(xpath = "//a[text()='7']")
	private WebElement lnkProduct7;
	
	@FindBy(xpath = "//a[text()='8']")
	private WebElement lnkProduct8;
	
	@FindBy(xpath = "//a[text()='9']")
	private WebElement lnkProduct9;
	
	@FindBy(xpath = "//a[text()='36']")
	private WebElement lnkProduct36;
	
	@FindBy(xpath = "//a[text()='39']")
	private WebElement lnkProduct39;
	
	@FindBy(xpath = "//a[text()='58']")
	private WebElement lnkProduct58;
	
	@FindBy(xpath = "//a[contains(text(),'58')]//..//following-sibling::td[1]")
	private WebElement elmProductName58;

	public NewOfferPage() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}

	public void selectProduct3() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct3, "Select Product3");
	}

	public void selectProduct4() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct4, "Select Product4");
	}

	public void selectProduct5() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct5, "Select Product5");
	}

	public void selectProduct6() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct6, "Select Product6");
	}

	public void selectProduct7() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct7, "Select Product7");
	}

	public void selectProduct8() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct8, "Select Product8");
	}

	public void selectProduct9() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct9, "Select Product9");
	}

	public void selectProduct36() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct36, "Select Product36");
	}

	public void selectProduct39() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct39, "Select Product39");
	}

	public void selectProduct58() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkProduct58, "Select Product58");
	}

	public String fetchProductname() {
		return Context.global().getSeleniumUtils().getText(this.elmProductName58).trim();
	}

	@Override
	public void verifyPageState() {
		//
	}
}
