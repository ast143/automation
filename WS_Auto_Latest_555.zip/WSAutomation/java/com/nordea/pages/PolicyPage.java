package com.nordea.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: Event View - This Page is for validating point in policy detail.
 * Navigation to this page is by clicking on LHN >> Policy >>policy
 * 
 * Abbreviations
 * VAEIC = View account events including cancelled
 * 
 * 
 * Functionality Created By  	: Kapil Kapoor
 * Reviewed By                 	: Poonam Joshi
 * Review Date                	: 27/04/2017
 * Modified By 				   	: 
 * Last Modified Date        	: 
 * Reviewed By					: 
 * Review Date					: 
*/

public class PolicyPage implements Page {

	
	@FindBy(xpath = "//th[contains(text(),'Mode')]//following-sibling::td[1]")									
	private WebElement elmMode;
	
	@FindBy(linkText="Savings")
	private WebElement tabSavings;
		
	@FindBy(xpath="//th[text()='Investment']/../../../tbody/tr/td[1]")
	private WebElement elmInvestment;
	
	@FindBy(xpath="//th[text()='Investment']/../../../tbody/tr/td[1]")
	private List<WebElement> elmInvestmentList;
	
	public PolicyPage(){
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
    public String fetchMode(){
	    return Context.global().getSeleniumUtils().getText(this.elmMode);
    }
	
    public void clickSavingsTab(){
	    Context.global().getSeleniumUtils().clickOnElement(this.tabSavings, "Savings Tab");
    } 
    
    public String fetchInvestment(){
    	return Context.global().getSeleniumUtils().getText(this.elmInvestment);
    }
    
	public List<String> fetchInvestmentList(){
    	List<String> investmentList=new ArrayList<String>();
    	for(int i=0;i<this.elmInvestmentList.size();i++){
    		investmentList.add(Context.global().getSeleniumUtils().getText(this.elmInvestmentList.get(i)));
    	}
		return investmentList;    	
    }
	
	@Override
	public void verifyPageState() {

	}

}
