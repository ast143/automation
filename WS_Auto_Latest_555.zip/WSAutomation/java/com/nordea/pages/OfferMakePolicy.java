package com.nordea.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;


/** 
 * Description: This page contains web elements and methods for complete flow of offer creation for different product
 * Navigating to this page by clicking on 'offer' tabs in the LHN 
 * 
 * 
 * Naming convention guidelines
 * PageName+WebElementName  
 * DB=Death Benefit
 * PD=Permanent Disability
 * PAH=Permanent Accidental Handicap
 * CI=Critical Illness 
 * Functionality			 	: Will be called as per requirement.
 * Functionality Created By  	: Snehal Bahulekar
 * Reviewed By                 	: Mithen Kadam
 * Review Date                	: 27/12/2016
 * Modified By 				   	: Aruna Kumar Behera
 * Last Modified Date        	: 20/03/2017
 * Reviewed By					: Debabrata Behera
 * Review Date					: 20/03/2017
*/

public class OfferMakePolicy extends LHN implements Page  {
		
	    @FindBy(xpath = "//input[@id='signed.yes']")
	    private WebElement rbdPolicySignedYes;
	    
	    @FindBy(xpath = "//input[@id='signed.no']")
	    private WebElement rbdPolicySignedNo;
	    
	    @FindBy(xpath = "//input[@name='indexedDecision[0]']")
	    private WebElement chkPolicyHD;
	    
	    @FindBy(xpath = "//input[@name='accept']")
	    private WebElement btnPolicyAccept;
	       
	    @FindBy(xpath = "//td[@class='popUpText']")
	    private WebElement elmPolicyId;
		
	    @FindBy(linkText = "Invoice")
	    private WebElement lnkInvoice;
	  
	    @FindBy(id = "smoker.no")
	    private WebElement rbdSmokerNo;
	    
	    @FindBy(id = "smoker.yes")
	    private WebElement rbdSmokerYes;	
	    
	    @FindBy(xpath = "//input[@value='OK']")
	    private WebElement btnOK;
	    
	    @FindBy(xpath = "//input[@value='Save']")
	    private WebElement btnSave;
	     
	    @FindBy(xpath = "//td[contains(text(),'Invoice')]/../td/input")
	    private WebElement chkInvoiceApplication;
	    
	    @FindBy(xpath = "//input[@name='Print']")
	    private WebElement btnPrint;
		
		@FindBy(xpath = "//div[@class='errorbox']")
	    private WebElement elmErrormessage;
	    
	    @FindBy(xpath = "//table[@class='scrollTable']/tbody/tr/td[1]/a")
	    private WebElement lnkInsured;    
	    
	    @FindBy(name="indexedCoverDesicionCode[0]")
	    private WebElement drpDecisionCode;
	    
	    @FindBy(name="indexedHealthDeclarationLevel[0]")
	    private WebElement drpHDStatus;
		
	    
	    @FindBy(name = "indexedHealthDeclarationLevel[0]")
	    private WebElement drpHealthDeclaration;
	    
	    @FindBy(xpath = "//input[@value='Save unfinished']")
	    private WebElement btnSaveUnfinished;
	    
	    @FindBy(xpath = "//p[@class='idfield']")
	    private WebElement eleHeader;
	    
	    @FindBy(linkText = "Make policy")
	    private WebElement lnkMakePolicy;
	    
	    @FindBy(name = "indexedArrivalDate[0]")
	    private WebElement txtHDArrivalDate;
	    
	    @FindBy(name="indexedAcceptDate[0]")
		private WebElement txtHDAcceptDate;
	    
	    @FindBy(name="indexedInsuredDecisionCode[0]")
		private WebElement drpInsuredDecisionCode;
	    
	    	    
	    public OfferMakePolicy() {
	        PageFactory.initElements(Context.global().getDriver(), this);
	    }  
	  
	    public void clickPolicySignedYes(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.rbdPolicySignedYes, "YespolicySigned");
	    	
	    }
	    public void checkHD(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.chkPolicyHD, "HD checkbox");
	    }
	    
	    public void checkHDCheckBox(){
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.chkPolicyHD, "HD checkbox")){    	
		    	if(Context.global().getSeleniumUtils().verifyElementEnable(this.chkPolicyHD, "HD checkbox") || !Context.global().getSeleniumUtils().verifycheckboxchecked(this.chkPolicyHD)){
		    		Context.global().getSeleniumUtils().clickOnElement(this.chkPolicyHD, "HD checkbox");		    		
		    	}
	    	}
	    }
	    	  
	    public void clickPolicyAccept(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnPolicyAccept, "PolicyAccept");
	    }
	    
	    public void clickSave(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "Save");
	    }
	     
		    
	    public String fetchPolicyID() {
	    	return Context.global().getSeleniumUtils().getText(elmPolicyId).trim().replaceAll("\\s+", " ").split(":")[1].trim();
	    }	    
	    public void clickInvoiceLink() {
	    	Context.global().getSeleniumUtils().clickOnElement(lnkInvoice, "Invoice");
	    }	    
	    public void saveInvoiceLetter(String fileName) throws Exception {
	    	Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(lnkInvoice, 3);
	    	Context.global().getFileDownloader().downloadFile(lnkInvoice, fileName);
	    }
	    
	    public void clickOK() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnOK, "OK Button");
	    }
	    
	    public void checkPrintInvoice(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.chkInvoiceApplication, "Print Invoice checkbox");
	    }
	    
	    public void clickPrint(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnPrint, "Print");
	    }
		
		public boolean verifyOfferErrMsgPresent(){
	    	return Context.global().getSeleniumUtils().verifyElementPresent(this.elmErrormessage,"Offer error message");
	    }
	    
	    public String fetchHDStatus(){
	    	return Context.global().getSeleniumUtils().getSelectedOptionfromDropdown(this.drpHDStatus,"Health declaration");
	    }
	    
	    public void clickInsuredLink(){	
	    	Context.global().getSeleniumUtils().clickOnElement(this.lnkInsured, "Insured link");
	    }
	    
	    public void selectHealthDeclaration(String healthdeclaration){	    	
	    	if(Context.global().getSeleniumUtils().verifyElementEnable(this.drpHealthDeclaration, "Health Declaration drop down")){
	    		Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpHealthDeclaration, "visibleText", healthdeclaration);
	    	}	    	
	    }
	    
	    public void clickSaveUnfinished(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnSaveUnfinished, "Save unfinished button");
	    }
	     
	    public String getDataFromHeader(){
	    	return Context.global().getSeleniumUtils().getText(this.eleHeader);	    
	    }
	    
	    public void clickMakePolicyTab() {
	    	Context.global().getSeleniumUtils().clickOnElement(lnkMakePolicy, "Make policy Tab");
	    }
	     
	    public void enterHDarrivalDate() throws Exception{
	    	Context.global().getSeleniumUtils().enterText(this.txtHDArrivalDate, "HD arraival date", Context.local().getAppUtilityFunction().getApplicationDate());
	    }
	    
	    public void enterHDacceptDate() throws Exception{

	    	Context.global().getSeleniumUtils().enterText(this.txtHDAcceptDate, "HD accept date",Context.local().getAppUtilityFunction().getApplicationDate());
	    }
	    
	    public String getValueFromInsuredDecisionCode() throws Exception{

	    	return Context.global().getSeleniumUtils().getSelectedOptionfromDropdown(this.drpInsuredDecisionCode, "Insured Decision Code");
	   
	    }
	    
	   
	    
		@Override
		public void verifyPageState() {
			//
		}
}
