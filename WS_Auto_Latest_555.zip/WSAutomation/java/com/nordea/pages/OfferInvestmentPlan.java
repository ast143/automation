package com.nordea.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;


/** 
 * Description: This page contains web elements and methods for complete flow of offer creation for different product
 * Navigating to this page by clicking on 'offer' tabs in the LHN 
 * 
 * 
 * Naming convention guidelines
 * PageName+WebElementName  
 * DB=Death Benefit
 * PD=Permanent Disability
 * PAH=Permanent Accidental Handicap
 * CI=Critical Illness 
 * Functionality			 	: Will be called as per requirement.
 * Functionality Created By  	: Snehal Bahulekar
 * Reviewed By                 	: Mithen Kadam
 * Review Date                	: 27/12/2016
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017
*/

public class OfferInvestmentPlan extends LHN implements Page  {
		
	    /**
	     * Application Page : investment Plan
	     */
	       

	    @FindBy(name = "insertInvertment")
	    private WebElement btnAddInvestment;
	    
	    @FindBy(name = "portfolioMgmtTypeCode")
	    private WebElement drpPortfollioServices;
	    
	    @FindBy(name = "showProfile")
	    private WebElement btnShowProfile;
	    
	    @FindBy(name = "profileId")
	    private WebElement drpPortfollioProfile;
	    
	    @FindBy(name = "showProfileInvestments")
	    private WebElement btnShowAllocations;
	    
	    
		@FindBy(name = "indexedAllowedInvestmentChosen[0]")
	    private WebElement chkFirstInvestment;
	    
	    @FindBy(xpath = "//input[@value='Add']")
	    private WebElement btnAdd;
	    
	    @FindBy(name = "count")
	    private WebElement btnCount;
		    
	    /**
	     * Application Page : Withdrawal Plan
	     */
	    
	    @FindBy(name = "withdrawalPlan")
	    private WebElement lnkWithdrawalPlan;
	    
	    @FindBy(name = "addRegular")
	    private WebElement btnAddRegularWithdrawal;	    
	    
	    @FindBy(name = "startDate")
	    private WebElement txtWithdrawalStartDate;
	    
	    @FindBy(name = "withdrawalAmount")
	    private WebElement txtWithdrawalAmount;
	    
	    @FindBy(name = "withdrawalFrequency")
	    private WebElement drpWithdrawalFrequency;
	    
	    @FindBy(name = "paymentDay")
	    private WebElement txtWithdrawalPaymentDay;
	    
	    @FindBy(name = "withdrawalOrderCode")
	    private WebElement drpWithdrawalOrderCode;
	    
	    @FindBy(name = "addSingle")
	    private WebElement btnAddSingleWithdrawal;
	    	    
	    @FindBy(name = "withdrawalDate")
	    private WebElement txtWithdrawalDate;
	    
	    @FindBy(name = "withdrawalRule")
	    private WebElement drpWithdrawalRule;
	    
	    @FindBy(name = "investmentRule")
	    private WebElement drpInvestmentRule;
	    
	    @FindBy(xpath= "//div[@class='commentbox']")
	    private WebElement eleCampaignMsg;	
	   
	    @FindBy(xpath = "//input[@value='OK']")
	    private WebElement btnOK;

	    @FindBy(xpath = "//input[@value='Save']")
	    private WebElement btnSave;
	      
	    @FindBy(xpath = "//input[@name='continue']")
	    private WebElement btnContinue;
	    
	    public OfferInvestmentPlan() {
	        PageFactory.initElements(Context.global().getDriver(), this); 
	    }
	    
	    
	    
		/**
		 * Methods for Investment Plan
		 */
	    
	    public void selectPortfollioServices(String addPortfollioServicesValue){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpPortfollioServices, "visibleText", addPortfollioServicesValue);
	    }
	    	   
	    public void clickShowProfile() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnShowProfile, "Show Profile button");	    	
	    }
	    
	    public void selectPortfollioProfile(String addPortfollioProfileValue){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpPortfollioProfile, "visibleText", addPortfollioProfileValue);
	    }
	    
	    public void clickShowAllocation() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnShowAllocations, "Show Allocation button");	    	
	    }
	    
	    
	    public void clickWithdrawalPlan() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.lnkWithdrawalPlan, "Withdrawal Plan link");
	    }
	    
	    public void clickAddRegularWithdrawal() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnAddRegularWithdrawal, "Add Regular Withdrawal button");	    	
	    }
	  
	    public void setWithdrawalStartDate(String withdrawalStartDate){
	    	Context.global().getSeleniumUtils().enterText(this.txtWithdrawalStartDate,"Withdrawal Start Date field", withdrawalStartDate);
    	}
	      
	    public void setWithdrawalAmount(String withdrawalAmount){
	    	Context.global().getSeleniumUtils().enterText(this.txtWithdrawalAmount,"Withdrawal Amount field", withdrawalAmount);
    	}
	   
	    public void selectWithdrawalFrequency(String withdrawalFrequencyValue){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpWithdrawalFrequency, "visibleText", withdrawalFrequencyValue);
	    }
	    
	    public void setWithdrawalPaymentDay(String withdrawalPaymentDay){
	    	Context.global().getSeleniumUtils().enterText(this.txtWithdrawalPaymentDay,"Withdrawal Payment Day field", withdrawalPaymentDay);
    	}
	    
	    public void selectnWithdrawalOrder(String withdrawalOrderCode){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpWithdrawalOrderCode, "visibleText", withdrawalOrderCode);
	    }
	   
	  
	    public void clickAddSingleWithdrawal() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnAddSingleWithdrawal, "Add button");	    	
	    }  	    
	    	   
	    public void setWithdrawalDate(String withdrawalDate){
	    	Context.global().getSeleniumUtils().enterText(this.txtWithdrawalDate,"Withdrawal Date field", withdrawalDate);
    	}
	    
	    public void selectWithdrawalRule(String withdrawalRule){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpWithdrawalRule, "visibleText", withdrawalRule);
	    }
	   
	    public void selectInvestmentRule(String investmentRule){
	    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpInvestmentRule, "visibleText", investmentRule);
	    }
	   
	    public boolean verifyCampaignMsg(){
	    	return Context.global().getSeleniumUtils().verifyElementPresent(this.eleCampaignMsg, "verifyCampaignMsg" );
	    }
	      
	    public void clickAddInvestment() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnAddInvestment, "Add Investment");
	    }	    
	    public void clickFirstInvestment() {
	    	Context.global().getSeleniumUtils().clickOnElement(chkFirstInvestment, "Investment");
	    }	    
	    public void clickAdd() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnAdd, "Add");
	    }	    
	    public void clickCount() {
	    	Context.global().getSeleniumUtils().clickOnElement(btnCount, "Count");
	    }
	   
	    public void clickResultCalcSave(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "ResultCalcSave"); 	
	    }
	   
	    public void clickOK() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnOK, "OK Button");
	    }
	    
	    public void clickContinue(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnContinue, "Continue");
	    }
	    
		@Override
		public void verifyPageState() {
			//
		}
}
