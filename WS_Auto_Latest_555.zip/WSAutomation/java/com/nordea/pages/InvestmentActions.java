package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

public class InvestmentActions  implements Page {
	/**
	 * Description: 
	 * 
	 * 
	 * Functionality Created By : Poonam Joshi 
	 * Reviewed By              : Debabrata Behera
	 * Review Date				: 09/03/2017
	 * Modified By 				: 
	 * Last Modified Date		: 
	 * Reviewed By 				: 
	 * Review Date				:
	 */

	@FindBy(name="investmentSearchCriteria")
	private WebElement drpInvSearchCriteria;
	
	@FindBy(name="investmentSearchInput")
	private WebElement txtInvestmentDetail;
	
	@FindBy(name="submit")
	private WebElement btnFind;
	
	@FindBy(xpath="//a[text()='Investment']/ancestor::table/tbody//td[1]/a")
	private WebElement lnkInvId;
	
	@FindBy(linkText ="Price parameter")
	private WebElement tabPriceParameter;
	
	@FindBy(xpath ="//th[contains(text(),'Linking delay days')]/../td")
	private WebElement eleLinkingDelayDays;
	
	@FindBy(xpath="//a[text()='Units/prices']")
	private WebElement tabUnitsPrices;
	
	@FindBy(linkText="Enter price")
	private WebElement lnkEnterPrices;
	
	@FindBy(name="priceDate")
	private WebElement txtEnterPriceDate;
	
	@FindBy(xpath="//table/tbody/tr[1]/td[3]")
	private WebElement elmPrice;
	
	@FindBy(name="indexedSubscriptionPrice[0]")
	private WebElement txtEnterPriceAmount;
	
	@FindBy(name="save")
	private WebElement btnSave;
	
	public InvestmentActions() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public void selectInvSearchCriteria(String drpdownValue) {
		Context.global()
				.getSeleniumUtils()
				.selectValueFromDropDown(drpInvSearchCriteria, "visibleText",
						drpdownValue);
	}
	
	public void searchInvestmentDetail(String invDetail){
		Context.global()
		.getSeleniumUtils()
		.clearText(this.txtInvestmentDetail,"Enter Investment Detail");
		Context.global()
				.getSeleniumUtils()
				.enterText(this.txtInvestmentDetail,"Enter Investment Detail", invDetail);
		Context.global().getSeleniumUtils()
		.clickOnElement(this.btnFind, "Click Investment Find");
	}
	
	public void clickFind() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnFind, "Click Investment Find");
	}
	
	public void clickInvestmentId() {
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(this.lnkInvId, 5);
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkInvId, "Click Investment ID link");
    }
	
	public void clickPriceParameterTab() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.tabPriceParameter, "Click Priceparameter Tab");
    }
	
	public String getLinkingDelayDays() {
		return Context.global().getSeleniumUtils()
				.getText(this.eleLinkingDelayDays).trim();
    }
	
	public void clickUnitsPricesTab() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.tabUnitsPrices, "Click Units/Prices Tab");
    }
	
	public void clickEnterPrices() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkEnterPrices, "Click Enter Prices");
    }
	
	public void enterPriceDate(String priceDate){
		Context.global()
		.getSeleniumUtils().clearText(this.txtEnterPriceDate, "Enter Price Date");
		Context.global()
				.getSeleniumUtils()
				.enterText(this.txtEnterPriceDate,"Enter Price Date", priceDate
						);
	}
	
	public void clickOk() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnFind, "Click Price Date OK button");
	}
	
	public String getInvestmentPrice() {
		return Context.global().getSeleniumUtils()
				.getText(this.elmPrice).trim();
    }
	
	public void enterPriceAmount(String priceAmount){
		Context.global()
				.getSeleniumUtils()
				.enterText(this.txtEnterPriceAmount,"Enter Price Amount", priceAmount);
	}
	
	public void clickSave() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnSave, "Click Save");
	}
	
	
	

	@Override
	public void verifyPageState() {
		//
	}
}

