package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/** Description : The pages refers the elements for Permanent Handicapped event
 * 
 * 
 * Functionality Created By  	: Snehal Bahulekar
 * Reviewed By                 	: Kapil Kapoor
 * Creation Date               	: 13/04/2017
 * Review Date					: 18/04/2017
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017 
*/
public class PermanentHandicap implements Page {

	@FindBy(name = "accidentEventType")									
	private WebElement drpPHType ;
	
	@FindBy(name= "eventDate")									
	private WebElement txtPHDate;
	
	@FindBy(name= "notificationDate")									
	private WebElement txtNotificationDate;	
	
	@FindBy(name= "claimantId")									
	private WebElement txtClaimantId;
	
	@FindBy(name= "claimantName")									
	private WebElement txtClaimantName;
	
	@FindBy(name= "receiverId")									
	private WebElement txtReceiverId;
	
	@FindBy(name= "receiverName")									
	private WebElement txtReceiverName;
	
	@FindBy(name= "findClaimant")									
	private WebElement btnfindClaimant;
	
	@FindBy(name= "findReceiver")									
	private WebElement btnfindReceiver;
	
	@FindBy(name="continue")
	private WebElement btnContinue;
	
	@FindBy(name="abort")
	private WebElement btnAbort;
	
	@FindBy(name="indexedSelectedCovers[0]")
	private WebElement chkPHBenefit;
	
	@FindBy(xpath="//tr/th[contains(text(),'Claim amount')]/../td[1]")
	private WebElement elePHAmount;
	
	@FindBy(id="coverSpecificClaims.yes")
	private WebElement rdbEDBYes;
	
	@FindBy(id="coverSpecificClaims.no")
	private WebElement rdbEDBNo;
	
	@FindBy(name="back")
	private WebElement btnBack;
	
	@FindBy(name="accept")
	private WebElement btnAccept;
	
	
	public PermanentHandicap(){
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	
	
	public void selectCriticalillnessType(String drpdownValue) {
		Context.global().getSeleniumUtils()
				.selectValueFromDropDown(this.drpPHType,"visibleText",drpdownValue);
	}

	public void setCriticalillnessDate(String deathDate){
    	Context.global().getSeleniumUtils().enterText(this.txtPHDate, deathDate, "DeathDate");
    }
	
	public void setNotificationDate(String notificationDate){
    	Context.global().getSeleniumUtils().enterText(this.txtNotificationDate, notificationDate, "NotificationDate");
    }
	
	
	public void setClaimantId(String claimantId){
    	Context.global().getSeleniumUtils().enterText(this.txtClaimantId,claimantId, "ClaimantId");
    }
	
	
	public void setClaimantName(String claimantName ){
    	Context.global().getSeleniumUtils().enterText(this.txtClaimantName, claimantName, "ClaimantName");
    }
	
	public void setReceiverId(String receiverId){
    	Context.global().getSeleniumUtils().enterText(this.txtReceiverId, receiverId, "ReceiverId");
    }
	
	public void setReceiverName(String receiverName){
    	Context.global().getSeleniumUtils().enterText(this.txtReceiverName, receiverName, "receiverName");
    }
	
	public void clickFindClaimant() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnfindClaimant, "FindClaimant");
	}
	
	public void clickFindReceiver() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnfindReceiver, "FindReceiver");
	}
	public void clickContinue() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnContinue, "Continue");
	}
	
	public void clickAbort() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAbort, "Abort");
	}
	
	public void checkPHBenefit() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.chkPHBenefit, "Check Critical Illness Benefit");
	}
	public void selectEDBYes() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.rdbEDBYes, "Select EDB Yes");
	}
	
	public void selectEDBNo() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.rdbEDBNo, "Select EDB No");
	}
	
	public void fetchAmount() {
		Context.global().getSeleniumUtils()
		.getText(this.elePHAmount);
	}
	
	public void clickBack() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnBack, "Click on Back ");
	}
	
	public void clickAccept() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAccept, "Click on Accept ");
	}
	
	@Override
	public void verifyPageState() {
		//		
	}

}
