package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;


/**
 * Description: The page refers the elements required for policy Cancellation event
 * 
 * 
 * Functionality Created By : Pavan Kadam
 * Reviewed By : Snehal Bahulekar
 * Review Date : 07/04/2017
 * Modified By : Mithen Kadam	
 * Last Modified Date : 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017
 */

public class PolicyCancellation implements Page {

	@FindBy(name = "occuredDate")
	private WebElement txtEventDate;
	
	@FindBy(name = "chosenActivityCode")
	private WebElement drpEvent;
	
	@FindBy(name = "claimantName")
	private WebElement txtClaimantName;
	
	@FindBy(name = "claimantId")
	private WebElement txtClaimantID;
	
	@FindBy(name = "findClaimant")
	private WebElement btnFindClaimant;
	
	@FindBy(name = "continue")
	private WebElement btnContinue;
	
	@FindBy(name= "abort")
	private WebElement btnAbort;
	
	@FindBy(name = "back")
	private WebElement btnBack;
	
	@FindBy(xpath ="//th[contains(text(),'End balance')]/../td[1]")
	private WebElement elmEndBalance;
	
	@FindBy(name ="expensesNotCharged")
	private WebElement chkExpenseNotCharged;
	
	@FindBy(name = "accept")
	private WebElement btnAccept;
	
	
	public PolicyCancellation() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	
	public void fetchEventDate()
	{
		Context.global().getSeleniumUtils().getText(this.txtEventDate);
	} 
	
	
	public void selectEvent(String drpdownValue){
		Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpEvent, "visibleText", drpdownValue);
	}
	
	public void fetchClaimantID()
	{
		Context.global().getSeleniumUtils().getText(this.txtClaimantID);
	}
	
	public void fetchClaimantName()
	{
		Context.global().getSeleniumUtils().getText(this.txtClaimantName);
	}
	
	public void clickFind() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnFindClaimant, "Click on Find");
	}
	
	public void clickContinue() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnContinue, "Click on Continue");
	}
	
	public void clickAbort() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnAbort, "Click on Abort");
	}
	
	public void clickBack() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnBack, "Click on Back");
	}
	
	public void fetchEndBalance()
	{
		Context.global().getSeleniumUtils().getText(this.elmEndBalance);
	} 
	
	public void checkExpenseNotCharged(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkExpenseNotCharged, "Expense Not Charged");
    }
	
	public void clickAccept() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnAccept, "Click on Accept");
	}
	
	@Override
	public void verifyPageState() {
		// 		
	}
	
	
	
	
	
}
