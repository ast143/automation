package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/** 
 * Functionality			 	: Will be called as per requirement.
 * Functionality Created By  	: Debabrata Behera
 * Reviewed By                 	: Poonam Joshi
 * Review Date                	: 03/03/2017
 * Modified By 				   	: Poonam Joshi
 * Last Modified Date        	: 27/04/2017
 * Reviewed By					: 
 * Review Date					: 
*/

public class Management implements Page {
	
	@FindBy(linkText = "Changing session time")
    private WebElement lnkChangeSessionTime;
	
	@FindBy(name = "time")
    private WebElement txtDate;
	
	@FindBy(name = "submit")
    private WebElement btnSubmit;
	
	public Management(){
		 PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public void clickChangeSessionTime(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkChangeSessionTime, "Change Session Time");
    }
	
	public void enterSessionDate(String date){
		Context.global().getSeleniumUtils().clearText(this.txtDate, "Date");
	    Context.global().getSeleniumUtils().enterText(this.txtDate,"Date" ,date);
    }
	
	public void clickSubmit(){
	    Context.global().getSeleniumUtils().clickOnElement(this.btnSubmit, "Submit");
    }

	@Override
	public void verifyPageState() {
	//	
	}

}
