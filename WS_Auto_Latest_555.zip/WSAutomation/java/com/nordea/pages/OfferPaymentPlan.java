package com.nordea.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;


/** 
 * Description: This page contains web elements and methods for complete flow of offer creation for different product
 * Navigating to this page by clicking on 'offer' tabs in the LHN 
 * 
 * 
 * Naming convention guidelines
 * PageName+WebElementName  
 * DB=Death Benefit
 * PD=Permanent Disability
 * PAH=Permanent Accidental Handicap
 * CI=Critical Illness 
 * Functionality			 	: Will be called as per requirement.
 * Functionality Created By  	: Snehal Bahulekar
 * Reviewed By                 	: Mithen Kadam
 * Review Date                	: 27/12/2016
 * Modified By 				   	: Aruna Kumar Behera
 * Last Modified Date        	: 20/03/2017
 * Reviewed By					: Debabrata Behera
 * Review Date					: 20/03/2017
*/

public class OfferPaymentPlan extends LHN implements Page  {
		
		
	    /**
	     * Application Page : Payment Plan tab
	     */
	    
	    @FindBy(xpath = "//input[@name='continue']")
	    private WebElement btnPaymentPlanContinue;
	    
	    @FindBy(xpath = "//table[@class='scrollTable']//tbody/tr/td[1]/input")
	    private WebElement txtPaymentPremiumPeriod;
	    
	    @FindBy(name = "indexedFieldPaymentQuantityPA[0]")
	    private WebElement txtPaymentPlanFrequency; 
	    
		@FindBy(name = "firstPremiumAmount")
	    private WebElement txtFirstPremiumAmount;
	    
	    @FindBy(name = "indexedFieldPaymentAmount[0]")
	    private WebElement txtPaymentPremiumAmount;
	    
	    @FindBy(name = "indexedFieldPaymentPeriodStart[0]")
	    private WebElement txtStartDate;
	    
	    @FindBy(name = "indexedFieldPaymentPeriodEnd[0]")
	    private WebElement txtEndDate;
	    
	    @FindBy(name = "indexedFieldPaymentDay[0]")
	    private WebElement txtInvoiceDate;
	    
	    @FindBy(name = "indexedFieldPaymentPlanComment[0]")
	    private WebElement txtMoreInformation;
	    
	    @FindBy(name = "removeRegularRow[0]")
	    private WebElement eleRemoveRegularPP;
	    
	    @FindBy(name = "paymentPlanCategoryCode")
	    private WebElement drpPaymentPlan;
	    
	    @FindBy(name = "paymentMethodCode")
	    private WebElement drpPaymentMethod;
	    
	    @FindBy(name = "addRegularPayment")
	    private WebElement btnAddRegularPayment;
	    
	    
	    @FindBy(name = "addIrregularPayment")
	    private WebElement btnAddSinglePayment;
	    
	    @FindBy(name = "indexedFieldPaymentDueDate[0]")
	    private WebElement txtSinglePremiumDate;
	    
	    @FindBy(name = "indexedFieldOPaymentAmount[0]")
	    private WebElement txtSinglePremiumAmount;
	    
	    @FindBy(name = "removeOccasionalRow[0]")
	    private WebElement eleRemoveSinglePP;  
	 
	    @FindBy(xpath = "//input[@value='OK']")
	    private WebElement btnOK;

	    @FindBy(xpath = "//input[@value='Save']")
	    private WebElement btnSave;
	    
	    @FindBy(xpath = "//input[@name='continue']")
	    private WebElement btnContinue;
	    	    
	    public OfferPaymentPlan() {
	        PageFactory.initElements(Context.global().getDriver(), this); 
	    }
	          
	    /**
	     * Methods for Payment Plan Tab
	     */
	    public void setFirstPremiumAmount(String paymentPeriod){
	    	Context.global().getSeleniumUtils().clearText(this.txtFirstPremiumAmount, "PremiumPeriod");
	    	Context.global().getSeleniumUtils().enterText(this.txtFirstPremiumAmount, "PremiumPeriod", paymentPeriod);
    	} 	
	  
	    
	    public void setPaymentPremiumPeriod(String paymentPeriod){
	    	Context.global().getSeleniumUtils().enterText(this.txtPaymentPremiumPeriod, "PremiumPeriod", paymentPeriod);
    	} 	    
	    public void setPaymentPlanFrequency(String paymentFrequency){
	    	Context.global().getSeleniumUtils().enterText(this.txtPaymentPlanFrequency, "Payment Frequency", paymentFrequency);
    	}  
		
		public void setPaymentPremiumAmount(String paymentAmount){
	    	Context.global().getSeleniumUtils().enterText(this.txtPaymentPremiumAmount, "Payment Amount", paymentAmount);
    	}
	    
		public void setStartDate(String startDate){
			Context.global().getSeleniumUtils().clearText(this.txtStartDate,"Start Date field");
		    Context.global().getSeleniumUtils().enterText(this.txtStartDate,"Start Date field", startDate);
	    }
		    
		public void setEndDate(String endDate){
		   	Context.global().getSeleniumUtils().enterText(this.txtEndDate,"End Date field", endDate);
	    }
		   
		public void setInvoiceDate(String invoiceDate){
		   	Context.global().getSeleniumUtils().enterText(this.txtInvoiceDate,"Invoice Date field", invoiceDate);
	    }
		
		public String fetchInvoiceDate(){
			
			return Context.global().getSeleniumUtils().getAttribute(this.txtInvoiceDate, "value");
		}
		
		    
		public void setMoreInformation(String moreInfo){
		   	Context.global().getSeleniumUtils().enterText(this.txtMoreInformation,"More information field", moreInfo);
	    } 
		    
		public void clickRegularPPImage(){
		   	Context.global().getSeleniumUtils().clickOnElement(this.eleRemoveRegularPP, "Thrash image");
		}  
		    
		public void selectPaymentPlanDropDown(String addPaymentPlanValue){
		   	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpPaymentPlan, "visibleText", addPaymentPlanValue);
		}
		    
		public void selectPaymentMethodDropDown(String addPaymentMethodValue){
		    Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpPaymentMethod, "visibleText", addPaymentMethodValue);
		}
		 
		public void clickAddRegularPayment() {
		  	Context.global().getSeleniumUtils().clickOnElement(this.btnAddRegularPayment, "Regular Add button");	    	
		}
		    
		public void clickAddSinglePayment() {
		  	Context.global().getSeleniumUtils().clickOnElement(this.btnAddSinglePayment, "Single Add button");	    	
		}
		    	    
		public void setSinglePremiumDate(String singlePremiumDate){
		   	Context.global().getSeleniumUtils().enterText(this.txtSinglePremiumDate,"Single Premium Date field", singlePremiumDate);
	    }
		    
		public void setSinglePremiumAmount(String singlePremiumamount){
		   	Context.global().getSeleniumUtils().enterText(this.txtSinglePremiumAmount,"Single Premium Amount field", singlePremiumamount);
	    }
		    
		public void clickSinglePPImage(){
		   	Context.global().getSeleniumUtils().clickOnElement(this.eleRemoveSinglePP, "Thrash image");
		}  
		
		public void deleteRegularRow(){
	    	Context.global().getSeleniumUtils().clickOnElement(eleRemoveSinglePP, "Death Saving Cover");
	    }
		 
	    public void clickOK() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnOK, "OK Button");
	    }
	    
	    public void clickContinue(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnContinue, "Continue");
	    }
		@Override
		public void verifyPageState() {
			//
		}
}
