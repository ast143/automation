package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
/**
 * Description: ChangeCalPensionSavings - It will perform various change calculations pertaining to Pension Savings. 

 * Functionality Created By  	: Neville Menezes
 * Reviewed By                 	: Mithen Kadam			
 * Review Date                	: 14/04/2017	
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017 
*/
public class ChangeCalPensionSavings implements Page{
	/**		    
	    *   Application Page : All 
	    */
	
	@FindBy(linkText="Basic")
	private WebElement lnkBasic;
	
	@FindBy(linkText="Covers")
	private WebElement lnkCovers;
	
	@FindBy(linkText="Savings")
	private WebElement lnkSavings;
	
	@FindBy(linkText="Payment plan")
	private WebElement lnkPaymentPlan;
	
	@FindBy(linkText="Investment plan")
	private WebElement lnkInvestmentPlan;
	
	@FindBy(linkText="Printing")
	private WebElement lnkPrinting;
	
	@FindBy(linkText="Further details")
	private WebElement lnkFurtherDetails;
	
	/**		    
	    *   Application Page : Savings Tab
	    */
	
	@FindBy(linkText="Reallocation of savings")
	private WebElement lnkReallocationSavings;
	
	@FindBy(linkText="Charge plan")
	private WebElement lnkChargePlan;
	
	@FindBy(linkText="Capital  and Yield information")
	private WebElement lnkCapitalYieldInformation;
	
	@FindBy(linkText="Value change information")
	private WebElement lnkValueChangeInformation;
	
	@FindBy(linkText="Premium Guarantee")
	private WebElement lnkPremiumGuarantee;
	
	@FindBy(name="showProfile")
    private WebElement btnShow;
	
	@FindBy(name="portfolioMgmtTypeCode")
	private WebElement drpServices;
	
	@FindBy(name="profileId")
	private WebElement drpProfiles;
	
	@FindBy(name="startDate")
	private WebElement txtChangePeriodSD;
	
	@FindBy(name="endDate")
	private WebElement txtChangePeriodED;
	
	@FindBy(name="queryDate")
	private WebElement txtQueryDate;
	
	@FindBy(name = "enquiryDate")
    private WebElement btnViewEnquiry;
	
	@FindBy(name = "cancel")
    private WebElement btnReturn;
	
	
	
	/**		    
	    *   Application Page : Covers Tab
	    */
	
	@FindBy(name="coverAmountSavings")
	private WebElement txtCoverAmountSavings;
	
	@FindBy(name="target")
	private WebElement txtTarget;
	
	@FindBy(name="startAgeYears")
	private WebElement txtStartAgeYears;
	
	@FindBy(name="startAgeMonths")
	private WebElement txtStartAgeMonths;
	
	@FindBy(name="durationYears")
	private WebElement txtDurationYears;
	
	@FindBy(name="durationMonths")
	private WebElement txtDurationMonths;
	
	@FindBy(name = "but2")
    private WebElement btnCountAgeExpirydate;
	
	@FindBy(name = "but1")
    private WebElement btnCountAgeDuration;
	
	@FindBy(name = "but3")
    private WebElement btnCountStartEndDate;
	
	@FindBy(name = "submit")
    private WebElement btnYes; //
	
	/**		    
	    *   Application Page : Payment plan Tab
	    */
	
	@FindBy(name="mandateDate")
	private WebElement txtMandateDate;
	
	@FindBy(name="occuredDate")
	private WebElement txtEventDate;
	
	@FindBy(name="channelCostlessTransferCount") 
	private WebElement txtCountChannel;
	
	@FindBy(id="countToValues.yes")
	private WebElement rdbTransferCountYes; 
	
	@FindBy(id="countToValues.no")
	private WebElement rdbTransferCountNo; 
	
	@FindBy(id="changeCostsCharge.yes")
	private WebElement rdbTransferCostChargeYes;  // No methods created for all  payment elements
	
	@FindBy(id="changeCostsCharge.no")                   
	private WebElement rdbTransferCostChargedNo; 
	
	@FindBy(id="changeInvesmentPlan.yes")
	private WebElement rdbChangeInvesmentPlanYes; 
	
	@FindBy(id="changeInvesmentPlan.no")
	private WebElement rdbChangeInvesmentPlanNo; 
	
	@FindBy(name="exceptionChannelCode")
	private WebElement drpChannelTransferDone ;
	
	@FindBy(name="allocationTransferType")
	private WebElement drpTransferType;
	
	@FindBy(name = "selectTransferType")
    private WebElement btnView;
	
	@FindBy(name = "addInvestments") 
    private WebElement btnAddInvestments;
	
	@FindBy(xpath ="//input[@value='Count']")
    private WebElement btnCount;
	
	@FindBy(xpath="//table[@class='scrollTable']//tbody//tr//td//input")
	private WebElement txtChargePercent;  
	
	
	
	
	public ChangeCalPensionSavings() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	/**
	 * Methods for ALL
	 */
    
	public void clickBasicLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkBasic, "Basic");
	}
	
	public void clickCoversLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkCovers, "Covers");
	}
	
	public void clickSavingsLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkSavings, "Savings");
	}
	
	public void clickPaymentPlanLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkPaymentPlan, "Payment Plan");
	}
	
	public void clickInvestmentPlanLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkInvestmentPlan, "Investment Plan");
	}
	
	public void clickPrintingLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkPrinting, "Printing");
	}
	
	/**
	 * Methods for Cover tabs
	 */
	public void setCoverAmountSavings(String coverAmountSavings) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtCoverAmountSavings, "Cover Amount Savings",coverAmountSavings);
	
	}
	
	public void setTarget(String edittarget) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtTarget, "Edit target",edittarget);
	
	}
	
	public void setStartAgeYears(String startAgeYears) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtStartAgeYears, "Start Age Years",startAgeYears);
	
	}
	
	public void setStartAgeMonths(String startAgeMonths) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtStartAgeMonths, "Start Age Months",startAgeMonths);
	
	}
	
	public void setDurationYears(String durationYears) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtDurationYears, "Duration Years",durationYears);
	
	}
	
	public void setDurationMonths(String durationMonths) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtDurationMonths, "Duration Months",durationMonths);
	
	}
	
	public void clickCountAgeExpirydate() {
    	Context.global().getSeleniumUtils().clickOnElement(btnCountAgeExpirydate, "Count Age And Expiry date");
    }
	
	public void clickCountAgeDuration() {
    	Context.global().getSeleniumUtils().clickOnElement(btnCountAgeDuration, "Count Age And Duration");
    }
	
	public void clickCountStartAndEndDate() {
    	Context.global().getSeleniumUtils().clickOnElement(btnCountStartEndDate, "Count Start And End Date");
    }
	
	
	public void clickYes() {
    	Context.global().getSeleniumUtils().clickOnElement(btnYes, "Yes");
    }
	
	/**
	 * Methods for Savings tab
	 */
	public void clickReallocationSavingsLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkReallocationSavings, "Reallocation Of Savings");
	}
	
	public void clickChargePlanLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkChargePlan, "Charge Plan");
	}
	
	public void clickCapitalYieldInformationLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkCapitalYieldInformation, "Capital And Yield Information");
	}
	
	public void clickValueChangeInformationLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkValueChangeInformation, "Value Change Information");
	}
	
	public void clickPremiumGuaranteeLink(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkPremiumGuarantee, "Premium Guarantee");
	}
	
	public void clickShow() {
    	Context.global().getSeleniumUtils().clickOnElement(btnShow, "Show");
    }
	
	public  void selectServices(String valueServices){
        Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpServices, "visibleText", valueServices);
    }
	
	public  void selectProfiles(String valueProfiles){
        Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpProfiles, "visibleText", valueProfiles);
    }
	
	
	public  void selectChannelTransferDone(String valueChannel){
        Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpChannelTransferDone, "visibleText", valueChannel);
    }
	
	public  void selectTransferType(String valueTransfer){
        Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpTransferType, "visibleText", valueTransfer);
    }

	/**
	 * Methods for Payment tab 
	 */
	
	public void setMandateDate(String mandateDate) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtMandateDate, "Mandate Date",mandateDate);
	
	}
	
	public void setEventDate(String eventDate) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtEventDate, "Event Date",eventDate);
	
	}
	
	public void setCountChannel(String countChannel) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtCountChannel, "Count Channel",countChannel);
	
	}
	
	public void clickTransferCountYes(){
    	Context.global().getSeleniumUtils().clickOnElement(this.rdbTransferCountYes, " Transfer Count Yes");
    }
	
	public void clickTransferCountNo(){
    	Context.global().getSeleniumUtils().clickOnElement(this.rdbTransferCountNo, "Transfer Count No");
    }
	
	public void clickTransferCostYes(){
    	Context.global().getSeleniumUtils().clickOnElement(this.rdbTransferCostChargeYes, "TransferCostYes");
    }
	
	public void clickTransferCostNo(){
    	Context.global().getSeleniumUtils().clickOnElement(this.rdbTransferCostChargedNo, "Transfer Cost No");
    }
	
	public void clickChangeInvesmentPlanYes(){
    	Context.global().getSeleniumUtils().clickOnElement(this.rdbChangeInvesmentPlanYes, "Change Invesment Plan Yes");
    }
	
	public void clickChangeInvesmentPlanNo(){
    	Context.global().getSeleniumUtils().clickOnElement(this.rdbChangeInvesmentPlanNo, "Change Invesment Plan No");
    }
	
	public void clickView() {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnView, "View");
    }
	
	public void clickAddInvestments() {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnAddInvestments, "AddInvestments");
    }
	
	public void clickCount() {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCount, "Count");
    }
	
	public void setChargePercent(String chargePercent) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtChargePercent, "Charge Percent",chargePercent);
	
	}
	
	
	// No methods created for payment tab
	@Override
	public void verifyPageState() {
		// 
	}
	
}
