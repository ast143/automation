package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;


/** 
 * Description: This page includes all the web elements needed for running Linking Batch
 * Navigation: Home/WorkFlow > Operations > Start batch Runs > Linking/ Periodical Events New
 * 
 * 
 * 
 * Functionality Created By  	: Kapil Kapoor
  * Reviewed By                 : Nitesh Khanna
 * Review Date                	: 27/02/2017
 * Modified By 				   	: Mithen Kadam		
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017
*/

public class BatchDetailsPage implements Page {

	@FindBy(name= "policyMin")
	private WebElement txtPolicyMin;
	
	@FindBy(name= "policyMax")
	private WebElement txtPolicyMax;
	
	@FindBy(name= "runDate")
	private WebElement txtRunDate;

	@FindBy(name= "NFI_PRODUCT")
	private WebElement drpProduct;
	
	@FindBy(name= "start")
	private WebElement btnStart;
	
	@FindBy(name= "return")
	private WebElement btnReturn;
	
	public BatchDetailsPage() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public void setPolicyMin(String strText) {
		Context.global().getSeleniumUtils().enterText(txtPolicyMin, "policyMin", strText);
	}
	
	public void setPolicyMax(String strText) {
		Context.global().getSeleniumUtils().enterText(txtPolicyMax, "policyMax", strText);
	}
	
	public void setRunDate(String strText) {
		Context.global().getSeleniumUtils().enterText(txtRunDate, "Run Date",  strText);
	}
	
	public void clickProduct(String drpdownValue) {
		Context.global().getSeleniumUtils().selectValueFromDropDown(drpProduct, "visibleText", drpdownValue);
	}
	
	public void clickStart() {
		Context.global().getSeleniumUtils().clickOnElement(btnStart, "Start");
	}
	
	public void clickReturn() {
		Context.global().getSeleniumUtils().clickOnElement(btnReturn, "Return");
	}

	@Override
	public void verifyPageState() {
		//
		
	}
}
