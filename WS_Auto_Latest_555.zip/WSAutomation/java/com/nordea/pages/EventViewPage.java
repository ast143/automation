package com.nordea.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: Event View - This Page is for payment events. Payment are to be done through 
 * this page and can be verified from the same page.
 * Navigation to this page is by clicking on LHN >> Policy >> Events View
 * 
 * Abbreviations
 * VAEIC = View account events including cancelled
 * 
 * 
 * Functionality Created By  	: Kapil Kapoor
 * Reviewed By                 	: Nitesh Khanna
 * Review Date                	: 09/04/2017
 * Modified By 				   	: Mithen Kadam
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017 
*/
public class EventViewPage implements Page {								
	
	@FindBy(linkText= "View events")									
	private WebElement lnkViewEvents;
	
	@FindBy(linkText= "View letters")									
	private WebElement lnkViewLetters;
	
	@FindBy(linkText= "Payment and accounting reporting")				
	private WebElement lnkPaymentAccntReport;
	
	@FindBy(linkText= "View payment events")							
	private WebElement lnkPaymentEvents;
					
	@FindBy(linkText= "View account events")							
	private WebElement lnkAccntEvents;
	
	@FindBy(linkText= "View account events including cancelled")		
	private WebElement lnkVAEIC;	
	
	@FindBy(linkText= "View policy summary")							
	private WebElement lnkPolicySummary;
	
	@FindBy(linkText= "Attribute history")								
	private WebElement lnkAttributeHistory;	
	
	@FindBy(linkText= "Event history")									
	private WebElement lnkEventHistory;
	
	/*Element under View payment event tab STARTS*/
	
	@FindBy(xpath= "//h2[contains(text(), 'Invoiced payments')]//following-sibling::div[2]//a")
	private WebElement lnkPaymentDate;
	
	@FindBy(xpath= "//h2[contains(text(), 'Invoiced payments')]/../div[4]//tbody/tr/td[5]")
	private WebElement elmInvoiceMode;
	
	@FindBy(name= "resendPayment")
	private WebElement btnResendPayment;
	
	/*Elements under create premium button STARTS*/
	
	@FindBy(name= "create")
	private WebElement btnCreate;
	
	@FindBy(name= "searchAccountNumber")
	private WebElement btnSearchAccntNo;
	
	@FindBy(xpath= "//table/tbody/tr/td/a")
	private WebElement lnkAccountNumber;
	
	@FindBy(name= "submit")
	private WebElement btnSave;
	
	@FindBy(name= "createPremium")
	private WebElement btnCreatePremium;
	
	@FindBy(name= "org.apache.struts.taglib.html.CANCEL")
	private WebElement btnCancel;
	
	@FindBy(name= "submit")
	private WebElement btnOk;
	
	/*Elements under create premium button ENDS*/	
	
	/*Elements under Cancel direct debit payment button STARTS*/
	
	@FindBy(name= "cancelPremium")
	private WebElement btnCancelPremium;	
	
	@FindBy(name= "submit")
	private WebElement btnYes;
	
	@FindBy(xpath= "//h2[contains(text(), 'Future invoices')]//following-sibling::div[1]//table")
	private WebElement elmfutureInvoicesTable;
	/*Elements under Cancel direct debit payment button ENDS*/
	
	/*Element under View payment event tab END*/
	
	public EventViewPage(){
			PageFactory.initElements(Context.global().getDriver(), this);
	}
	
    public void clickViewEvents(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkViewEvents, "View events");
    }
	
    public void clickViewletters(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkViewLetters, "View letters");    	
    }
    
    public void clickPaymentAccountingReporting(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkPaymentAccntReport, "Payment and accounting reporting");  
    }
	
    public void clickViewPaymentEvents(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkPaymentEvents, "View payment events");  
    }
    
    public List<WebElement> fetchPaymentDates(String status){
    	
    	return Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Invoiced payments')]//following-sibling::div[2]//tr/td[last()][contains(text(),'"+status+"')]/../td[1]"));
    }
    
    
    public void clickViewAccountEvents(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkAccntEvents, "View account events");  
    }
    
    public void clickViewAccountEventsIncludingCancelled(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkVAEIC, "View account events including cancelled");
    }
    
    public void clickViewPolicySummary(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkPolicySummary, "View policy summary");
    }
    
    public void clickAttributeHistory(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkAttributeHistory, "Attribute History");
    }
    
    public void clickEventHistory(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkEventHistory, "Event History");
    }
    
    public void clickPaymentDate(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkPaymentDate, "Payment Date Link");
    }
    
    public String fetchInvoiceMode(){
    	return Context.global().getSeleniumUtils().getText(this.elmInvoiceMode);
    }
    
    public void clickResendPayment(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnResendPayment, "Resend Button");
    }
    
    public void clickCreatePremium(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCreate, "Create Premium");
    }
    
    public void clickFind(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnSearchAccntNo, "Find");
    }
    
    public void clickAccntNoLink(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkAccountNumber, "Nordea Account Number");
    }
    
    public void clickSave(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "Save");
    }
  
    public void clickSaveAndCreatePremium(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCreatePremium, "Save And Create Premium");
    }
    
    public void clickCancel(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCancel, "Cancel");
    }
    
    public void clickOk(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnOk, "Ok");
    }
    
    public void clickCancelDirectDebitPayment(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnCancelPremium, "Cancel direct debit payment");
    }
    
    public void clickYes(){
    	Context.global().getSeleniumUtils().clickOnElement(this.btnYes, "Yes");
    }
    
    public WebElement fetchFutureInvoiceTable() {
    	return elmfutureInvoicesTable;
    }
    
    public List<WebElement> fetchInvoicePeriodList(){
    	return Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Invoiced payments')]//following-sibling::div[2]//tr/td[last()]/../td[3]"));
    }
    
    public List<WebElement> fetchInvoiceStatusList(){
    	return Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Invoiced payments')]//following-sibling::div[2]//tr/td[9]"));
    }
    
    public List<WebElement> fetchEventDateList(){
    	return Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Invoiced payments')]//following-sibling::div[2]//tr/td[last()]/../td[2]"));
    }
    
    public List<WebElement> fetchInvoicePeriodWithIncompleteStatusList(){
    	return Context.global().getDriver().findElements(By.xpath("/h2[contains(text(), 'Invoiced payments')]//following-sibling::div[2]//tr/td[9][contains(text(),'Incomplete')]/../td[3]"));
    }
    
    public List<WebElement> fetchAmtWithIncompleteStatusList(){
    	return Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Invoiced payments')]//following-sibling::div[2]//tr/td[9][contains(text(),'Incomplete')]/../td[5]"));
    }
    
    public List<WebElement> fetchInvoicePeriodListPaymentPlanTab(){
    	return Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Invoicing Details')]//following-sibling::div//tr/td[1]"));
    }
    
    public List<WebElement> fetchInvoiceAmtListPaymentPlanTab(){
    	return Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Invoicing Details')]//following-sibling::div//tr/td[last()]"));
    }
    
    public List<WebElement> fetchPaymentPlanStartDate(){
    	return Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Regular premiums')]//following-sibling::div[1]//tr[2]/td[2]"));
    }

    @Override
	public void verifyPageState() {
		//
	}
}
