package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/** 
 * Description: This page includes all the web elements needed for validating the (event date), (event type), (event status)
 * Navigation: Policy > Event View > View Account Event
 * 
 * 
 * 
 * Functionality Created By  	: Kapil Kapoor
 * Reviewed By                  : Nitesh Khanna
 * Review Date                	: 23/02/2017
 * Modified By 				   	: Mithen Kadam	
 * Last Modified Date        	: 21/04/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 27/04/2017
*/
public class AccountEventsPage implements Page {

	@FindBy(xpath="//table[@class='scrollTable']//tbody//tr[1]/td[1]")
	private WebElement elmeventDate;
	
	@FindBy(xpath="//table[@class='scrollTable']//tbody//tr[1]/td[2]")
	private WebElement lnkeventType;
	
	@FindBy(xpath="//table[@class='scrollTable']//tbody//tr[1]/td[3]")
	private WebElement elmeventStatus;
	
	AccountEventsPage() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public String fetchEventDate() {
		return Context.global().getSeleniumUtils().getText(elmeventDate);
	}
	
	public String fetchEventType() {
		return Context.global().getSeleniumUtils().getText(lnkeventType);
	}
	
	public String fetchEventStatus() {
		return Context.global().getSeleniumUtils().getText(elmeventStatus);
	}
	
	@Override
	public void verifyPageState() {
		//
	}
	
}