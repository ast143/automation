package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/** 
 * Description: SearchResultPage- This page loads after searching the customer on DataSearchPage
 * 
 * 
 * Functionality Created By  	: Debabrata Behera
 * Reviewed By                 	: Poonam Joshi
 * Review Date                	: 10/12/2016
 * Modified By 				   	: Kapil Kapoor
 * Last Modified Date        	: 17/01/2017
 * Reviewed By					: Debabrata Behera
 * Review Date					: 17/01/2017
*/

public class SearchResultPage implements Page {

    @FindBy(xpath = "//table[@class='contentTable']//a")
    WebElement lnkCustomerID;
    
    public SearchResultPage() {
        PageFactory.initElements(Context.global().getDriver(), this); 
    }
    
    public String fetchCustomerID() {
    	return Context.global().getSeleniumUtils().getText(lnkCustomerID); 
    	
    }
    public void clickCustomerID() {
        Context.global().getSeleniumUtils().clickOnElement(lnkCustomerID, "Customer ID"); 
    }

@Override
	public void verifyPageState() {
		
	}
}
