package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
/**
 * Description: CustomerPage - This page has all the customer related web elements  
 * for example: contacts, Accounts, Address Details 
 * Navigating to this page by clicking on 'customer tab in LHN'
 * 
 * 
 * Functionality Created By  	: Poonam Joshi
 * Reviewed By                 	: Debabrata Behara
 * Review Date                	: 02/01/2017
 * Modified By 				   	: Kapil Kapoor (Correcting Naming Convention & Giving definition to the page)
 * Last Modified Date        	: 16/01/2017
 * Reviewed By					: Poonam Joshi
 * Review Date					: 20/01/2017
*/
public class CustomerPage implements Page {
	
	@FindBy(xpath = "//th[contains(text(),'Surname and forename(s)')]//following-sibling::td[1]")
	private WebElement txtCustomerName;
	
	@FindBy(xpath = "//th[contains(text(),'Customer ID')]//following-sibling::td[1]")
	private WebElement txtCustomerId;
	
	@FindBy(xpath = "//th[contains(text(),'Language')]//following-sibling::td[1]")
	private WebElement txtLanguage;
	
	@FindBy(linkText = "Contacts")
	private WebElement elmContactsTab;
	
	@FindBy(xpath = "//a[contains(text(),'Mailing address')]//..//following-sibling::td[1]")
	private WebElement txtCustomerAddress;
		
	@FindBy(linkText = "Mailing address")
	private WebElement lnkContactsMailingAddress;
	
	@FindBy(name = "contactPersonName")
	private WebElement txtContactsContactPerson;
	
	@FindBy(name = "coAddress")
	private WebElement txtContactsCo;
	
	@FindBy(name = "save")
	private WebElement btnContactsSave;
	
	@FindBy(xpath = "//a[text()='Accounts']")
	private WebElement elmAccountsTab;
	
	@FindBy(xpath = "//a[text()='Basic']")
	private WebElement elmBasicTab;
	
	@FindBy(name="addAccount")
	private WebElement btnAccountsAdd;
	
	@FindBy(name="IBAN")
	private WebElement txtAccountsIBAN;
	
	@FindBy(name="productLine")
	private WebElement chkAccountsProductLine;
	
	@FindBy(xpath = "//input[@value='Cancel']")
	private WebElement btnAccountsCancel;
	
	@FindBy(name="delete")
	private WebElement btncontactsDelete;
	
	@FindBy(name="return")
	private WebElement btnBasicReturn;
	
	@FindBy(xpath="//table/tbody/tr/td[2]")
	private WebElement elmAccountsAccountnumber;
	
	public CustomerPage() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public String fetchCustomerName() {
		return Context.global().getSeleniumUtils().getText(this.txtCustomerName).trim();
	}
	public String fetchAccountNumber(){
		return Context.global().getSeleniumUtils().getText(this.elmAccountsAccountnumber);
	}
	public String fetchCustomerId() {
		return Context.global().getSeleniumUtils().getText(this.txtCustomerId).trim();
	}
	
	public String fetchLanguage() {
		return Context.global().getSeleniumUtils().getText(this.txtLanguage).trim();
	}
	
	public void navigateToContactsTab()
	{
		Context.global().getSeleniumUtils().clickOnElement(this.elmContactsTab, "Contacts");
	}
	public void clickReturn()
	{
		Context.global().getSeleniumUtils().clickOnElement(this.btnBasicReturn, "Return");
	}
	public void navigateToBasicTab()
	{
		Context.global().getSeleniumUtils().clickOnElement(this.elmBasicTab, "Basic");
	}
	public void navigateToAccountsTab()
	{
		Context.global().getSeleniumUtils().clickOnElement(this.elmAccountsTab, "Accounts");
	}
	public String fetchCustomerAddress() {
		return Context.global().getSeleniumUtils().getText(this.txtCustomerAddress).replaceAll("\\s+", " ").trim();
	}
	public void clickMailingAddress() {
		Context.global()
				.getSeleniumUtils()
				.clickOnElement(this.lnkContactsMailingAddress,
						"Contact Mailing Address Link");
	}
	public void setContactPerson(String contPerson){
		Context.global()
				.getSeleniumUtils()
				.enterText(this.txtContactsContactPerson, contPerson,
						"Contact Person");
	}
	public void setContactCO(String contCO){
		Context.global().getSeleniumUtils()
				.enterText(this.txtContactsCo, contCO, "Contact Person");
	}
	public void clickSave(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnContactsSave, "Save");
	}
	public void clickAccountAdd(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAccountsAdd, "Add Account");
	}
	public void setIBAN(String iBAN){
		Context.global().getSeleniumUtils()
		.enterText(this.txtAccountsIBAN, "Add IBAN",iBAN);
	}
	public void clickProductLine(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.chkAccountsProductLine, "Select Product Line");
	}
	public void clickCancel(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnAccountsCancel, "Cancel");
	}
	public void clickDelete(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btncontactsDelete, "Delete");
	}
	
	@Override
	public void verifyPageState() {
		
		//		
	}

}
