package com.nordea.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: This page refers the elements for the event withdrawal plan
 * creation.
 * 
 * 
 * Functionality Created By : Pavan Kadam 
 * Reviewed By : Snehal Bahulekar 
 * Review
 * Date : 05/04/2017 
 * Modified By : Snehal Bahulekar 
 * Last Modified Date:06/04/2017 
 * Reviewed By : Poonam Joshi 
 * Review Date : 26/04/2017
 */

public class Withdrawal implements Page {

	@FindBy(xpath = "//a[text()='Savings']")
	private WebElement lnkSavings;

	@FindBy(linkText = "Withdrawal plan")
	private WebElement lnkWithdrawalPlan;

	@FindBy(name = "addSingle")
	private WebElement btnAddSingle;

	@FindBy(name = "addRegular")
	private WebElement btnAddRegular;

	@FindBy(name = "back")
	private WebElement btnReturn;

	@FindBy(name = "startDate")
	private WebElement txtRWStartDate;

	@FindBy(name = "endDate")
	private WebElement txtRWEndDate;

	@FindBy(name = "withdrawalAmount")
	private WebElement txtRWAmount;

	@FindBy(xpath = "//th[contains(text(),'Date')]/../../..//a")
	private List<WebElement> lnkWithdrawalPlanLink;

	@FindBy(name = "withdrawalFrequency")
	private WebElement drpRWFrequency;

	@FindBy(name = "paymentDay")
	private WebElement txtRWPaymentDay;

	@FindBy(name = "withdrawalOrder")
	private WebElement drpRWOrder;

	@FindBy(name = "accountNumberId")
	private WebElement drpRWAccountnumber;

	@FindBy(name = "save")
	private WebElement btnRWSave;

	@FindBy(name = "cancel")
	private WebElement btnRWCancel;

	@FindBy(id = "withdrawalPlanFunctionalityAllowed.yes")
	private WebElement rdbRWHandlingFeeYes;

	@FindBy(id = "withdrawalPlanFunctionalityAllowed.no")
	private WebElement rdbRWHandlingFeeNo;

	@FindBy(name = "openViewCustomer")
	private WebElement btnEditCustomer;

	@FindBy(xpath = "//div[@class='commentbox']")
	private WebElement elmCommentBox;

	@FindBy(xpath = "//div[@class='errorbox']")
	private WebElement elmErrorBox;

	@FindBy(xpath = "//th[contains(text(),'Savings')]/../td[1]")
	private WebElement elmSavingsAmt;
	
	@FindBy(xpath = "//thead/tr/th[contains(text(),'Period')]/../../../tbody/tr")
	private WebElement elmRegularWithdrawalDateRange;

	public Withdrawal() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}

	public void clickSavings() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkSavings, "Savings Tab");
	}

	public String fetchSavingsAmount() {
		return Context.global().getSeleniumUtils().getText(this.elmSavingsAmt).replace(" ", "").replace(",", ".").replace("EUR", "");
				//.replaceAll("[^0-9]", "");
	}

	public void clickWithdrawalPlan() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkWithdrawalPlan, "Withdrawal Plan");
	}

	public void clickAddSingle() {
		Context.global()
				.getSeleniumUtils()
				.clickOnElement(this.btnAddSingle,
						"Click Add for Single Withdrawal");
	}

	public void clickAddRegular() {
		Context.global()
				.getSeleniumUtils()
				.clickOnElement(this.btnAddRegular,
						"Click Add for Regular Withdrawal");
	}

	public void clickReturn() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnReturn, "Return");
	}

	public void setStartDate(String startDate) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtRWStartDate, "startDate", startDate);
	}

	public void setEndDate(String endDate) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtRWEndDate, "End Date", endDate);
	}

	public void setWithdrawalAmount(String withAmount) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtRWAmount, "Withdraw Amount", withAmount);
	}

	public String fetchWithdrawalAmount() {
		return Context.global().getSeleniumUtils().getText(this.txtRWAmount);

	}
	
	public String fetchErrorMessage() {
		return Context.global().getSeleniumUtils().getText(this.elmErrorBox);

	}

	public void selectFrequency(String drpdownValue) {
		Context.global()
				.getSeleniumUtils()
				.selectValueFromDropDown(this.drpRWFrequency, "visibleText",
						drpdownValue);
	}

	public void setPaymentDate(String paymentDate) {
		Context.global().getSeleniumUtils()
				.enterText(this.txtRWPaymentDay, "Payment Day", paymentDate);
	}

	public String fetchLastWithdrawalDate() {
		return Context
				.global()
				.getSeleniumUtils()
				.getText(
						this.lnkWithdrawalPlanLink
								.get(this.lnkWithdrawalPlanLink.size() - 1));
	}

	public boolean verifyErrorBox() {
		return Context.global().getSeleniumUtils()
				.verifyElementPresent(this.elmErrorBox, "Error Box");
	}
	
	public List<String> fetchRegWithDateRangeList(){
	List<WebElement> dateRangeElement= this.elmRegularWithdrawalDateRange.findElements(By.xpath("//tr//a"));
	List<String> dateRange = new ArrayList<String>();
	for(int i=0;i<dateRangeElement.size();i++)	{
		dateRange.add(dateRangeElement.get(i).getText());
	}
	return dateRange;
	}

	public void selectWithOrder(String drpdownValue) {
		Context.global()
				.getSeleniumUtils()
				.selectValueFromDropDown(this.drpRWOrder, "visibleText",
						drpdownValue);
	}

	public void selectAccountID(String drpdownValue) {

		Context.global()
				.getSeleniumUtils()
				.selectValueFromDropDown(this.drpRWAccountnumber,
						"visibleText", drpdownValue);
	}

	public String fetchAccountNumber() {
		return Context
				.global()
				.getSeleniumUtils()
				.getSelectedOptionfromDropdown(this.drpRWAccountnumber,
						"Selected Account Number");
	}

	public void clickSave() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnRWSave, "Save");
	}

	public void clickCancel() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnRWCancel, "Cancel");
	}

	public void clickYesHandlingFees() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.rdbRWHandlingFeeYes, " Yes radio button");
	}

	public void clickNoHandlingFees() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.rdbRWHandlingFeeNo, " No radio button");
	}

	public void clickEditCustomer() {
		Context.global().getSeleniumUtils()
				.clickOnElement(this.btnEditCustomer, "Edit Customer");
	}

	public boolean verifyCommentbox() {
		return Context.global().getSeleniumUtils()
				.verifyElementPresent(this.elmCommentBox, "Comment Box");
	}

	@Override
	public void verifyPageState() {
		
		//
	}

}
