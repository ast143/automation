package com.nordea.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
/** 
 * Description: This page contains web elements and methods for complete flow of updating execution results to Confluence.
 * 
 * Functionality Created By  	: Mithen Kadam
 * Reviewed By                 	: Debabrata Behera
 * Modified By 				   	:
 * Last Modified Date        	: 
 * Reviewed By					:
 * Review Date					: 
*/

public class Confluence implements Page{

	@FindBy(name="os_username")
	private WebElement txtUsername;
	
	@FindBy(name="os_password")
	private WebElement txtPassword;
	
	@FindBy(name="login")
	private WebElement btnLogin;
		
	@FindBy(id="create-page-button")
	private WebElement lnkAddReport;
	
	@FindBy(id="file-list-page-title")
	private WebElement txtFname;

	@FindBy(id="file-list-page-description")
	private WebElement txtFDesc;
	
	@FindBy(xpath="//button[text()='Create']")
	private WebElement lnkCreate;

	@FindBy(xpath="//label[text()='Upload file']/../input")
	private WebElement btnBrowse;
	
	@FindBy(xpath="//span[@class='template-preview file-list-blueprint-icon large']")
	private WebElement elmFldrSelect;
	
	@FindBy(name="confirm")
	private WebElement btnUpload;
	
	public Confluence(WebDriver driver){
		PageFactory.initElements(driver, this);
	}

	public void clickAddReport()
	{
		Context.global().getSeleniumUtils().clickOnElement(this.lnkAddReport,"AddReport");
	}

	public void clicklogin() {
		
		Context.global().getSeleniumUtils().clickOnElement(this.btnLogin,"LoginButton");
	
	}

	public void setUserid(String userid){
		
		 Context.global().getSeleniumUtils().enterText(this.txtUsername, "Username",userid);
	}

	public void setPassword(String pwd){
	
		Context.global().getSeleniumUtils().enterText(this.txtPassword,"Password",pwd);
	
	}
	
	public void setFldrName(String fldrname){
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsDisplayed(this.txtFname, 5);
		Context.global().getSeleniumUtils().enterText(this.txtFname, "FolderName",fldrname);
	}
	
	public void setFldrDesc(String fldrdesc){
		 Context.global().getSeleniumUtils().enterText(this.txtFDesc, "FolderName",fldrdesc);
	}
		
	public void clickCreate() {
		Context.global().getSeleniumUtils().clickOnElement(this.lnkCreate,"CreateReportButton");
	}
	
	public void clickBrowse() {
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsClickable(this.btnBrowse, 5);
		Context.global().getSeleniumUtils().clickOnElement(this.btnBrowse,"BrowseButton");
	}
	
	public void doubleClickFolder(){
		Context.global().getSeleniumUtils().doubleclickonElement(this.elmFldrSelect, "Folder Icon");
	}
	
	public void clickUpload(){
		Context.global().getSeleniumUtils().waitForSpecificTimeTillElementIsClickable(this.btnUpload, 5);
		Context.global().getSeleniumUtils().clickOnElement(this.btnUpload, "Upload");
	}

	@Override
	public void verifyPageState() {
		//		
	}

	

	
	
}

