package com.nordea.pages;

/**
 * 'VerifyPage' interface is used for providing a method verifyPageState which
 * should be implemented by every page class
 */
public interface Page {
	/**
	 * 'verifyPageState' method is being used for checking pageState before any
	 * operation is being performed on the page and body of the method should be
	 * provided by each page class
	 */
	public void verifyPageState();
}