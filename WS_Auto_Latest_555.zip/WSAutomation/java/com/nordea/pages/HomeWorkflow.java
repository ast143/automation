package com.nordea.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;


	/**
	 * Description: HoweWorkFlow - It manages tasks and operations where operations belong to daily routine operations,
	 * Batch actions, Printout actions and Other actions
	 * 
	 * 
	 * 
	 * Naming convention guidelines
	 * OSBR=Operations Starting Batch Runs
	 * OBEL=Operations Batch Entry Log
	 * OIP=Operations Incoming Payments
	 * ODDA=Operations Direct Debit Authorization
	 * OEIDPA=Operations Einvoice Direct Payment Authorization
	 * OCPR=Operations Create Printout Request
	 * OVPR=Operations View Printout Request
	 * PIAD=Pension Insurance Annual Declaration
	 * PIATDT=Pension Insurance Annual Tax Declaration Transmission
	 *
	 * Functionality Created By  	: Poonam Joshi
	 * Reviewed By                 	: Debabrata Behara
	 * Review Date                	: 11/01/2017
	 * Modified By 				   	: Mithen Kadam	
	 * Last Modified Date        	: 21/04/2017
	 * Reviewed By					: Poonam Joshi
	 * Review Date					: 27/04/2017
	 * 
	*/
public class HomeWorkflow implements Page {
	
	@FindBy(linkText="Operations")
	private WebElement lnkOperations;
	
	@FindBy(linkText="Starting batch runs")
	private WebElement lnkOSBR;
	
	@FindBy(linkText="Batch entry log")
	private WebElement lnkOBEL;
	
	@FindBy(linkText="Incoming payments")
	private WebElement lnkOIP;
	
	@FindBy(linkText="Enter prices")
	private WebElement lnkOperationsEnterPrices;
	
	@FindBy(linkText="Workflow tasks")
	private WebElement lnkOperationsWorkflowTasks;
	
	@FindBy(linkText="Flow items")
	private WebElement lnkOperationsFlowItems;
	
	@FindBy(linkText="Direct debit authorizations")
	private WebElement lnkODDA;
	
	@FindBy(xpath="//a[contains(text(),'E-invoice')][contains(text(),'and Direct Payment authorizations')]")
	private WebElement lnkOEIDPA;
	
	@FindBy(linkText="Create printout request")
	private WebElement lnkOCPR;
	
	@FindBy(linkText="View printout request")
	private WebElement lnkOVPR;
	
	@FindBy(linkText="Create letter")
	private WebElement lnkOperationsCreateLetter;
	
	@FindBy(linkText="Send letter")
	private WebElement lnkOperationsSendLetter;
	
	@FindBy(linkText="Collect pension insurance annual declaration")
	private WebElement lnkOperationsCollectPIAD;
	
	@FindBy(linkText="Check pension insurance annual declaration")
	private WebElement lnkOperationsCheckPIAD;
	
	@FindBy(linkText="Pension insurance annual tax declaration transmission")
	private WebElement lnkOperationsPIATDT;
	
	
	@FindBy(linkText="Annual AccountStatementPrintout")
	private WebElement lnkActStatPrintout;
	
	@FindBy(name = "NFI_PRINTOUT_TYPE")
    private WebElement drpPrintoutType;
	
	@FindBy(name = "policyMin")
    private WebElement txtPolicyMin;
	
	@FindBy(name = "policyMax")
    private WebElement txtPolicyMax;
	
	@FindBy(name = "queryStartDate")
    private WebElement txtPolicyStartDate;
	
	@FindBy(name = "queryEndDate")
    private WebElement txtPolicyEndDate;
	
	@FindBy(name = "start")
    private WebElement btnStart;
    
	@FindBy(xpath="//input[@value='02']") // "//td[contains(.,'Holder')]//input[@type='radio']"
	private WebElement rdbHolder;
	
	@FindBy(xpath="//input[@value='013']") // "//td[contains(.,'Trustee')]//input[@type='radio']"
	private WebElement rdbTrustee;
	
	@FindBy(xpath="//input[@value='14']") // "//td[contains(.,'Representative')]//input[@type='radio']"
	private WebElement rdbRepresentative ;
	
	@FindBy(xpath="//input[@value='16']") // "//td[contains(.,'Minor')]//input[@type='radio']"
	private WebElement rdbMinor ;
	
	@FindBy(xpath="//input[@value='17']") // "//td[contains(.,'Holder and Insured')]//input[@type='radio']"
	private WebElement rdbHolderInsured ;
	
	@FindBy(name="indexedProductChosen[0]") // "(//td[contains(text(),'Nordea Endowment')]//preceding-sibling::td)[contains(.,'11')]//preceding-sibling::td//input"
	private WebElement chkPrd11 ;	
		
	@FindBy(name="indexedProductChosen[2]")
	private WebElement chkPrd2 ;
	
	@FindBy(name="indexedProductChosen[3]")
	private WebElement chkPrd21 ;
	
	@FindBy(name="indexedProductChosen[4]")
	private WebElement chkPrd3 ;	
	
	@FindBy(name="indexedProductChosen[6]")
	private WebElement chkPrd39 ;
	
	@FindBy(name="indexedProductChosen[7]")
	private WebElement chkPrd4 ;
	
	@FindBy(name="indexedProductChosen[9]")
	private WebElement chkPrd5 ;
	
	@FindBy(name="indexedProductChosen[10]")
	private WebElement chkPrd51 ;
	
	@FindBy(name="indexedProductChosen[11]")
	private WebElement chkPrd58 ;
	
	@FindBy(name="indexedProductChosen[12]")
	private WebElement chkPrd6 ;
	
	@FindBy(name="indexedProductChosen[13]")
	private WebElement chkPrd61 ;
	
	@FindBy(name="indexedProductChosen[14]")
	private WebElement chkPrd7 ;
	
	@FindBy(name="indexedProductChosen[15]")
	private WebElement chkPrd8 ;
	
	@FindBy(name="indexedProductChosen[16]")
	private WebElement chkPrd9 ;	

	@FindBy(name="policyModesSelected")
	private WebElement elmpolicyMode ;
	
	
	
	
	
	public HomeWorkflow() {
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public void clickOperations(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOperations, "Operations");
	}
	
	public void clickStartingBatchRuns(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOSBR, "Starting Batch Runs");
	}
	
	public void clickBatchEntryLog(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOBEL, "Batch Entry Log");
	}
	public void clickIncomingPayments(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOIP, "Incoming Payments");
	}
	public void clickEnterPrices(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOperationsEnterPrices, "Enter prices");
	}
	public void clickWorkflowTasks(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOperationsWorkflowTasks, "Workflow Tasks");
	}
	public void clickFlowItems(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOperationsFlowItems, "Flow Items");
	}
	public void clickDirectDebitAutho(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkODDA, "Direct Debit Authorizations");
	}
	public void clickEinvoiceDirectPaymentAutho(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOEIDPA, "E-invoice and Direct Payment Authorizations");
	}
	public void clickCreatePrintoutRequest(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOCPR, "Create Printout Request");
	}
	public void clickViewPrintoutRequest(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOVPR, "View Printout Request");
	}
	public void clickCreateLetter(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOperationsCreateLetter, "Create Letter");
	}
	public void clickSendLetter(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOperationsSendLetter, "Send Letter");
	}
	public void clickCollectPIAD(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOperationsCollectPIAD, "Collect Pension Insurance Annual Declaration");
	}
	public void clickCheckPIAD(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOperationsCheckPIAD, "Check Pension Insurance Annual Declaration");
	}
	public void clickPIATDT(){
		Context.global().getSeleniumUtils()
				.clickOnElement(this.lnkOperationsPIATDT, "Pension Insurance Annual Tax Declaration Transmission");
	}


	public void clickAccStatPrintoutlnk(){
    	Context.global().getSeleniumUtils().clickOnElement(this.lnkActStatPrintout, "Account Statement Printout link");
    }
	
	public void clickPrintoutTypeDropdown(){
    	Context.global().getSeleniumUtils().clickOnElement(this.drpPrintoutType, "Printout type dropdown");
    }
	
	public void setPolicyMin(String policyMin){
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyMin, "Policy min", policyMin);
	} 
	
	public void setPolicyMax(String policyMax){
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyMax, "Policy max", policyMax);
	} 
	
	public void setPolicyStartDate(String policyStartDate){
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyStartDate, "Policy start date", policyStartDate);
	} 
	
	public void setPolicyEndDate(String policyEndDate){
    	Context.global().getSeleniumUtils().enterText(this.txtPolicyEndDate, "Policy end date", policyEndDate);
	} 
	
	public void clickStart(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnStart, "start button");
	}
	
	public void clickHolder(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.rdbHolder, "Holder radio button");
	}
	 
	public void clickTrustee(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.rdbTrustee, "Trustee radio button");
	}
	
	public void clickRepresentative(){
    	Context.global().getSeleniumUtils().clickOnElement(this.rdbRepresentative, "Representative radio button");
	}
	
	public void clickMinor(){
    	Context.global().getSeleniumUtils().clickOnElement(this.rdbMinor, "Minor radio button");
	}
	
	public void clickHolderInsured(){
    	Context.global().getSeleniumUtils().clickOnElement(this.rdbHolderInsured, "Holder/Insured radio button");
	}
		
	public void clickPrd11(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd11, "Product 11 checkbox");
    }
	
	public void clickPrd2(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd2, "Product 2 checkbox");
    }
	
	public void clickPrd21(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd21, "Product 21 checkbox");
    }
		
	public void clickPrd3(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd3, "Product 3 checkbox");
    }
	
	public void clickPrd39(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd39, "Product 39 checkbox");
    }
	
	public void clickPrd4(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd4, "Product 4 checkbox");
    }
	
	public void clickPrd5(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd5, "Product 5 checkbox");
    }
	
	public void clickPrd51(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd51, "Product 51 checkbox");
    }
	
	public void clickPrd58(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd58, "Product 58 checkbox");
    }
	
	public void clickPrd6(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd6, "Product 6 checkbox");
    }
	
	public void clickOnPrd61(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd61, "Product 61 checkbox");
    }
	
	public void clickPrd7(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd7, "Product 7 checkbox");
    }
	
	public void clickPrd8(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd8, "Product 8 checkbox");
    }
	
	public void clickPrd9(){
    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrd9, "Product 9 checkbox");
    }
	
	public void clickPolicyMode(){
    	Context.global().getSeleniumUtils().clickOnElement(this.elmpolicyMode, "Policy Mode checkbox");
    }
	
	
	
	
	@Override
	public void verifyPageState() {
		//		
	}
}

