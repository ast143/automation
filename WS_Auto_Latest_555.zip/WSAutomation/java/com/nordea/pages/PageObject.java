package com.nordea.pages;

import java.util.HashMap;
import java.util.Map;

/**
 * Pages class provides a generic getPage method for getting page
 * 
 * @author Nitesh Khanna
 * 
 */
public class PageObject {

	private Map<Class<?>, Page> pages = new HashMap<>();

	/**
	 * 'getPage' method is being used for providing Page object and for checking
	 * page state
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public <T> T getPage(Class<T> page) throws Exception {
		//Context.global().getSeleniumUtils().waitForPageToLoad(90);

		if (!pages.containsKey(page)) {
			Page pageInstance = (Page) page.newInstance();
			pages.put(page, pageInstance);
		}

		Page pageInstance = pages.get(page);
		pageInstance.verifyPageState();
		return (T) pageInstance;
	}

}