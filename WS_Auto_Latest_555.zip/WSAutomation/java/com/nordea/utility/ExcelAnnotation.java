package com.nordea.utility;

import java.lang.annotation.Retention;
import java.lang.annotation.ElementType;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation being used for storing excel file name
 * and sheet name
 * @author Nitesh Khanna
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface ExcelAnnotation {
	String filename();

	String sheetname();
}