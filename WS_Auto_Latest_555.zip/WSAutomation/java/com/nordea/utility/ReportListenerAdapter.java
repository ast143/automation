package com.nordea.utility;

import java.util.List;

import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;

/**
 * Class being used for creating a listner
 * @author Nitesh Khanna
 *
 */
public class ReportListenerAdapter implements IReporter {

	@Override
	public void generateReport(List<XmlSuite> xml, List<ISuite> suites,
			String outdir) {
	}

}