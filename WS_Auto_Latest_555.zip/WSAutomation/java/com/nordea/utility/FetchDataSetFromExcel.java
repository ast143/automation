package com.nordea.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.nordea.framework.Context;

/**
 * Class being used for fetching data from excel
 * 
 * @author Nitesh Khanna
 * 
 */
public class FetchDataSetFromExcel {
	private String testCaseName=null;
	final static Logger logger = Logger.getLogger(FetchDataSetFromExcel.class);
	HashMap<Integer, LinkedHashMap<String, String>> hashDataSet = new HashMap<Integer, LinkedHashMap<String, String>>();

	/**
	 * Method being used for storing all the data values from an excel sheet
	 * having execution value as 'Y'
	 * 
	 * @param strXCompleteXlspath
	 * @param strSheetName
	 * @return
	 */
	private HashMap<Integer, LinkedHashMap<String, String>> makeTestData(
			String strXCompleteXlspath, String strSheetName) {
		FetchDataSetFromExcel fetchDataSet = new FetchDataSetFromExcel();
		XSSFSheet sheet = null;
		try {
			FileInputStream xlsFile = new FileInputStream(strXCompleteXlspath);
			
			XSSFWorkbook workBook = new XSSFWorkbook(xlsFile);
			sheet = workBook.getSheet(strSheetName);
			int totalIterations = sheet.getLastRowNum();
			int columnIndex = -1;
			int testDataIndex = -1;
			// Row zero (0) is dedicated or reserved for HEADERS so Lets find
			// out dataSetExecutionFlag column index.
			for (int y = 0; y < sheet.getRow(1).getLastCellNum(); y++) {
				if (sheet.getRow(1).getCell(y).getStringCellValue()
						.equals("Test Case Name")) {
					columnIndex = y;
				}
				if (sheet.getRow(1).getCell(y).getStringCellValue()
						.equals("TestDataCount")){
					testDataIndex = y;
					break;
				}
			}
			
			if(testDataIndex!=-1) {
				for (int rowCount = 2, validRows = 1; rowCount <= totalIterations; rowCount++) {
					if (sheet.getRow(rowCount).getCell(columnIndex)
							.getStringCellValue().equals(testCaseName)) {
						int replicaCount=Integer.parseInt(sheet.getRow(rowCount).getCell(testDataIndex).getStringCellValue());
						for(int count=0; count<replicaCount; count++){
							hashDataSet.put(validRows - 1,
								fetchDataSet.getRowData(sheet, rowCount));
							validRows++;
						}
					}
				}
			}else {
				for (int rowCount = 2, validRows = 1; rowCount <= totalIterations; rowCount++) {
					if (sheet.getRow(rowCount).getCell(columnIndex)
							.getStringCellValue().equals(testCaseName)) {
							hashDataSet.put(validRows - 1,
								fetchDataSet.getRowData(sheet, rowCount));
							validRows++;
					}
				}
			}
			if(hashDataSet.size()==0)
			{
				logger.info("No Test data found for test case: " + testCaseName);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return hashDataSet;
	}
	
	/**
	 * Method being used for storing data of row in a haspMap
	 * 
	 * @param sheet
	 * @param rowCount
	 * @return
	 */
	LinkedHashMap<String, String> getRowData(XSSFSheet sheet, int rowCount) {
		LinkedHashMap<String, String> hashRowData = new LinkedHashMap<String, String>();
		XSSFRow headerRow = sheet.getRow(1);
		XSSFRow row = sheet.getRow(rowCount);
		int totalInputValues = row.getLastCellNum();
		for (int cellCount = 0; cellCount < totalInputValues; cellCount++) {
			XSSFCell headerCell = headerRow.getCell(cellCount);
			XSSFCell cell = row.getCell(cellCount,
					org.apache.poi.ss.usermodel.Row.CREATE_NULL_AS_BLANK);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			String cellValue = cell.getStringCellValue();
			hashRowData.put(headerCell.getStringCellValue(), cellValue);
		}
		return hashRowData;
	}

	/**
	 * Method used for storing data with specific file and sheet name in a
	 * hashMap
	 * 
	 * @param excelFileName
	 * @param strSheetName
	 * @return
	 */
	public HashMap<Integer, LinkedHashMap<String, String>> getTestDataInHashMap(
			String excelFileName, String strSheetName) {
		String strXCompleteXlspath = System.getProperty("user.dir")
				+ File.separator + "src" + File.separator + "test"
				+ File.separator + "resources" + File.separator + "testdata"
				+ File.separator + excelFileName + ".xlsx";
		return makeTestData(strXCompleteXlspath, strSheetName);
	}

	/**
	 * Method being used for getting a data from a particular row in excel sheet
	 * 
	 * @param hashMap
	 * @param rowNumber
	 * @return
	 */
	public LinkedHashMap<String, String> getData(
			HashMap<Integer, LinkedHashMap<String, String>> hashMap,
			int rowNumber) {
		LinkedHashMap<String, String> hashData = null;
		hashData = hashMap.get(rowNumber);
		return hashData;
	}

	/**
	 * Method being used for Modifying test data in a an excel sheet
	 * 
	 * @param hashMap
	 * @param excelFileName
	 * @param strSheetName
	 * @param rowNumber
	 * @param colHead
	 * @param modifiedValue
	 * @return
	 * @throws IOException
	 */
	public LinkedHashMap<String, String> modifyData(
			HashMap<Integer, LinkedHashMap<String, String>> hashMap,
			String excelFileName, String strSheetName, int rowNumber,
			String colHead, String modifiedValue) throws IOException {
		String strXCompleteXlspath = System.getProperty("user.dir")
				+ File.separator + "src" + File.separator + "main"
				+ File.separator + "resources" + File.separator + "dataset"
				+ File.separator + excelFileName + ".xlsx";
		LinkedHashMap<String, String> hashData = null;
		hashData = hashMap.get(rowNumber - 1);
		hashData.put(colHead, modifiedValue);
		FileInputStream xlsFile = new FileInputStream(strXCompleteXlspath);
		XSSFWorkbook workBook = new XSSFWorkbook(xlsFile);
		XSSFSheet sheet = workBook.getSheet(strSheetName);
		sheet.getRow(rowNumber).getCell(1).setCellValue(modifiedValue);
		xlsFile.close();
		FileOutputStream outputFile = new FileOutputStream(new File(
				strXCompleteXlspath));
		workBook.write(outputFile);
		outputFile.close();
		return hashData;
	}

	public void setExcelCellData() throws Exception {

		FileInputStream fsIP = new FileInputStream(new File(
				System.getProperty("user.dir") + File.separator + "src"
						+ File.separator + "main" + File.separator
						+ "resources" + File.separator + "files-to-upload"
						+ File.separator + "Store_SAK_Template.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fsIP); // Access the workbook
		XSSFSheet worksheet = wb.getSheetAt(0);
		Cell cell = null;
		cell = worksheet.getRow(1).getCell(3);
		cell.setCellValue(SeleniumUtils.generateRandomWord(6));
		cell = worksheet.getRow(1).getCell(4);
		cell.setCellValue(SeleniumUtils.generateRandomWord(9));
		fsIP.close();
		FileOutputStream outputFile = new FileOutputStream(new File(
				System.getProperty("user.dir") + File.separator + "src"
						+ File.separator + "main" + File.separator
						+ "resources" + File.separator + "files-to-upload"
						+ File.separator + "Store_SAK_Template.xlsx"));
		wb.write(outputFile); // write changes
		outputFile.close(); // close the stream
	}

	/**
	 * Method being used for getting total number of test data in HashMap
	 * 
	 * @param hashMap
	 * @return
	 */
	public long totalNumberOfTestData(
			HashMap<Integer, LinkedHashMap<String, String>> hashMap) {
		long count = 0;
		count = hashMap.size();
		return count;
	}

	/**
	 * Method being used for converting a dataset to Object Array
	 * 
	 * @param fileName
	 * @param sheetName
	 * @return
	 */
	public Object[][] getDataSetAsObjectArray(String fileName, String sheetName, String methodName) {
		this.testCaseName = methodName;
		HashMap<Integer, LinkedHashMap<String, String>> hashMap = Context
				.global().getDataSet()
				.getTestDataInHashMap(fileName, sheetName);
		Object[][] objectArray = new Object[(int) Context.global().getDataSet()
				.totalNumberOfTestData(hashMap)][1];
		for (int i = 0; i < Context.global().getDataSet()
				.totalNumberOfTestData(hashMap); i++) {
			objectArray[i][0] = Context.global().getDataSet()
					.getData(hashMap, i);
		}
		return objectArray;
	}

	/**
	 * Method being used for fetching column values, separated with New Line
	 * 
	 * @param dataSetTestData
	 * @param columnName
	 * @return
	 */
	public String[] getMultipleValuesFromColumn(
			LinkedHashMap<String, String> dataSetTestData, String columnName) {
		String str = dataSetTestData.get(columnName);
		return str.trim().split("\n");
	}

	/**
	 * Method being used for fetching column values, separated with semi-colon
	 * 
	 * @param dataSetTestData
	 * @param columnName
	 * @return
	 */
	public LinkedHashMap<String, String> fetchColumnValuesAsHashMap(
			LinkedHashMap<String, String> dataSetTestData, String columnName) {
		String str = dataSetTestData.get(columnName);
		String[] strSplit = str.trim().split(";");
		String[] strKeyValue = new String[2];
		LinkedHashMap<String, String> columnData = new LinkedHashMap<String, String>();
		for (int count = 0; count < strSplit.length; count++) {
			strKeyValue = strSplit[count].trim().split("=");
			columnData.put(strKeyValue[0], strKeyValue[1]);
		}
		return columnData;
	}

}