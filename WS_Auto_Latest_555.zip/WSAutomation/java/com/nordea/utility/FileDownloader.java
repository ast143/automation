package com.nordea.utility;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebElement;

import com.nordea.framework.Context;

/**
 * This class contains functions related to downloading Pdf from link
 * 
 * @author Nitesh Khanna
 * 
 */

public class FileDownloader {

	private static final Logger LOG = Logger.getLogger(FileDownloader.class);
	private String localDownloadPath = System.getProperty("user.dir")
			+ "\\src\\test\\resources\\saved-files\\";

	/**
	 * * Download the file specified in the href attribute of a WebElement * * @param
	 * element * @return * @throws Exception
	 */
	public synchronized void downloadFile(WebElement element, String fileName)
			throws Exception {
		downloader(element, fileName, "href");
	}

	/**
	 * * Perform the file/image download. * * @param element * @param attribute
	 * * @return * @throws IOException * @throws NullPointerException
	 */
	private void downloader(WebElement element, String fileName,
			String attribute) throws IOException, NullPointerException,
			URISyntaxException {
		String fileToDownloadLocation = element.getAttribute(attribute);
		if (fileToDownloadLocation.trim().equals(""))
			throw new NullPointerException(
					"The element you have specified does not link to anything!");

		File downloadedFile = new File(this.localDownloadPath + fileName
				+ ".pdf");
		if (downloadedFile.canWrite() == false)
			downloadedFile.setWritable(true);

		URLConnection connection = new URL(fileToDownloadLocation)
				.openConnection();
		for (Cookie cookie : Context.global().getDriver().manage().getCookies()) {
			String cookieHeader = cookie.getName() + "=" + cookie.getValue();
			connection.addRequestProperty("Cookie", cookieHeader);
		}
		InputStream input = connection.getInputStream();
		FileUtils.copyInputStreamToFile(input, downloadedFile);
		LOG.info("File Downlaoded to location:" + downloadedFile);
	}

}