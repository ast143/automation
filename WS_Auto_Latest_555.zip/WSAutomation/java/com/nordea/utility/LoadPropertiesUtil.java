package com.nordea.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * LoadPropertiesUtil loads the properties from a given properties file
 * 
 * @author Nitesh Khanna
 * Updated by: Debabrata Behera
 */
public class LoadPropertiesUtil {
	final static Logger logger = Logger.getLogger(LoadPropertiesUtil.class);
	public static Properties configProps;
	Properties prop = new Properties();
	static {
		try {
			configProps = LoadPropertiesUtil.loadConfigProperties();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Finds the file with the given file name in the classpath and loads the
	 * properties provided in it.
	 * 
	 * @param filename
	 *            :filename of the properties(key=value)file:Stored under the
	 *            source folder
	 * @return Properties object
	 * @throws IOException
	 * @throws IOException
	 *             :any derivation of java.io.IOException thrown by the loader.
	 */
	public Properties loadPropertiesFromClasspath(String filename)
			throws IOException {

		Properties props = new Properties();
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream(filename);
		if (inputStream == null) {
			throw new FileNotFoundException("property file '" + filename
					+ "' not found in the classpath");
		}
		props.load(inputStream);
		return props;
	}

	/**
	 * Loads the properties from a given file.
	 * 
	 * @param filename
	 *            :filename of the properties(key=value)file:Stored under the
	 *            user defined folder
	 * @return Properties object
	 * @throws IOException
	 *             :any derivation of java.io.IOException thrown by the parser
	 *             itself.
	 * @throws FileNotFoundException
	 *             :exception if file is not found in the defined location
	 */
	public Properties loadPropertiesFromFile(String filename)
			throws FileNotFoundException, IOException {
		Properties props = new Properties();
		props.load(new FileReader(""+filename));
		return props;
	}

	/**
	 * Method being used for loading configuration file
	 * 
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static Properties loadConfigProperties()
			throws FileNotFoundException, IOException {
		LoadPropertiesUtil prop = new LoadPropertiesUtil();
		configProps = prop.loadPropertiesFromFile(System
				.getProperty("user.dir")
				+ File.separator
				+ "src"
				+ File.separator
				+ "main"
				+ File.separator
				+ "resources"
				+ File.separator
				+ "config"
				+ File.separator
				+ "config.properties");

		return configProps;
	}
	
	public static Properties loadNordeaHoliday()
			throws FileNotFoundException, IOException {
		LoadPropertiesUtil prop = new LoadPropertiesUtil();
		return prop.loadPropertiesFromFile(System
				.getProperty("user.dir")
				+ File.separator
				+ "src"
				+ File.separator
				+ "main"
				+ File.separator
				+ "resources"
				+ File.separator
				+ "nordeaHolidays"
				+ File.separator
				+ "nordeaHolidayList.properties");
	}
	

		/** 
		 * This method is used for writing the data to properties file which can be used further in application at run time. 
		*/
		public void writeToAppPropsFile(String key, String value){
			try {
				OutputStream output = new FileOutputStream(
						System.getProperty("user.dir") + File.separator + 
						"src" + File.separator + "test" + File.separator + "resources" + 
						File.separator + "prop-file" + File.separator + "appdata.properties");
				prop.setProperty(key, value);
				prop.store(output, null);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} 
		
		/** 
		 * This method is used for fetching the value from appdata.properties file through its key 
		 * @throws IOException 
		 * @throws FileNotFoundException 
		*/
		public String fetchValueFromAppPropsFile(String key) throws FileNotFoundException, IOException {
			prop.load(new FileReader(
						System.getProperty("user.dir") + File.separator + 
						"src" + File.separator + "test" + File.separator + "resources" + 
						File.separator + "prop-file" + File.separator + "appdata.properties"));
			return prop.getProperty(key);
		} 

		public String fetchValueFromAccountPropsFile(String key) throws FileNotFoundException, IOException{
			prop.load(new FileReader(System
					.getProperty("user.dir")
					+ File.separator
					+ "src"
					+ File.separator
					+ "main"
					+ File.separator
					+ "resources"
					+ File.separator
					+ "accountNumbers"
					+ File.separator
					+ "Accounts.properties"));
			return prop.getProperty(key);			
		}
}