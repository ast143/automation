package com.nordea.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.nordea.framework.Context;

/**
 * Class being used for instantiating a Browser
 * @author Nitesh Khanna
 *
 */
public class DriverUtils {
	final static Logger logger = Logger.getLogger(DriverUtils.class);
	private DriverUtils driverUtil;

	/**
	 * Method being used for get a DriverUtils instance
	 * @return
	 */
	public DriverUtils getDriverUtilsInstance() {
		if (driverUtil == null) {
			driverUtil = new DriverUtils();
		}
		return driverUtil;
	}

	/**
	 * Method being used for instantiating a driver
	 * @param mtd
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void initiateDriver(Method mtd) throws FileNotFoundException, IOException, InterruptedException {
		String strBrowser = LoadPropertiesUtil.configProps.getProperty("BrowserName");
		ThreadLocal<ParallelFileAppender> prApp = new ThreadLocal<ParallelFileAppender>();

		if (strBrowser.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\src\\main\\resources\\drivers\\chromedriver.exe");
			RemoteWebDriver webDriver = new ChromeDriver();
			Context.global().setDriver(webDriver);
			File session = new File(System.getProperty("user.dir") + "\\logs\\" + LoggingUtils.executionFolder.getName() + "\\" + mtd.getName() + "_"
					+ webDriver.getSessionId() + "\\logs");
			session.mkdirs();
			Context.global().setSessionFolderPath(session.getPath());
			prApp.set(new ParallelFileAppender(session.getPath()));
			Logger.getRootLogger().addAppender(prApp.get());
			logger.info("Chrome browser instantiated successfully");
			
		} else if (strBrowser.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "\\src\\main\\resources\\drivers\\IEDriverServer.exe");
			DesiredCapabilities caps=DesiredCapabilities.internetExplorer();
			caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			caps.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);	
			RemoteWebDriver webDriver = new InternetExplorerDriver(caps);
			Context.global().setDriver(webDriver);
			File session = new File(System.getProperty("user.dir") + "\\logs\\" + LoggingUtils.executionFolder.getName() + "\\" + mtd.getName() + "_"
					+ webDriver.getSessionId() + "\\logs");
			session.mkdirs();
			Context.global().setSessionFolderPath(session.getPath());
			prApp.set(new ParallelFileAppender(session.getPath()));
			Logger.getRootLogger().addAppender(prApp.get());
			logger.info("Internet explorer browser instantiated successfully");
			
		} else if(strBrowser.equalsIgnoreCase("Firefox")) {
			ProfilesIni p = new ProfilesIni();
			FirefoxProfile firefoxProfile = p.getProfile("Automation");
			firefoxProfile.setPreference("browser.download.folderList", 2);
			firefoxProfile.setPreference("browser.download.manager.showWhenStarting", false);
			firefoxProfile.setPreference("services.sync.prefs.sync.browser.download.manager.closeWhenDone", false);
			firefoxProfile.setPreference("browser.download.panel.shown", true);
			firefoxProfile.setPreference("browser.download.manager.showAlertOnComplete", false);
			firefoxProfile.setPreference("browser.download.dir", System.getProperty("user.dir") + "\\src\\test\\resources\\saved-files");
			firefoxProfile.setPreference("pdfjs.disabled", true);
			firefoxProfile.setPreference("browser.helperApps.neverAsk.saveToDisk","application/pdf, application/x-pdf, application/octet-stream");
			DesiredCapabilities capabilities = DesiredCapabilities.firefox();
			RemoteWebDriver webDriver;
			capabilities.setCapability(FirefoxDriver.PROFILE, firefoxProfile);
			if(LoadPropertiesUtil.configProps.getProperty("seleniumGrid").equalsIgnoreCase("YES")) {
				String hub = "http://"+LoadPropertiesUtil.configProps.getProperty("hubIP")+":"+
						LoadPropertiesUtil.configProps.getProperty("hubPort")+"/wd/hub";
		        capabilities.setBrowserName("firefox");
		        webDriver = new RemoteWebDriver(new URL(hub), capabilities);
		        logger.info("Using Selenium Grid");
			} else{
				webDriver = new FirefoxDriver(capabilities);
			}
			Context.global().setDriver(webDriver);
			File session = new File(System.getProperty("user.dir") + "\\logs\\" + LoggingUtils.executionFolder.getName() + "\\" + mtd.getName() + "_"
					+ webDriver.getSessionId() + "\\logs");
			session.mkdirs();
			Context.global().setSessionFolderPath(session.getPath());
			prApp.set(new ParallelFileAppender(session.getPath()));
			Logger.getRootLogger().addAppender(prApp.get());
			logger.info("Firefox browser instantiated successfully");
		} else {
			logger.info("Kindly select a valid browser");
		}
		Context.global().getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
}