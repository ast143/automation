package com.nordea.utility;

import org.apache.log4j.Logger;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import org.testng.internal.Utils;

import com.nordea.framework.Context;

/**
 * Class to print the stacktrace in case test case is fail otherwise prints
 * successful test execution message
 * 
 * 
 */
public class TestNGListener extends TestListenerAdapter {
	final static Logger logger = Logger.getLogger(TestNGListener.class);

	/**
	 * Method being executed once test method gets fail
	 */
	@Override
	public void onTestFailure(ITestResult result) {
		if (!result.isSuccess()) {
			try {
				Context.global().getSeleniumUtils()
						.takeScreenShotForReport(result.getMethod());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		logger.info(result.getName() + " =====> [TEST METHOD FAILED]");
		Throwable throwable = result.getThrowable();
		if (throwable != null) {
			logger.error(Utils.stackTrace(throwable, true)[0]);
		}
	}

	/**
	 * Method being executed once test method gets passed
	 */
	@Override
	public void onTestSuccess(ITestResult result) {
		logger.info(result.getName() + " =====> [TEST METHOD PASSED]");
	}

}