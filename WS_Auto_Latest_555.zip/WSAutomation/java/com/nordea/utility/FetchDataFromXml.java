package com.nordea.utility;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Class being used for fetching data from xml
 * @author Nitesh Khanna
 *
 */
public class FetchDataFromXml {

	private Document parseXmlDocument;

	public void parseXmFile(String fileName) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = builderFactory.newDocumentBuilder();
		//parseXmlDocument = builder.parse(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\xml-files\\"+fileName+".xml"));
		parseXmlDocument = builder.parse(new InputSource(new StringReader(fileName)));
		parseXmlDocument.getDocumentElement().normalize();
	}
	
	public NodeList findElementsWithTagName(String tagName) {
		return parseXmlDocument.getElementsByTagName(tagName);
	}
	
	public String getErrorReportDetails(String pageSourceContent) throws ParserConfigurationException, SAXException, IOException {
		FetchDataFromXml obj = new FetchDataFromXml();
		obj.parseXmFile(pageSourceContent);
		NodeList ls = obj.findElementsWithTagName("Error");
		String str1 = "Policy Number" + "\t" + "Insured" + "\t\t" + "Message" + "\n";
		for(int count=0; count<ls.getLength(); count++) {
			Node n = ls.item(count);
			if(n.getNodeType()==Node.ELEMENT_NODE) {
				Element ele = (Element) n;
				str1 = str1 + (ele.getElementsByTagName("PolicyNumber").item(0).getTextContent()
						+ "\t" + ele.getElementsByTagName("Insured").item(0).getTextContent()
						+ "\t" + ele.getElementsByTagName("Message").item(0).getTextContent()) + "\n";
			}
		}
		return str1.replaceAll("\\<.*?>", "");
		}
	
	public String getEventReportDetails(String pageSourceContent) throws ParserConfigurationException, SAXException, IOException {
		FetchDataFromXml obj = new FetchDataFromXml();
		obj.parseXmFile(pageSourceContent);
		NodeList ls = obj.findElementsWithTagName("Policy");
		String str1 = "Policy Number"+ "\n";
		for(int count=0; count<ls.getLength(); count++) {
			Node n = ls.item(count);
			if(n.getNodeType()==Node.ELEMENT_NODE) {
				Element ele = (Element) n;
				str1 = str1 + (ele.getElementsByTagName("PolicyNumber").item(0).getTextContent()) + "\n";
			}
		}
		return str1.replaceAll("\\<.*?>", "");
		}

}