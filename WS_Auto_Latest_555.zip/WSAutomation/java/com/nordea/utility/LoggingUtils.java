package com.nordea.utility;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * Class being used for logging
 * 
 * @author Nitesh Khanna
 * 
 */
public class LoggingUtils {
	final static Logger logger = Logger.getLogger(LoggingUtils.class);
	static File executionFolder;

	/**
	 * Method being used for configuring logging properties 
	 */
	public static void configureLogProperties() {
		createExecutionFolderUnderTemp();
		PropertyConfigurator.configure(System.getProperty("user.dir")
				+ File.separator + "src" + File.separator + "main"
				+ File.separator + "resources" + File.separator
				+ "config" + File.separator + "log4j.properties");
	}

	/**
	 * Method being used for creating execution folder
	 */
	private static void createExecutionFolderUnderTemp() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"MM-dd-yyyy_HH.mm.ss");
		executionFolder = new File(System.getProperty("user.dir")
				+ File.separator + "logs" + File.separator
				+ LoadPropertiesUtil.configProps.getProperty("BuildVersion")
				+ "_" + dateFormat.format(new Date()));
		executionFolder.mkdir();
	}

}