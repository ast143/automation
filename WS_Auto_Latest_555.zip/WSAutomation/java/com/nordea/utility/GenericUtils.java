package com.nordea.utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;

import com.nordea.framework.Context;


public class GenericUtils{
	
	/**
	 * Functionality: Capture Screenshot as per the testname passed and will return the path where screenshot is stored
	 *  Return Type: String
	 * @throws IOException 
	 */	
public static String captureScreenshot(String testname) throws IOException{
	String screenshotDest = LoadPropertiesUtil.configProps.getProperty("Screenshot_Path")+"/"+testname+".png";
    File destFile = new File(screenshotDest);

    TakesScreenshot ts = (TakesScreenshot) Context.global().getDriver();
    File srcFile = ts.getScreenshotAs(OutputType.FILE);
    FileUtils.copyFile(srcFile, destFile);
	return screenshotDest;
}

	/**
	 * Functionality: Fetch the current system date in the format
	 * yyyy-MM-dd:HH-mm-ss Return Type: String
	 */
	public static String getCurrentDate() {
		Date date = new Date();
		SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd:HH-mm-ss");
		return d.format(date);
	}

	/**
	 * Functionality: Highlight the Element
	 */
	public static void highLightElement(WebElement element)
			throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) Context.global().getDriver();
		js.executeScript(
				"arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",
				element);
		Thread.sleep(1000);
	}
}
