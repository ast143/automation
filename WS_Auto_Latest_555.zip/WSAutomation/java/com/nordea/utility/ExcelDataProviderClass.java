package com.nordea.utility;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

import com.nordea.framework.Context;

/**
 * Class being used for supplying excel data to test method
 * @author Nitesh Khanna
 *
 */
public class ExcelDataProviderClass {
	@DataProvider(name = "excel-data-provider")
	
	/**
	 * Method being used for supplying data from excel in form of Object[][]
	 * @param m
	 * @return
	 */
	public static Object[][] dataProviderMethod(Method m) {
		String filename = "";
		String sheetname = "";
		Annotation[] annote = m.getDeclaredAnnotations();
		for (Annotation annotation : annote) {
			if (annotation instanceof ExcelAnnotation) {
				ExcelAnnotation myAnnotation = (ExcelAnnotation) annotation;
				filename = myAnnotation.filename();
				sheetname = myAnnotation.sheetname();
				break;
			}
		}
		Context.global().setDataSet();
		return Context.global().getDataSet()
				.getDataSetAsObjectArray(filename, sheetname, m.getName());
	}
}