package com.nordea.workflow;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;

import com.nordea.framework.Context;
import com.nordea.pages.CustomerPage;
import com.nordea.pages.DataSearchPage;
import com.nordea.pages.NewOfferPage;
import com.nordea.pages.OfferBasicPage;
import com.nordea.pages.OfferCoversPage;
import com.nordea.pages.OfferInvestmentPlan;
import com.nordea.pages.OfferMakePolicy;
import com.nordea.pages.OfferPaymentPlan;
import com.nordea.pages.OfferResultCalcAndPrinting;
import com.nordea.pages.PolicyCovertab;
import com.nordea.utility.Report;

public class OfferWorkflow{
	
	final static Logger logger = Logger.getLogger( OfferWorkflow.class);
	HashMap<String, String> valuesFetchedFromUI = new HashMap<String, String>();
	String productID;
		
	/**
	 * @param testData
	 * @throws Exception
	 */
	public void basicOfferCreation(LinkedHashMap<String, String> testData) throws Exception {
		Context.local().getPages().getPage(DataSearchPage.class).searchByCustomerID(testData.get("Customer_ID"));
		Context.local().getPages().getPage(DataSearchPage.class).clickCustomer();
		valuesFetchedFromUI.put("CustomerName", Context.local().getPages().getPage(CustomerPage.class).fetchCustomerName());
		Report.updateReport("INFO","Customer Search Successful","Customer Search Screen");
		valuesFetchedFromUI.put("CustomerID", Context.local().getPages().getPage(CustomerPage.class).fetchCustomerId());
		valuesFetchedFromUI.put("CustomerLanguage", Context.local().getPages().getPage(CustomerPage.class).fetchLanguage());
		Report.updateReport("INFO", " Customer Language : " + Context.local().getPages().getPage(CustomerPage.class).fetchLanguage());
		Context.local().getPages().getPage(CustomerPage.class).navigateToContactsTab();
		valuesFetchedFromUI.put("CustomerAddress", Context.local().getPages().getPage(CustomerPage.class).fetchCustomerAddress());
		valuesFetchedFromUI.put("CreationDate", Context.local().getAppUtilityFunction().getCurrentDate());
		Context.local().getPages().getPage(DataSearchPage.class).clickNewOffer();
		valuesFetchedFromUI.put("ProductName", Context.local().getPages().getPage(NewOfferPage.class).fetchProductname());
		Report.updateReport("INFO", " Product ID : " + testData.get("Product_ID")+ " &  Product Name : " + Context.local().getPages().getPage(NewOfferPage.class).fetchProductname());
		Context.local().getOfferUtilityFunction().selectProduct(testData.get("Product_ID"));
		Context.local().getPages().getPage(OfferBasicPage.class).setSalesPersonId(testData.get("SalesPersonID"));
		Context.local().getPages().getPage(OfferBasicPage.class).clickSalesPersonNameFind();		
		Context.local().getPages().getPage(OfferBasicPage.class).setBranchOfficeId(testData.get("BranchOfficeID"));
		Context.local().getPages().getPage(OfferBasicPage.class).clickBranchOfficeFind();
		Context.local().getPages().getPage(OfferBasicPage.class).clickContinue();
		Context.local().getPages().getPage(OfferCoversPage.class).clickDeathSavingCover();
		Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiary();
		Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiaryAdd();
		Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
		Context.local().getPages().getPage(OfferCoversPage.class).clickContinue();
		Context.local().getPages().getPage(OfferCoversPage.class).setFirstPremiumAmount(testData.get("FirstPremium"));
		valuesFetchedFromUI.put("PaymentValue", testData.get("FirstPremium"));
		Context.local().getPages().getPage(OfferPaymentPlan.class).setPaymentPremiumPeriod(testData.get("PremiumPeriod"));
		Context.local().getPages().getPage(OfferPaymentPlan.class).setPaymentPlanFrequency(testData.get("PlanFrequency"));
		Context.local().getPages().getPage(OfferPaymentPlan.class).clickContinue();
		Context.local().getPages().getPage(OfferInvestmentPlan.class).clickFirstInvestment();
		Context.local().getPages().getPage(OfferInvestmentPlan.class).clickAdd();
		Context.local().getPages().getPage(OfferInvestmentPlan.class).clickCount();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickSave();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).checkAllPrintCheckbox();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickPrint();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickReturn();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickContinue();
		Context.local().getPages().getPage(OfferMakePolicy.class).clickPolicySignedYes();
		Context.local().getPages().getPage(OfferMakePolicy.class).clickPolicyAccept();
		valuesFetchedFromUI.put("PolicyId", Context.local().getPages().getPage(OfferMakePolicy.class).fetchPolicyID());
		Report.updateReport("PASS","Policy Created ","Policy Creation Screen");
		}
	
	
		public void offerCreationRisk(LinkedHashMap<String, String> testData) throws Exception {
		Context.local().getPages().getPage(DataSearchPage.class).searchByCustomerID(testData.get("Customer_ID"));
		Context.local().getPages().getPage(DataSearchPage.class).clickCustomer();
		valuesFetchedFromUI.put("CustomerName", Context.local().getPages().getPage(CustomerPage.class).fetchCustomerName());
		Report.updateReport("INFO","Customer Search Successful","Customer Search Screen");
		Context.local().getPages().getPage(DataSearchPage.class).clickNewOffer();
		Context.local().getOfferUtilityFunction().selectProduct(testData.get("Product_ID"));
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillBasicTab(testData);
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillCoverTab(testData);	
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillPaymentPlanTab(testData);
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillResutlOfCalAndPrintTab(testData);
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillMakePolicyTab(testData);
	}
	
	
	/**
	 * Method to be used for entering values in Offers basic tab.
	 * @param testData
	 * @throws Exception
	 */
	public void fillBasicTab(LinkedHashMap<String, String> testData) throws Exception{
		Context.local().getPages().getPage(OfferBasicPage.class).setSalesPersonId(testData.get("SalesPersonID"));
		Context.local().getPages().getPage(OfferBasicPage.class).clickSalesPersonNameFind();		
		Context.local().getPages().getPage(OfferBasicPage.class).setBranchOfficeId(testData.get("BranchOfficeID"));
		Context.local().getPages().getPage(OfferBasicPage.class).clickBranchOfficeFind();
		Report.updateReport("INFO","Basic Tab Details Entered");	
		Context.local().getPages().getPage(OfferBasicPage.class).clickContinue();
	}
	
	/**
	 * Method to be used for entering values in Offers Cover tab.
	 * @param testData
	 * @throws Exception
	 */
	public void fillCoverTab(LinkedHashMap<String, String> testData) throws Exception{
		productID=testData.get("Product_ID");
		if(productID.equals("39") || productID.equals("9") || productID.equals("58")){
		Context.local().getOfferUtilityFunction().addCovers(testData);
		Context.local().getPages().getPage(OfferCoversPage.class).clickContinue();
		}
		else{
		Context.local().getPages().getPage(OfferCoversPage.class).clickContinue();
		}
	}
	
	/**
	 * Method to be used for entering values in Offers Payment Plan tab.
	 * @param testData
	 * @throws Exception
	 */
	public void fillPaymentPlanTab(LinkedHashMap<String, String> testData) throws Exception{
		
		productID=testData.get("Product_ID");
		Context.local().getPages().getPage(OfferPaymentPlan.class).selectPaymentPlanDropDown(testData.get("PaymentPlan"));
		Context.local().getPages().getPage(OfferPaymentPlan.class).selectPaymentMethodDropDown(testData.get("PaymentMethod"));
		if(!(productID.equals("39") || productID.equals("9")) ){
			Context.local().getPages().getPage(OfferPaymentPlan.class).setFirstPremiumAmount(testData.get("FirstPremium"));
			Context.local().getPages().getPage(OfferPaymentPlan.class).setPaymentPremiumPeriod(testData.get("PremiumPerPeriod"));
		}
		
		Context.local().getPages().getPage(OfferPaymentPlan.class).setPaymentPlanFrequency(testData.get("PaymentFrequency"));
		
		if(!(testData.get("PremiumStartDate").equalsIgnoreCase("NA")||testData.get("PremiumStartDate").equalsIgnoreCase(""))){
			Context.local().getPages().getPage(OfferPaymentPlan.class).setStartDate(testData.get("PremiumStartDate"));
		}
		
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).setInvoiceDate(testData);
		
		Report.updateReport("INFO","Payment Plan Details Entered");
		Context.local().getPages().getPage(OfferPaymentPlan.class).clickContinue();
	}
	
	/**
	 * Method to be used for entering values for invoice due date.
	 * @param testData
	 * @throws Exception
	 */
	
	public void setInvoiceDate(LinkedHashMap<String, String> testData) throws Exception{
		
		String invoiceDate=testData.get("InvoiceDate");
		if(invoiceDate.equals("NA")){
			
			valuesFetchedFromUI.put("invoiceDate", Context.local().getPages().getPage(OfferPaymentPlan.class).fetchInvoiceDate());
			Report.updateReport("INFO","Invoice date picked from UI","PaymentPlantab");
		}
		else
		{
			Context.local().getPages().getPage(OfferPaymentPlan.class).setInvoiceDate(invoiceDate);
			Report.updateReport("INFO","Invoice date entered from test data","PaymentPlantab");
		}
			
	}
	
	
	/**
	 * Method to be used for entering values in Offers Investment Plan tab.
	 * @param testData
	 * @throws Exception
	 */
	public void fillInvestmentPlanTab(LinkedHashMap<String, String> testData) throws Exception{
		
		String portfoliservice =testData.get("Services");
		if(portfoliservice.equals("NA")){
			Context.local().getPages().getPage(OfferInvestmentPlan.class).clickAddInvestment();		
			Context.local().getOfferUtilityFunction().selectInvestments(testData);		
			Context.local().getPages().getPage(OfferInvestmentPlan.class).clickAdd();
			Report.updateReport("INFO","Investment Plan Details Entered");		
			Context.local().getOfferUtilityFunction().enterInvestmentDistribution(testData);
			Report.updateReport("INFO","Investment Distributions Entered");						
		}
		else{			
			Context.local().getPages().getPage(OfferInvestmentPlan.class).selectPortfollioServices(testData.get("Services"));
			Context.local().getPages().getPage(OfferInvestmentPlan.class).clickShowProfile();
			Context.local().getPages().getPage(OfferInvestmentPlan.class).selectPortfollioProfile(testData.get("Profile"));
			Context.local().getPages().getPage(OfferInvestmentPlan.class).clickShowAllocation();	
			Report.updateReport("INFO","Portfolio Services and Profiles are selected");
		}		
		Context.local().getPages().getPage(OfferInvestmentPlan.class).clickCount();
	}
	
	/**
	 * Method to be used for entering values in Offers Results of Calculation and Print tab.
	 * @param testData
	 * @throws Exception
	 */
	public void fillResutlOfCalAndPrintTab(LinkedHashMap<String, String> testData) throws Exception{
		
		if(!(testData.get("ResultOfCalcCovers").equals("")||testData.get("ResultOfCalcCovers").equals("NA")))
		{
			Context.local().getOfferUtilityFunction().VerifyAnnualCoverPremiums(testData);
			Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickReturn();
		}
		valuesFetchedFromUI.put("OfferPremium",Context.local().getPages().getPage(PolicyCovertab.class).fetchInsuranceYearlyPremium());
		Report.updateReport("INFO","Insurance yearly premium from result of calc tab","Insurance yearly premium offer");
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickSave();		
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).checkAllPrintCheckbox();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickPrint();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickReturn();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickContinue();	
	}
	
	/**
	 * Method used to fetch offer insurance yearly premium  from HashMap valuesFetchedFromUI.
	 * @throws Exception
	 */
	public String getOfferInsPremium(){
		return valuesFetchedFromUI.get("OfferPremium"); 
	}
	
	/**
	 * Method to be used for entering values in Offers Make Policy tab.
	 * @param testData
	 * @return 
	 * @throws Exception
	 */
	public void fillMakePolicyTab(LinkedHashMap<String, String> testData) throws Exception{
		
		productID=testData.get("Product_ID");
		String offerID=Context.local().getOfferUtilityFunction().getValueFromOfferHeader("Offerid");
		Context.local().getPages().getPage(OfferMakePolicy.class).clickPolicySignedYes(); 
		if(productID.equals("9")||productID.equals("39")){
			Context.local().getPages().getPage(OfferMakePolicy.class).checkHDCheckBox();
			
			if (!(testData.get("HealthDeclarationType").equalsIgnoreCase("NA"))){
				Context.local().getPages().getPage(OfferMakePolicy.class).selectHealthDeclaration(testData.get("HealthDeclarationType"));
				if(testData.get("HealthDeclarationType").equalsIgnoreCase("Comprehensive")) {			
					offerCreationForComprehensive(testData);
				}				
			}							
				Context.local().getPages().getPage(OfferMakePolicy.class).clickPolicyAccept();				
								
				if(Context.local().getPages().getPage(OfferMakePolicy.class).verifyOfferErrMsgPresent() && (Context.local().getPages().getPage(OfferMakePolicy.class).fetchHDStatus().equalsIgnoreCase("Comprehensive") || Context.local().getPages().getPage(OfferMakePolicy.class).fetchHDStatus().equalsIgnoreCase("Complex"))){
					Report.updateReport("INFO","Comprehensive HD status","Error for comprehensive and complex HD");
					Context.local().getPages().getPage(OfferMakePolicy.class).clickSaveUnfinished();
					Context.local().getWorkflows().getWorkflow(GenericWorkflow.class).updateSessionDate(Context.local().getAppUtilityFunction().getFutureDateConsideringBankHoliday(Context.local().getAppUtilityFunction().getApplicationDate(),1));
					Context.local().getPages().getPage(DataSearchPage.class).searchByOfferID(offerID);				
					Context.local().getPages().getPage(OfferMakePolicy.class).clickMakePolicyTab();
					changeDecisionCodeAndHDdates(testData);
				}		
		}
		else{
				Context.local().getPages().getPage(OfferMakePolicy.class).clickPolicyAccept();
		}
			
			Context.local().getPages().getPage(OfferMakePolicy.class).fetchPolicyID();
			valuesFetchedFromUI.put("PolicyId", Context.local().getPages().getPage(OfferMakePolicy.class).fetchPolicyID());		
			Report.updateReport("PASS","Policy Created ", "Policy Creation Screen" + valuesFetchedFromUI.get("PolicyId"));
			Context.local().getPages().getPage(OfferMakePolicy.class).clickOK();	
	}
	
	
	public void offerCreationForComprehensive(LinkedHashMap<String, String> testData) throws Exception{
		
		Context.local().getPages().getPage(OfferMakePolicy.class).clickSaveUnfinished();
		Context.local().getPages().getPage(OfferMakePolicy.class).clickOK();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).checkPrintHDform();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickPrint();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickReturn();
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickContinue();	
	}
	/**
	 * Method to be used for download the Invoice PDF and validate it further for all required fields
	 * @throws Exception
	 */
	public synchronized void downloadAndVerifyInviocePdf() throws Exception {
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickOK();
		Context.local().getPages().getPage(OfferMakePolicy.class).checkPrintInvoice();
		Context.local().getPages().getPage(OfferMakePolicy.class).clickPrint();
		valuesFetchedFromUI.put("LetterContent", Context.local().getInvoiceLetterObject().createInvoiceContentUsingIdentifiers(valuesFetchedFromUI.get("CustomerLanguage")));
		Context.local().getPages().getPage(OfferMakePolicy.class).saveInvoiceLetter(valuesFetchedFromUI.get("PolicyId"));
		Report.updateReport("INFO","***PDF VALIDATION***");
		Thread.sleep(3000);
		Context.local().getAppUtilityFunction().validatePdfContent(valuesFetchedFromUI, valuesFetchedFromUI.get("PolicyId"));
	}
	
		
	/**
	 * Method to be used for changing decision code of covers and entering arrival and acceptance date of HD form.
	 * @throws Exception
	 */
	public void changeDecisionCodeAndHDdates(LinkedHashMap<String, String> testData) throws Exception{
		Context.local().getPages().getPage(OfferMakePolicy.class).clickInsuredLink();
		if(testData.get("HealthDeclarationType").equalsIgnoreCase("NA")){
			Context.local().getOfferUtilityFunction().changeDecisionCode();
		}	
		
		Context.local().getPages().getPage(OfferMakePolicy.class).enterHDarrivalDate();
		Context.local().getPages().getPage(OfferMakePolicy.class).enterHDacceptDate();
		Context.local().getPages().getPage(OfferMakePolicy.class).clickSave();
		Report.updateReport("INFO","Insured link on make policy tab","After change of decision code");
		Context.local().getPages().getPage(OfferMakePolicy.class).clickPolicyAccept();
	}
	
	public String getInvoiceDate(){
		return valuesFetchedFromUI.get("invoiceDate");
		
	}
	
		public void createRiskPolicy(LinkedHashMap<String, String> testData) throws Exception
	{
		Report.updateReport("INFO","Product ID: "+testData.get("Product_ID"));
		Report.updateReport("INFO","Test Case Description: "+testData.get("Description"));
		Context.local().getPages().getPage(DataSearchPage.class).searchByCustomerID(testData.get("Customer_ID"));
		Context.local().getPages().getPage(DataSearchPage.class).clickNewOffer();
		Context.local().getOfferUtilityFunction().selectProduct(testData.get("Product_ID"));		
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillBasicTab(testData);
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillCoverTab(testData);
	    Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillPaymentPlanTab(testData);
		//Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillInvestmentPlanTab(testData);
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillResutlOfCalAndPrintTab(testData);
		Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).fillMakePolicyTab(testData);
	}
	
	public String getPolicyID(){
		return valuesFetchedFromUI.get("PolicyId");
		
	}
}