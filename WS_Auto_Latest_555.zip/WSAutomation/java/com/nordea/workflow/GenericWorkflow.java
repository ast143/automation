package com.nordea.workflow;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.nordea.framework.Context;
import com.nordea.page.components.FooterSection;
import com.nordea.page.components.LHN;
import com.nordea.pages.EventViewPage;
import com.nordea.pages.HomeWorkflow;
import com.nordea.pages.ITLoginPage;
import com.nordea.pages.InvestmentActions;
import com.nordea.pages.Management;
import com.nordea.pages.PaymentPage;
import com.nordea.pages.PolicyPage;
import com.nordea.utility.LoadPropertiesUtil;
import com.nordea.utility.Report;
import com.nordea.utility.SeleniumUtils;

public class GenericWorkflow {
	
	HashMap<String, String> valuesFetchedFromUI = new HashMap<String, String>();
	final static Logger logger = Logger.getLogger(SeleniumUtils.class);
	
	/**
	 * Functionality: Login to IT environment and click on In English link
	 * Input Parameter : IT url, userID and Password
	 *  Return Type: Null
	 */
	
	public void login() throws Exception{
		String env = LoadPropertiesUtil.configProps.getProperty("Environment");
		Context.global().getSeleniumUtils().navigateToApplicationUrl(env);
		if (env.equalsIgnoreCase("IT")) {
			itLogIn();			
		}
		Context.local().getPages().getPage(LHN.class).clickEnglish();
	}

	/**
	 * Functionality: Login to IT environment 
	 * Input Parameter : IT url Return
	 * Type: Null
	 */
	public void itLogIn() throws Exception {
		Context.local().getPages().getPage(ITLoginPage.class)
				.setUserid(LoadPropertiesUtil.configProps.getProperty("Username"));
		Context.local().getPages().getPage(ITLoginPage.class)
				.setPassword(LoadPropertiesUtil.configProps.getProperty("Password"));	
		Context.local().getPages().getPage(ITLoginPage.class).clickLogin();
	}
     
      
     /**
  	 * Functionality: Update the Session date
  	 *  Input Parameter : new Session Date
  	 *  Return Type: Null
  	 */
     public void updateSessionDate(String updatedDate) throws Exception{
    	 Context.local().getPages().getPage(LHN.class).clickManagement();
    	 Context.local().getPages().getPage(Management.class).clickChangeSessionTime();
    	 Context.local().getPages().getPage(Management.class).enterSessionDate(updatedDate);
    	 Context.local().getPages().getPage(Management.class).clickSubmit();
    	 Context.local().getPages().getPage(LHN.class).clickDataSearch();
       } 
     
     /**
   	 * Functionality: Enter Prices for any investment.
   	 *  Input Parameter : delay days of the Investment
   	 *  Return Type: Null
   	 */
	public String enterPrices(int delayDays) throws Exception
 	{
		DateFormat dateformat = new SimpleDateFormat("dd.MM.yyyy");
		Calendar calendar = new GregorianCalendar();
 		String dateString = Context.local().getPages().getPage(FooterSection.class).getApplicationDate(); 		
  		
		Date date = new SimpleDateFormat("dd.MM.yyyy").parse(dateString); 		
 	    calendar.setTime(date);
 	    Date resultDate = calendar.getTime(); 	    
		String newDate = dateformat.format(resultDate);
		
  		for(int j=0;j<=delayDays;j++){
  			
  		boolean flag=true;
  		while(flag){
 	    if(calendar.get(Calendar.DAY_OF_WEEK)==7){ 	    	
 	    	System.out.println("Its saturday");
 	        calendar.add(Calendar.DATE, 2);
 	    }
 	    else if(calendar.get(Calendar.DAY_OF_WEEK)==1){
 	    System.out.println("Its Sunday");
 	 	calendar.add(Calendar.DATE, 1);
 	    }
 	    resultDate = calendar.getTime(); 	    
	    newDate = dateformat.format(resultDate);
	    System.out.println("Next date:"+newDate);
	   
 	    if(Context.local().getAppUtilityFunction().getNordeaHolidayList().contains(newDate)){
 	      System.out.println(newDate+": Its nordea Holiday");
 	      calendar.add(Calendar.DATE, 1);
 	      resultDate = calendar.getTime();
 	      newDate = dateformat.format(resultDate);  	     
 	    }
 	    else
 	    {
 	    	flag = false;
 	    }
 	    }  
  		Context.local().getPages().getPage(InvestmentActions.class).clickEnterPrices();
  		Context.local().getPages().getPage(InvestmentActions.class).enterPriceDate(newDate);
  		Context.local().getPages().getPage(InvestmentActions.class).clickOk(); 		
  		String oldprice = Context.local().getPages().getPage(InvestmentActions.class).getInvestmentPrice();
  		oldprice = oldprice.replace(",", ".");
  		oldprice = oldprice.replace(" ", "");
  		double newprice = Double.parseDouble(oldprice)+0.001;
  		DecimalFormat df=new DecimalFormat("#.#####");
		String price=df.format(newprice);
  		Context.local().getPages().getPage(InvestmentActions.class).enterPriceAmount(price);
  		Context.local().getPages().getPage(InvestmentActions.class).clickSave();
  		calendar.add(Calendar.DATE, 1);
  		}
  		resultDate = calendar.getTime();
	    newDate = dateformat.format(resultDate);
	    return newDate;
 	}

	/**
  	 * Functionality: Complete Payment after policy creation
  	 *  Input Parameter : Null
  	 *  Return Type: Null
  	 */
	public void doPayments() throws Exception{
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Report.updateReport("INFO","Mode of policy before payment: " + Context.local().getPages().getPage(PolicyPage.class).fetchMode());
		Context.local().getPages().getPage(LHN.class).clickEventView(); 
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		List<WebElement> paymentDates=Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Invoiced payments')]//following-sibling::div[2]//tr/td[9][contains(text(),'Incomplete')]/../td[1]"));
		
		while(paymentDates.size()>0)
		{
		paymentDates.get(0).click();
		Context.local().getPages().getPage(EventViewPage.class).clickCreatePremium();
		Context.local().getPages().getPage(EventViewPage.class).clickFind();
		Context.local().getPages().getPage(EventViewPage.class).clickAccntNoLink();
		Context.local().getPages().getPage(EventViewPage.class).clickSaveAndCreatePremium(); 
		Context.local().getPages().getPage(EventViewPage.class).clickOk();
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		Report.updateReport("INFO","Invoice payment is succesfully completed","ViewPaymentsEventsPage");
		paymentDates=Context.global().getDriver().findElements(By.xpath("//h2[contains(text(), 'Invoiced payments')]//following-sibling::div[2]//tr/td[9][contains(text(),'Incomplete')]/../td[1]"));
		}
}
   
	
	/**
  	 * Functionality: Complete Incoming Payment after policy creation
  	 *  Input Parameter : String,String
  	 *  Return Type: Null
  	 */
	public void doIncomingPayments(String policyID, String paymentAmount) throws Exception{
		Context.local().getPages().getPage(LHN.class).clickHomeWorkFlow();
		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
		Context.local().getPages().getPage(HomeWorkflow.class).clickIncomingPayments();
		Context.local().getPages().getPage(PaymentPage.class).clickAdd();
		Context.local().getPages().getPage(PaymentPage.class).setPaymentDate(Context.local().getPages().getPage(FooterSection.class).getApplicationDate());
		Context.local().getPages().getPage(PaymentPage.class).setAmount(paymentAmount);
		Context.local().getPages().getPage(PaymentPage.class).clickFindAccountNumber();
		Context.local().getPages().getPage(PaymentPage.class).clickInvoicerAccountLink();
		Context.local().getPages().getPage(PaymentPage.class).setPolicyNumber(policyID);
		Context.local().getPages().getPage(PaymentPage.class).clickSaveAndCreatePremium();
	}
	
	public void doPartialPayments() throws Exception{
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Report.updateReport("INFO","Mode of policy before payment: " + Context.local().getPages().getPage(PolicyPage.class).fetchMode());
		Context.local().getPages().getPage(LHN.class).clickEventView(); 
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		List<WebElement> paymentDates=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Incomplete");
		
		while(paymentDates.size()>0)
		{
		paymentDates.get(0).click();
		Context.local().getPages().getPage(EventViewPage.class).clickCreatePremium();
		Context.local().getPages().getPage(EventViewPage.class).clickFind();
		Context.local().getPages().getPage(EventViewPage.class).clickAccntNoLink();
		String amt=Context.local().getPages().getPage(PaymentPage.class).getAmount();
		amt=amt.replace(",", ".");
		Float val=Float.parseFloat(amt);
		val=val/2;
		String partialamt=String.valueOf(val);
		partialamt=partialamt.replace(".", ",");
		Context.local().getPages().getPage(PaymentPage.class).setAmount(partialamt);
		Context.local().getPages().getPage(EventViewPage.class).clickSaveAndCreatePremium(); 
		Context.local().getPages().getPage(EventViewPage.class).clickOk();
		Context.local().getPages().getPage(EventViewPage.class).clickViewPaymentEvents();
		paymentDates=Context.local().getPages().getPage(EventViewPage.class).fetchPaymentDates("Incomplete");
		}
}
}
