package com.nordea.workflow;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;

import com.nordea.framework.Context;
import com.nordea.page.components.FooterSection;
import com.nordea.page.components.LHN;
import com.nordea.pages.BatchDetailsPage;
import com.nordea.pages.BatchEntryLogPage;
import com.nordea.pages.DataSearchPage;
import com.nordea.pages.HomeWorkflow;
import com.nordea.pages.IndividualBatches;
import com.nordea.pages.InvestmentActions;
import com.nordea.pages.PolicyPage;
import com.nordea.pages.StartBatchRunPage;
import com.nordea.utility.LoadPropertiesUtil;
import com.nordea.utility.Report;
import com.nordea.utility.SeleniumUtils;

public class BatchWorkflow {

	HashMap<String, String> valuesFetchedFromUI = new HashMap<String, String>();
	final static Logger logger = Logger.getLogger(SeleniumUtils.class);
    
 	/**
 	 * Method to be used for running the linking batch 
 	 * completely till verifying the event report and error report
 	 * @param testData
 	 * @throws Exception
 	 * @author Debabrata Behera, poonam Joshi
 	 */
 	public void runLinkingBatch(LinkedHashMap<String, String> testData) throws Exception
 	{	
 	    int maxdelayDays=0;
 	    int delayDays=0; 		
  		boolean flag=true;
  		DateFormat dateformat = new SimpleDateFormat("dd.MM.yyyy");
		Calendar calendar = new GregorianCalendar();
		String url = null;
 		String currentdate = Context.local().getPages().getPage(FooterSection.class).getApplicationDate(); 
 		Date date = new SimpleDateFormat("dd.MM.yyyy").parse(currentdate); 		
 	    calendar.setTime(date);
 	    Date resultDate = calendar.getTime();   
		String newDate = dateformat.format(resultDate);
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(PolicyPage.class).clickSavingsTab();
 		List<String> investmentName = Context.local().getPages().getPage(PolicyPage.class).fetchInvestmentList();
 		Context.local().getPages().getPage(LHN.class).clickInvestments(); 
 		for(int i=0;i<investmentName.size();i++){
 			if(!(investmentName.get(i).equalsIgnoreCase("Outgoing"))&&!(investmentName.get(i).equalsIgnoreCase("Unlinked"))){
 				Context.local().getPages().getPage(InvestmentActions.class).searchInvestmentDetail(investmentName.get(i));
 				Context.local().getPages().getPage(InvestmentActions.class).clickInvestmentId();
 				Context.local().getPages().getPage(InvestmentActions.class).clickPriceParameterTab();
 	 		delayDays = Integer.parseInt(Context.local().getPages().getPage(InvestmentActions.class).getLinkingDelayDays());
 	 		if(maxdelayDays < delayDays){
 	 			maxdelayDays = delayDays;
 	 		}
 	 		Context.local().getPages().getPage(LHN.class).clickInvestments();
 		}
 		}
 		logger.info("Max delay days:"+maxdelayDays);
 		
 		for(int k=0;k<=maxdelayDays;k++){
 			flag = true;
 			calendar.add(Calendar.DATE, 1);
 			while(flag){
 				if(calendar.get(Calendar.DAY_OF_WEEK)==7){ 	    	
 					logger.info("Its saturday");
 					calendar.add(Calendar.DATE, 2);
 				}
 				else if(calendar.get(Calendar.DAY_OF_WEEK)==1){
 					logger.info("Its Sunday");
 					calendar.add(Calendar.DATE, 1);
 				}
 				resultDate = calendar.getTime();	    
 				newDate = dateformat.format(resultDate);
 				logger.info("Next date:"+newDate);
 				if(Context.local().getAppUtilityFunction().getNordeaHolidayList().contains(newDate)){
 					logger.info(newDate+": Its nordea Holiday");
 					calendar.add(Calendar.DATE, 1);
 					resultDate = calendar.getTime();
 					newDate = dateformat.format(resultDate);  	     
 				}
 				else
 				{
 					flag = false;
 				}
 			}
 		}
 		resultDate = calendar.getTime();
	    newDate = dateformat.format(resultDate); 
	    Context.local().getPages().getPage(LHN.class).clickInvestments();
 		logger.info("New Application Date: "+newDate); 
 		Context.local().getWorkflows().getWorkflow(GenericWorkflow.class).updateSessionDate(newDate);
 		Context.local().getPages().getPage(DataSearchPage.class).clickHomeWorkFlow();
 		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
 		
 		Context.local().getPages().getPage(HomeWorkflow.class).clickStartingBatchRuns();
 		Context.local().getPages().getPage(StartBatchRunPage.class).clickLinkingBatch();
 		if(("").equalsIgnoreCase(testData.get("Policy_ID"))) {
 			Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMin(Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).valuesFetchedFromUI.get("PolicyId"));
 			Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMax(Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).valuesFetchedFromUI.get("PolicyId"));
		
 			logger.info("***Value fetched from UI");
 			}else {
 				Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMin(testData.get("Policy_ID"));
 				Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMax(testData.get("Policy_ID"));
		}
 		Context.local().getPages().getPage(BatchDetailsPage.class).clickStart();
 		valuesFetchedFromUI.put("BatchID" ,Context.local().getPages().getPage(StartBatchRunPage.class).fetchBatchID());
 		logger.info("Batch ID: "+valuesFetchedFromUI.get("BatchID"));
 		Context.local().getBatchUtilityFunction().waitForBatchCompletion("Linking batch",valuesFetchedFromUI.get("BatchID"));

            if("Completed".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))) || "Interrupted".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID")))) {
            	url= Context.global().getDriver().getCurrentUrl();
    			Context.local().getBatchUtilityFunction(). navigateToXmlEventReport(valuesFetchedFromUI.get("BatchID"));
    			
			try {
				Context.local().getBatchUtilityFunction().verifyLinkingEventReport(testData.get("Policy_ID"));
			}catch(NoSuchElementException e) {
				logger.info("No policy displayed in event report");
				Report.updateReport("FAIL", "Policy not picked in Event Report");
				Context.global().getDriver().navigate().to(url);
				Thread.sleep(2000);
				Context.local().getPages().getPage(BatchEntryLogPage.class).clickErrorReportPrint();
				Thread.sleep(10000);
				Context.local().getBatchUtilityFunction().verifyLinkingErrorReport(url);
			}
			
            } else {
    			if(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))==null){
    				Report.updateReport("FAIL","Batch not picked in BatchLog");
    				}
    				else{
    					Report.updateReport("FAIL","Latest Linking Status:" + Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID")));
    				}
    		}
	} 
 	
 	/**
 	 * Method to be used for running the periodical batch 
 	 * completely till verifying the event report and error report
 	 * @param testData
 	 * @throws Exception
 	 * @author Nitesh Khanna, Kapil Kapoor
 	 */
	public void runPeriodicalBatch(LinkedHashMap<String, String> testData) throws Exception {
		Context.local().getPages().getPage(DataSearchPage.class).clickHomeWorkFlow();
		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
		Context.local().getPages().getPage(HomeWorkflow.class).clickStartingBatchRuns();
		Context.local().getPages().getPage(StartBatchRunPage.class).clickPeriodicalEventsNew();
		if(("").equalsIgnoreCase(testData.get("Policy_ID"))) {
			Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMin(Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).valuesFetchedFromUI.get("PolicyId"));
			Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMax(Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).valuesFetchedFromUI.get("PolicyId"));
		}else {
			Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMin(testData.get("Policy_ID"));
			Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMax(testData.get("Policy_ID"));
		}
		Report.updateReport("INFO","Starting Periodical Batch", "Periodical_Start_Batch");
		Context.local().getPages().getPage(BatchDetailsPage.class).clickStart();
		valuesFetchedFromUI.put("BatchID" ,Context.local().getPages().getPage(StartBatchRunPage.class).fetchBatchID());
		Report.updateReport("INFO","Started Periodical Batch", "Batch_ID");
		Context.local().getBatchUtilityFunction().waitForBatchCompletion("Periodical Events New",valuesFetchedFromUI.get("BatchID"));
		
		if("Completed".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))) || "Interrupted".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID")))) {
			String url= Context.global().getDriver().getCurrentUrl();
			Context.local().getBatchUtilityFunction(). navigateToXmlEventReport(valuesFetchedFromUI.get("BatchID"));
			
			try {
				Context.local().getBatchUtilityFunction().verifyPeriodicalEventReport(testData.get("Policy_ID"));
			}catch(Exception e) {
				logger.info("No policy displayed in event report");
				Report.updateReport("FAIL", "No policy displayed in event report");
				Context.global().getDriver().navigate().to(url);
				Thread.sleep(2000);
				Context.local().getPages().getPage(BatchEntryLogPage.class).clickErrorReportPrint();
				Thread.sleep(10000);
				Context.local().getBatchUtilityFunction().verifyPeriodicalErrorReport(url);
			} 
		} else {
			if(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))==null){
			    Report.updateReport("FAIL","Batch not picked in BatchLog");
			}
			else{
				Report.updateReport("FAIL","Latest Periodical Status:" + Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID")));
			}
		}
	}	
	
 	/**
 	 * Method to be used for running the periodical Events New batch
 	 * @param testData
 	 * @throws Exception
 	 * @author Nitesh Khanna, Kapil Kapoor
 	 */
 	public void runPeriodicalEvntBatchRange(LinkedHashMap<String, String> testData) throws Exception {
 		Context.local().getAppUtilityFunction().renameFile(LoadPropertiesUtil.configProps.getProperty("Tulse_Batch_FilePath"), LoadPropertiesUtil.configProps.getProperty("Periodical_Events_New_Batch_File_Name"));
		Context.local().getPages().getPage(LHN.class).clickHomeWorkFlow();
		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
		Context.local().getPages().getPage(HomeWorkflow.class).clickStartingBatchRuns();
		Context.local().getPages().getPage(StartBatchRunPage.class).clickPeriodicalEventsNew();
		Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMin(testData.get("Policy_Min"));
		Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMax(testData.get("Policy_Max"));
		Report.updateReport("INFO","Starting Periodical Batch for Range", "Periodical_Start_Batch_For_Range");
		Context.local().getPages().getPage(BatchDetailsPage.class).clickStart();
		valuesFetchedFromUI.put("BatchID" ,Context.local().getPages().getPage(StartBatchRunPage.class).fetchBatchID());
		Report.updateReport("INFO","Started Periodical Batch", "Batch_ID");
		Context.global().getLoadPropertiesUtil().writeToAppPropsFile("PropertiesEventsNewBatch", valuesFetchedFromUI.get("BatchID"));
		Report.updateReport("INFO","Batch ID is " + valuesFetchedFromUI.get("BatchID"));
		logger.info("Batch ID written to properties file");
		}	
		
	/**
 	 * Method to be used for checking the status for batch periodical Events New batch
 	 * and to paste the tulse file in given path 
 	 * @param testData
 	 * @throws Exception
 	 * @author Nitesh Khanna, Kapil Kapoor
 	 */
 	public void chkPeriodicalEvntBatchRangeStatus(LinkedHashMap<String, String> testData) throws Exception {
		valuesFetchedFromUI.put("BatchID" ,Context.global().getLoadPropertiesUtil().fetchValueFromAppPropsFile("PropertiesEventsNewBatch"));
		Context.local().getPages().getPage(LHN.class).clickHomeWorkFlow();
		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
		Context.local().getPages().getPage(HomeWorkflow.class).clickBatchEntryLog();
		Context.local().getPages().getPage(BatchEntryLogPage.class).selectBatchToRun("Periodical Events New");
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		Thread.sleep(10000);
		Report.updateReport("INFO","Batch ID :" + valuesFetchedFromUI.get("BatchID"));
		if("Completed".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))) || "Interrupted".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID")))) {
			Context.local().getBatchUtilityFunction().clickBatchLink(valuesFetchedFromUI.get("BatchID"));
			File newFile = new File(LoadPropertiesUtil.configProps.getProperty("Tulse_Batch_FilePath") + File.separator + LoadPropertiesUtil.configProps.getProperty("Periodical_Events_New_Batch_File_Name"));
			if(newFile.exists())
			{	
				logger.info("File is created with the name: " + LoadPropertiesUtil.configProps.getProperty("Periodical_Events_New_Batch_File_Name"));
					Context.local().getAppUtilityFunction().copyFile(LoadPropertiesUtil.configProps.getProperty("Tulse_Batch_FilePath"), LoadPropertiesUtil.configProps.getProperty("Shared_Reports_Repository"), LoadPropertiesUtil.configProps.getProperty("Periodical_Events_New_Batch_File_Name"));
					if(Context.local().getBatchUtilityFunction().getUniqueErrorLines()==0)
					{
						Report.updateReport("PASS","No errors found in the tulse file");
					}else
					{
						Report.updateReport("FAIL","Errors found in the tulse file");
						Report.updateReport("INFO","Please find the consolidated error file <b>'errorFile"+ new SimpleDateFormat("_dd-MM-yyyy").format(new Date())  +".txt'</b> " +"under: //vda1cs0172.qaoneadr.local//SharedFolder//batch-transfer-reports//");
					}
			}else
			{	
				logger.info(LoadPropertiesUtil.configProps.getProperty("Periodical_Events_New_Batch_File_Name") + " File is not created");
			}
		}else 
		{
				if(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))==null){
					Report.updateReport("FAIL","Batch not picked in BatchLog");
				}else{
						
					Report.updateReport("FAIL","Latest Periodical Status:" + Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID")));
				}
		}
	}
 	
 	/**
 	 * Method to be used for running the Invoicing batch
 	 * Verifying the batch until its status is interrupted
 	 * @param testData
 	 * @throws Exception
 	 * @author Mithen Kadam
 	 */
 	public void runInvoicingBatch(LinkedHashMap<String, String> testData) throws Exception
 	{
 		Context.local().getPages().getPage(DataSearchPage.class).clickHomeWorkFlow();
		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
		Context.local().getPages().getPage(HomeWorkflow.class).clickStartingBatchRuns();
		Context.local().getPages().getPage(StartBatchRunPage.class).clickInvoicing();
		Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMin(Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).getPolicyID());
		Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMax(Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).getPolicyID());
		Report.updateReport("INFO","Starting Invoicing Batch Run", "Invoicing Batch Run");
		Context.local().getPages().getPage(BatchDetailsPage.class).clickStart();
		valuesFetchedFromUI.put("BatchID" ,Context.local().getPages().getPage(StartBatchRunPage.class).fetchBatchID());
		Report.updateReport("INFO","Started Invoicing Batch", "Batch_ID");
		Context.local().getPages().getPage(DataSearchPage.class).clickHomeWorkFlow();
		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
		Context.local().getPages().getPage(HomeWorkflow.class).clickBatchEntryLog();
		Context.local().getPages().getPage(BatchEntryLogPage.class).selectBatchToRun("Invoicing");
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		Thread.sleep(10000);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		Report.updateReport("INFO","Batch ID :" + valuesFetchedFromUI.get("BatchID"));
		for(int i = 18; i>=0; i--) {
			Thread.sleep(10000);
			if("Completed".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))) || "Interrupted".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID")))) {
				break;
			}
			Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		}
 	}
 	
 	/**
 	 * Method to be used for running the Invoicing batch
 	 * Verifying the batch until its status is interrupted
 	 * @param testData
 	 * @throws Exception
 	 * @author Mithen Kadam
 	 */
 	public void runInvoiceRemiderBatch(LinkedHashMap<String, String> testData) throws Exception
 	{
 		Context.local().getPages().getPage(DataSearchPage.class).clickHomeWorkFlow();
		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
		Context.local().getPages().getPage(HomeWorkflow.class).clickStartingBatchRuns();
		Context.local().getPages().getPage(StartBatchRunPage.class).clickInvoiceReminde();
		Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMin(Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).getPolicyID());
		Context.local().getPages().getPage(BatchDetailsPage.class).setPolicyMax(Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).getPolicyID());
		Report.updateReport("INFO","Starting Invoice remider Batch Run", "Invoice remider Batch Run");
		Context.local().getPages().getPage(BatchDetailsPage.class).clickStart();
		valuesFetchedFromUI.put("BatchID" ,Context.local().getPages().getPage(StartBatchRunPage.class).fetchBatchID());
		Report.updateReport("INFO","Started Invoice remider Batch", "Batch_ID");
		Context.local().getPages().getPage(DataSearchPage.class).clickHomeWorkFlow();
		Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
		Context.local().getPages().getPage(HomeWorkflow.class).clickBatchEntryLog();
		Context.local().getPages().getPage(BatchEntryLogPage.class).selectBatchToRun("Invoice Reminder");
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		Thread.sleep(10000);
		Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		Report.updateReport("INFO","Batch ID :" + valuesFetchedFromUI.get("BatchID"));
		for(int i = 18; i>=0; i--) {
			Thread.sleep(10000);
			if("Completed".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))) || "Interrupted".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID")))) {
				break;
			}
			Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
		}
 	}
	
		public void runVasteriAsteriConnectionBatch(LinkedHashMap<String, String> testData) throws Exception
    {
           Context.local().getPages().getPage(DataSearchPage.class).clickHomeWorkFlow();
           Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
           Context.local().getPages().getPage(HomeWorkflow.class).clickStartingBatchRuns();
           Context.local().getPages().getPage(StartBatchRunPage.class).clickVasteriAsteriConnection();
           //Context.local().getPages().getPage(IndividualBatches.class).enterProductList(testData.get("Product_ID"));
           Context.local().getPages().getPage(IndividualBatches.class).enterProductList(testData.get("Product_ID"));
           Context.local().getPages().getPage(IndividualBatches.class).enterStartDate(Context.local().getAppUtilityFunction().getApplicationDate());
           //Context.local().getPages().getPage(IndividualBatches.class).enterStartDate("06.06.2017");
           //Context.local().getPages().getPage(IndividualBatches.class).enterEndDate(Context.local().getWorkflows().getWorkflow(OfferWorkflow.class).valuesFetchedFromUI.get("PolicyId"));
           Context.local().getPages().getPage(IndividualBatches.class).enterEndDate(Context.local().getAppUtilityFunction().getApplicationDate());
           
           Report.updateReport("INFO","Starting Vasteri Asteri Connection Batch Run", "Vasteri Asteri Connection Batch Run");
           Context.local().getPages().getPage(BatchDetailsPage.class).clickStart();
           valuesFetchedFromUI.put("BatchID" ,Context.local().getPages().getPage(StartBatchRunPage.class).fetchBatchID());
           Report.updateReport("INFO","Started Vasteri-Asteri connection Batch", "Batch_ID");
           Context.local().getPages().getPage(DataSearchPage.class).clickHomeWorkFlow();
           Context.local().getPages().getPage(HomeWorkflow.class).clickOperations();
           Context.local().getPages().getPage(HomeWorkflow.class).clickBatchEntryLog();
           Context.local().getPages().getPage(BatchEntryLogPage.class).selectBatchToRun("Vasteri-Asteri connection");
           valuesFetchedFromUI.put("BatchName" ,"Vasteri-Asteri connection");
           Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
           Thread.sleep(10000);
           Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
           Report.updateReport("INFO","Batch ID :" + valuesFetchedFromUI.get("BatchID"));
           
           Context.local().getBatchUtilityFunction().waitForBatchCompletion("Vasteri-Asteri connection",valuesFetchedFromUI.get("BatchID"));
           /*int i;
           do
           {
            	i=150;
            	Context.local().getPages().getPage(BatchEntryLogPage.class).clickFind();
            	i--;
            	Thread.sleep(5000);
            	if("Completed".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))) || "Interrupted".equalsIgnoreCase(Context.local().getBatchUtilityFunction().fetchBatchStatus(valuesFetchedFromUI.get("BatchID"))))
            	{
                    break;
            	}
            }while(i>=0);*/
           
           Context.local().getBatchUtilityFunction().navigateToVasteriAsteriConnXmlEventReport(valuesFetchedFromUI.get("BatchID"));
         
    }
}