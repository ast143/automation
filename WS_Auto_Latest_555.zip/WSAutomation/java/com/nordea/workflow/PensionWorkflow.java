package com.nordea.workflow;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;
import com.nordea.pages.ChangeCalculation;
import com.nordea.pages.PageObject;
import com.nordea.utility.Report;

public class PensionWorkflow {
	
	final static Logger logger = Logger.getLogger(PensionWorkflow.class);
	HashMap<String, String> valuesFetchedFromUI = new HashMap<String, String>();
    PageObject pages = Context.local().getPages();

    /**
     * Description: This method validates the basic flow for pension change calculation by making small change in given cover & validate the before and after cover amount. 
     * @param testData
     * @throws Exception
     * @author kapil Kapoor, Nitesh Khanna
     */
    public void verifyPensionChangeCalculationFlow(LinkedHashMap<String, String> testData) throws Exception
    {
		Context.local().getPages().getPage(LHN.class).clickChangeCalculations();
		Context.local().getPages().getPage(ChangeCalculation.class).clickAdd();
		Context.local().getPages().getPage(ChangeCalculation.class).clickChangeCover();
		valuesFetchedFromUI=Context.local().getPolicyUtilityFunction().fetchPensionAmount(Context.local().getPages().getPage(ChangeCalculation.class).getTable());
		logger.info("Pension cover amount for all the covers: " + valuesFetchedFromUI);
		Report.updateReport("INFO", "Pension cover amount before change calculation", "pension amount01");
		Context.local().getAppUtilityFunction().clickOnLinkInTable(Context.local().getPages().getPage(ChangeCalculation.class).getTable(), testData.get("CoverName"));
		if("".equals(Context.local().getPages().getPage(ChangeCalculation.class).getCoverExpiryDate())){
			valuesFetchedFromUI.put("EffectiveDate", Context.local().getPages().getPage(ChangeCalculation.class).getCoverEffectiveDate());
			Context.local().getPages().getPage(ChangeCalculation.class).setCoverEffectiveDate(Context.local().getAppUtilityFunction().increaseDateByMonth(valuesFetchedFromUI.get("EffectiveDate")));
		}else{
			if(Context.local().getPages().getPage(ChangeCalculation.class).getDurationMonths()<11)
			{
				Context.local().getPages().getPage(ChangeCalculation.class).setDurationMonths((Context.local().getPages().getPage(ChangeCalculation.class).getDurationMonths()+1)+"");
			}else{
				Context.local().getPages().getPage(ChangeCalculation.class).setDurationMonths((Context.local().getPages().getPage(ChangeCalculation.class).getDurationMonths()-1)+"");
			}
		}
		Context.local().getPages().getPage(ChangeCalculation.class).clickCountStartEndDate();
		Context.local().getAppUtilityFunction().verifyErrorBoxIsDisplayed();
		Context.local().getPages().getPage(ChangeCalculation.class).clickSave();
		if(Context.local().getAppUtilityFunction().verifyErrorBoxIsDisplayed()){
			Context.local().getPages().getPage(ChangeCalculation.class).clickSave();
		}
		Context.local().getPages().getPage(ChangeCalculation.class).clickCalculate();
		Context.local().getAppUtilityFunction().verifyErrorBoxIsDisplayed();
		logger.info(Context.local().getPolicyUtilityFunction().fetchPensionAmount(Context.local().getPages().getPage(ChangeCalculation.class).getTable()));
		Report.updateReport("INFO", "Pension cover amount after change calculation", "pension amount02");
		if(Context.local().getAppUtilityFunction().compareMapValues(valuesFetchedFromUI, Context.local().getPolicyUtilityFunction().fetchPensionAmount(Context.local().getPages().getPage(ChangeCalculation.class).getTable())))
		{
			Report.updateReport("PASS", "Values are changed after performing change calculation");
		}
		else
		{
			Report.updateReport("FAIL", "Values are not changed after performing change calculation");
		}
		Context.local().getPages().getPage(ChangeCalculation.class).clickSave();
		Context.local().getPages().getPage(ChangeCalculation.class).clickSave();
		Context.global().getSeleniumUtils().waitForPageToLoad(10);
		if(Context.global().getSeleniumUtils().verifyElementPresent(Context.local().getPages().getPage(ChangeCalculation.class).getCommentBox(),"Comment Box")) {
			Context.local().getPages().getPage(ChangeCalculation.class).clickSave();
		}
		Context.local().getPages().getPage(ChangeCalculation.class).clickAccept();
		Context.local().getPages().getPage(ChangeCalculation.class).clickYes();
		Report.updateReport("INFO","Change Calculation ID : " + Context.local().getPages().getPage(ChangeCalculation.class).fetchChangeCalcID());
		if(Context.local().getPolicyUtilityFunction().fetchChangeCalcStatus(Context.local().getPages().getPage(ChangeCalculation.class).getTable(), Context.local().getPages().getPage(ChangeCalculation.class).fetchChangeCalcID()).equals("Completed")){
			Report.updateReport("PASS", "Pension Change Calculation Status is : Completed", "ChangeCalc");
			logger.info("Pension Change Calculation Status is: " + Context.local().getPolicyUtilityFunction().fetchChangeCalcStatus(Context.local().getPages().getPage(ChangeCalculation.class).getTable(), Context.local().getPages().getPage(ChangeCalculation.class).fetchChangeCalcID()));
		}
		else
		{	
			Report.updateReport("FAIL", "Pension Change Calculation Status is : " + Context.local().getPolicyUtilityFunction().fetchChangeCalcStatus(Context.local().getPages().getPage(ChangeCalculation.class).getTable(), Context.local().getPages().getPage(ChangeCalculation.class).fetchChangeCalcID()), "ChangeCalc");
			logger.info("Pension Change Calculation Status is : " + Context.local().getPolicyUtilityFunction().fetchChangeCalcStatus(Context.local().getPages().getPage(ChangeCalculation.class).getTable(), Context.local().getPages().getPage(ChangeCalculation.class).fetchChangeCalcID()));
		}
		
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Report.updateReport("INFO", "Policy cover tab after change calculation", "policy cover tab");
		if(Context.local().getAppUtilityFunction().compareMapValues(valuesFetchedFromUI, Context.local().getPolicyUtilityFunction().fetchPnsnAmntPolicyCoverTab(Context.local().getPages().getPage(ChangeCalculation.class).getTable()))){
			Report.updateReport("PASS", "Values are changed after performing change calculation on policy cover tab");
			logger.info("Values are changed after performing change calculation on policy cover tab");
		}
		else
		{
			Report.updateReport("FAIL", "Values are not changed after performing change calculation on policy cover tab");
			logger.info("Values are not changed after performing change calculation on policy cover tab");
		}
		
    }
}
	

	


