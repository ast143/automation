package com.nordea.workflow;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.nordea.framework.Context;
import com.nordea.pages.Confluence;
import com.nordea.utility.LoadPropertiesUtil;
import com.nordea.utility.LoggingUtils;

public class ConfluenceWorkflow {
	
  public static RemoteWebDriver driver;
  WebDriverWait wait;
  public static Confluence cnf;
  public static String screenshotPath="C:\\ReportScreenshot\\";
  public static String screenshotName;
  final static Logger logger = Logger.getLogger(ConfluenceWorkflow.class);
	
  /**
	* Method to handle windows popup to upload file
	*/
  
  public void actionUploadReport() throws Exception{
	  wait=new WebDriverWait(driver, 3000);
	  StringSelection sel = new StringSelection(screenshotPath+screenshotName);
	  Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sel,null);
	  cnf.clickBrowse();
	  Thread.sleep(1000);
	  Robot robot = new Robot();
	  Thread.sleep(1000);
	  robot.keyPress(KeyEvent.VK_ENTER);
	  robot.keyRelease(KeyEvent.VK_ENTER);
	  robot.keyPress(KeyEvent.VK_CONTROL);
	  robot.keyPress(KeyEvent.VK_V);
	  robot.keyRelease(KeyEvent.VK_CONTROL);
	  robot.keyRelease(KeyEvent.VK_V);
	  Thread.sleep(1000);
	  robot.keyPress(KeyEvent.VK_ENTER);
	  robot.keyRelease(KeyEvent.VK_ENTER);
	  Thread.sleep(1000);
	  cnf.clickUpload();

  }
 
  /**
 	 * Functionality: Updating execution results to Confluence.
 	 *  Input Parameter : 
 	 *  Return Type: Null
 	 */
  @Test
  public void updateResultToConfluence() throws Exception{
	  LoggingUtils.configureLogProperties();
	  logger.info("Uploading Result to Confluence.....");
	  System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "\\src\\main\\resources\\drivers\\IEDriverServer.exe");
	  DesiredCapabilities caps=DesiredCapabilities.internetExplorer();
	  caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	  caps.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);	
	  driver = new InternetExplorerDriver(caps);
	  Context.global().setDriver(driver);
	  String reportPath = LoadPropertiesUtil.configProps.getProperty("Execution_Report_Path")+"/"+LoadPropertiesUtil.configProps.getProperty("Execution_Report_Name")+".html";
	  driver.navigate().to(reportPath);
	  driver.manage().window().maximize();
	  Thread.sleep(3000);
	  String tempScreenshotName = LoadPropertiesUtil.configProps.getProperty("Execution_Report_Name");
	  screenshotName = tempScreenshotName+"_"+Context.global().getSeleniumUtils().getCurrentDateTimeStamp()+".png";
		 
	  File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	  FileUtils.copyFile(scrFile, new File(screenshotPath+screenshotName), true);
	  driver.get(LoadPropertiesUtil.configProps.getProperty("Confluence_Report_Path"));
	  cnf = new Confluence(driver);
	  actionUploadReport();
	  Thread.sleep(3000);
	  driver.quit();
  }
}
