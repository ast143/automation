package com.nordea.workflow;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.nordea.framework.Context;
import com.nordea.page.components.FooterSection;
import com.nordea.page.components.LHN;
import com.nordea.pages.CustomerPage;
import com.nordea.pages.DataSearchPage;
import com.nordea.pages.DeathClaim;
import com.nordea.pages.EventInsured;
import com.nordea.pages.InsuranceClaimsPage;
import com.nordea.pages.PageObject;
import com.nordea.pages.PolicyPage;
import com.nordea.pages.Withdrawal;
import com.nordea.utility.Report;

public class ClaimWorkflow {
	
	final static Logger logger = Logger.getLogger(ClaimWorkflow.class);
	HashMap<String, String> valuesFetchedFromUI = new HashMap<String, String>();
    PageObject pages = Context.local().getPages();
    
	public void Withdrawal(LinkedHashMap<String, String> testData)
			throws Exception {

		Context.local().getWorkflows().getWorkflow(GenericWorkflow.class)
				.updateSessionDate(testData.get("Session Time"));
		Report.updateReport("INFO",
				"Current Session Time:" + testData.get("Session Time"));

		String currentdate = Context.local().getPages()
				.getPage(FooterSection.class).getApplicationDate();
		String currenttime = Context.local().getPages()
				.getPage(FooterSection.class).getApplicationTime();

		Date date = new SimpleDateFormat("dd.MM.yyyy").parse(currentdate);
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		

		
		logger.info("currentdate:" + currentdate);
		logger.info("currenttime:" + currenttime);

		Calendar cal3 = Calendar.getInstance();
		Date time3 = new SimpleDateFormat("dd.MM.yyyy hh.mm.ss")
				.parse(currentdate + " " + currenttime);
		cal3.setTime(time3);

		String lowerlimit = "00.00.00";
		Date time1 = new SimpleDateFormat("dd.MM.yyyy hh.mm.ss")
				.parse(currentdate + " " + lowerlimit);
		Calendar cal = Calendar.getInstance();
		cal.setTime(time1);

		String Upperlimit = "13.00.00";
		Date time2 = new SimpleDateFormat("dd.MM.yyyy hh.mm.ss")
				.parse(currentdate + " " + Upperlimit);
		cal.setTime(time2);

		String Upperlimit1 = "23.59.59";
		Date time4 = new SimpleDateFormat("dd.MM.yyyy hh.mm.ss")
				.parse(currentdate + " " + Upperlimit1);
		cal.setTime(time4);

		Context.local().getPages().getPage(LHN.class).clickDataSearch();
		Context.local().getPages().getPage(DataSearchPage.class)
				.searchByPolicy(testData.get("Policy_ID"));
		String invoiceMode = Context.local().getPages()
				.getPage(PolicyPage.class).fetchMode().trim();
		if (invoiceMode.equalsIgnoreCase("Policy effective")) {
			Report.updateReport("Pass", "Policy is effective");

			String a = Context.local().getPages().getPage(Withdrawal.class)
					.fetchSavingsAmount();
			int savingAmt = Integer.parseInt(a);
			String b = testData.get("Withdrawal Amount");
			int withdrawalAmt = Integer.parseInt(b);

			if (savingAmt > withdrawalAmt) {
				Report.updateReport("Info",
						"The Saving Amount is more than Withdrawal Amount");
			} else {

				Report.updateReport("Info",
						"The Saving Amount is less than Withdrawal Amount");
			}
			Context.local().getPages().getPage(Withdrawal.class).clickSavings();
			Context.local().getPages().getPage(Withdrawal.class)
					.clickWithdrawalPlan();
			Context.local().getPages().getPage(Withdrawal.class)
					.clickAddSingle();
			Context.local().getPages().getPage(Withdrawal.class)
					.setWithdrawalAmount(testData.get("Withdrawal Amount"));

			String accountno = Context.local().getPages().getPage(Withdrawal.class).fetchAccountNumber();
            
            if(accountno == null)
            {
            	  Context.local().getPages().getPage(Withdrawal.class).clickSave();
            	  
            	  String errorbox = Context.local().getPages().getPage(Withdrawal.class).fetchErrorMessage().trim();
            	  
            	  
            	  if (errorbox.equalsIgnoreCase("Provide Valid account Number."))
            	  {
            		  Report.updateReport("info","Verified Error Box : Provide Valid account Number", "Verify Error Box");
            	  }
                  Context.local().getPages().getPage(Withdrawal.class).clickEditCustomer();
                  Context.local().getPages().getPage(CustomerPage.class).navigateToAccountsTab();
                  Context.local().getPages().getPage(CustomerPage.class).clickAccountAdd();
                  String account= testData.get("IBAN");
                   Context.local().getPages().getPage(CustomerPage.class).setIBAN(testData.get("IBAN"));
                  Context.local().getPages().getPage(CustomerPage.class).clickSave();
                  Report.updateReport("Pass", "Account number is added :" +account);
                  Context.local().getPages().getPage(CustomerPage.class).navigateToBasicTab();
                  Context.local().getPages().getPage(CustomerPage.class).clickReturn();
            }


			Context.local().getPages().getPage(Withdrawal.class).clickSave();
			if (Context.local().getPages().getPage(Withdrawal.class)
					.verifyCommentbox()) {
				Context.local().getPages().getPage(Withdrawal.class)
						.clickSave();
			}
			

			if (Context.local().getPages().getPage(Withdrawal.class)
					.verifyErrorBox()) {
				Report.updateReport("Fail", "Invalid Test Data",
						"Withdrawal Error Message");
			}

			else {

				// condition for 00 to 13 then
				if (time3.after(time1) && time3.before(time2)) {

					Report.updateReport("INFO",
							"Current time is Before Cut off Time");

					String newDate1 = Context.local().getAppUtilityFunction()
							.getNextWorkingDay(currentdate);
					String lastWithdrawlDate = Context.local().getPages()
							.getPage(Withdrawal.class)
							.fetchLastWithdrawalDate();

					if (Context.global().getSeleniumUtils()
							.assertText(newDate1, lastWithdrawlDate)) {

						Report.updateReport("PASS",
								"Expected Withdrawal Date :" + newDate1
										+ "and Actual Withdrawal Date :"
										+ lastWithdrawlDate);
						Report.updateReport("PASS",
								"Withdrawal Plan is added on " + newDate1,
								"Withdrawal");
					}

					// new date is the updated banking date
				}

				if (time3.after(time2) && time3.before(time4)) {

					Report.updateReport("INFO",
							"Current time is After Cut off Time");

					String newDate1 = Context
							.local()
							.getAppUtilityFunction()
							.getFutureDateConsideringBankHoliday(currentdate, 1);

					String lastWithdrawlDate = Context.local().getPages()
							.getPage(Withdrawal.class)
							.fetchLastWithdrawalDate();
					System.out.println(Context.local().getPages()
							.getPage(Withdrawal.class)
							.fetchLastWithdrawalDate());
					System.out.println(newDate1);

					if (Context.global().getSeleniumUtils()
							.assertText(newDate1, lastWithdrawlDate)) {

						Report.updateReport("PASS",
								"Expected Withdrawal Date :" + newDate1
										+ " Actual Withdrawal Date :"
										+ lastWithdrawlDate);
						Report.updateReport("PASS",
								"Withdrawal Plan is added on " + newDate1,
								"Withdrawal");
					}

				}

			}

		}

		else {
			Report.updateReport("Fail",
					"Policy is not effective. Please choose another policy");

		}

	}
	/**
 	 * Method to be used for making plan creation for regular withdrawal 
 	 * Method validates the date range. It also contains code for checking if the withdrawal amount is less than the total saving amount.
 	 * @param testData
 	 * @throws Exception
 	 * @author Poonam Joshi
 	 */
	
	public void regularWithdrawal(LinkedHashMap<String, String> testData)
			throws Exception {

		Context.local().getPages().getPage(LHN.class).clickDataSearch();
		Context.local().getPages().getPage(DataSearchPage.class)
				.searchByPolicy(testData.get("Policy_ID"));
		String invoiceMode = Context.local().getPages()
				.getPage(PolicyPage.class).fetchMode().trim();
		if (invoiceMode.equalsIgnoreCase("Policy effective")) {
			Report.updateReport("Pass", "Policy is effective");
			String strSavingAmnt = Context.local().getPages().getPage(Withdrawal.class)
					.fetchSavingsAmount();
			String strSavingAmnt1 = strSavingAmnt.replace(",",".");
			int savingAmt = Integer.parseInt(strSavingAmnt);
			Context.local().getPages().getPage(Withdrawal.class).clickSavings();
			Context.local().getPages().getPage(Withdrawal.class)
					.clickWithdrawalPlan();
			Context.local().getPages().getPage(Withdrawal.class)
					.clickAddRegular();
			Context.local().getPages().getPage(Withdrawal.class)
					.setStartDate(testData.get("Start Date"));
			Context.local().getPages().getPage(Withdrawal.class)
					.setEndDate(testData.get("End Date"));
			Context.local().getPages().getPage(Withdrawal.class)
					.setWithdrawalAmount(testData.get("Withdrawal Amount"));
			Context.local().getPages().getPage(Withdrawal.class)
					.setPaymentDate(testData.get("Payment Date"));
			Context.local().getPages().getPage(Withdrawal.class).clickSave();
			
			String strdate1=testData.get("Start Date").substring(0,2);
			String strdate2=testData.get("Payment Date");
			String strdate3=testData.get("End Date").substring(0,2);
			int date1 = Integer.parseInt(strdate1);
			int date2 = Integer.parseInt(strdate2);
			int date3 = Integer.parseInt(strdate3);
			int rwMonthDiff = Context.local().getAppUtilityFunction().getMonthDifference(testData.get("Start Date"),testData.get("End Date"));
			String strWithAmount=testData.get("Withdrawal Amount");
			int amount = Integer.parseInt(strWithAmount);
			
			if((date2 > date1) && (date2 <= date3)){
				int monthIncl  = rwMonthDiff+1;
				if ((savingAmt/monthIncl) < amount) {
					Report.updateReport("Info",
							"The Saving Amount is less than Withdrawal Amount");
				}
				else{
					Report.updateReport("Info",
							"The Saving Amount is greater than Withdrawal Amount");
				}

				
			}
			
			else if(((date2 > date1) && (date2 > date3))||((date2 < date1) && (date2 <= date3))){
				int monthIncl=rwMonthDiff;
				if ((savingAmt/monthIncl) < amount) {
					Report.updateReport("Info",
							"The Saving Amount is less than Withdrawal Amount");
				}
				else{
					Report.updateReport("Info",
							"The Saving Amount is greater than Withdrawal Amount");
				}
				
				
			}
			else
			{
				int  monthIncl=rwMonthDiff-1;
								if ((savingAmt/monthIncl) < amount) {
					Report.updateReport("Info",
							"The Saving Amount is less than Withdrawal Amount");
				}
				else{
					Report.updateReport("Info",
							"The Saving Amount is greater than Withdrawal Amount");
				}

			}

			if (Context.local().getPages().getPage(Withdrawal.class)
					.verifyErrorBox()) {
				Report.updateReport("Fail", "Invalid Test Data",
						"Regular withdrawal plans may not be overlapping");
			}

			else {

				String rwDateRange = testData.get("Start Date") + "-"
						+ testData.get("End Date");
				List<String> regWithDateRange = Context.local().getPages()
						.getPage(Withdrawal.class).fetchRegWithDateRangeList();

				if (regWithDateRange.contains(rwDateRange)) {
					
					Report.updateReport("Fail",
							"The Date Range for Regular withdrwal is not added","Date Range for Regular Withdrawal");
				} else {
					Report.updateReport("Pass",
							"The Date Range for Regular Withdrawal is added","No Date Range for Regular Withdrawal");
				}

			}
		}
		else{
			Report.updateReport("Fail",
					"The policy is not effective");
		}

	}

	public void DeathClaim(LinkedHashMap<String, String> testData)
			throws Exception {
		
		Context.local().getWorkflows().getWorkflow(GenericWorkflow.class).updateSessionDate(testData.get("Session Time"));
		Report.updateReport("INFO","Current Session Time:" + testData.get("Session Time"));
        pages.getPage(DataSearchPage.class).searchByPolicy(testData.get("Policy_ID"));
        Thread.sleep(2000);
        pages.getPage(EventInsured.class).clickEventInsured();
        pages.getPage(EventInsured.class).clickDeathEvent();
        String currentdate = pages.getPage(FooterSection.class).getApplicationDate();
        String deathDate = Context.local().getAppUtilityFunction().getFutureDate(currentdate,-1);
        System.out.println(deathDate);
        pages.getPage(DeathClaim.class).setDeathDate(deathDate);
        pages.getPage(DeathClaim.class).setNotificationDate(currentdate);
        pages.getPage(DeathClaim.class).setClaimantId(testData.get("Claimant_ID"));
        pages.getPage(DeathClaim.class).clickFindClaimant();
        pages.getPage(DeathClaim.class).setReceiverId(testData.get("Receiver_ID"));
        pages.getPage(DeathClaim.class).clickFindReceiver();
        pages.getPage(DeathClaim.class).clickContinue();
        if (pages.getPage(DeathClaim.class).verifyCommentBoxDisplay()){
            pages.getPage(DeathClaim.class).clickContinue();       
     }             
     
        Thread.sleep(2000);
        pages.getPage(DeathClaim.class).clickContinue();
       String amountOnAcceptance = pages.getPage(DeathClaim.class).fetchAmountonAcceptance();
        Report.updateReport("info","Amount on Acceptance :" +amountOnAcceptance );
                
     //Context.global().getSeleniumUtils().assertText(Amount, AmountOnAcceptance);
     pages.getPage(DeathClaim.class).clickAccept();
	}
	
	public void ClaimCreation(LinkedHashMap<String, String> testData)
			throws Exception {
     
     pages.getPage(InsuranceClaimsPage.class).clickClaimPopupYes();
     pages.getPage(InsuranceClaimsPage.class).clickClaimId();
     
     String claimId = pages.getPage(InsuranceClaimsPage.class).fetchClaimId();
     System.out.println(claimId);
     
    Report.updateReport("Pass", "Claim is Created. Claim Id :" +claimId);
     
	
      
     
     
     
     
     
     
     
        
     
	}
}
	

	


