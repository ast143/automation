package com.nordea.workflow;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;
import com.nordea.pages.ChangeCalculation;
import com.nordea.pages.OfferBasicPage;
import com.nordea.pages.OfferCoversPage;
import com.nordea.pages.OfferMakePolicy;
import com.nordea.pages.OfferResultCalcAndPrinting;
import com.nordea.pages.PageObject;
import com.nordea.utility.Report;
import com.nordea.utility.SeleniumUtils;


public class ChangeCal {
	
	HashMap<String, String> valuesFetchedFromUI = new HashMap<String, String>();
	PageObject pages = Context.local().getPages();
	Workflow workflow = Context.local().getWorkflows();
	final static Logger logger = Logger.getLogger(SeleniumUtils.class);
    
 	/**
 	 * Method to be used for running the Change calculation 
 	 * completely till verifying the event report and error report
 	 * @param testData
 	 * @throws Exception
 	 * @author Neville Menezes
 	 */
	
	public void navigateCovers() throws Exception {
		pages.getPage(LHN.class).clickPolicy();
		pages.getPage(LHN.class).clickChangeCalculations();	
		pages.getPage(OfferCoversPage.class).clickAdd();	
	}
	
	public void coverChanges(LinkedHashMap<String, String> testData) throws Exception {
		pages.getPage(ChangeCalculation.class).clickChangeCover();
		pages.getPage(OfferCoversPage.class).clickDB();
		pages.getPage(OfferCoversPage.class).setCoverAmount(testData.get("DeathBenifitAmount"));
		pages.getPage(OfferCoversPage.class).clickCalcPremiumAmount();
		
	}
	
	public void coverFrequencyChanges(LinkedHashMap<String, String> testData) throws Exception {
		
		pages.getPage(ChangeCalculation.class).clickChangeRepaymentPlan();
		pages.getPage(ChangeCalculation.class).clickEdit();
		pages.getPage(ChangeCalculation.class).setFrequency(testData.get("CC-Frequency"));
		Report.updateReport("INFO","Payment frequency changed to"+ testData.get("CC-Frequency"));
		pages.getPage(OfferCoversPage.class).clickSave();
		Report.updateReport("INFO","Payment frequency changes","ChangeOFRepaymentPlanPage");
		pages.getPage(ChangeCalculation.class).clickContinue();
		pages.getPage(ChangeCalculation.class).clickContinue();
		pages.getPage(ChangeCalculation.class).clickContinue();
		pages.getPage(ChangeCalculation.class).clickAccept();
		Report.updateReport("INFO","Change calculation is completed","ChnageCalculationPage");
	}
	
	
	
	public void acceptChangeCalculation() throws Exception {
		pages.getPage(OfferCoversPage.class).clickSave();
		pages.getPage(OfferCoversPage.class).clickSave();
		pages.getPage(OfferCoversPage.class).clickSave();
		pages.getPage(OfferBasicPage.class).clickContinue();
		pages.getPage(OfferBasicPage.class).clickContinue();
		pages.getPage(OfferBasicPage.class).clickContinue();
		pages.getPage(ChangeCalculation.class).clickAccept();
		pages.getPage(ChangeCalculation.class).clickPrintHD();
		pages.getPage(ChangeCalculation.class).checkHD();
		pages.getPage(OfferResultCalcAndPrinting.class).clickPrint();
		pages.getPage(OfferResultCalcAndPrinting.class).clickReturn();
		pages.getPage(OfferMakePolicy.class).clickPolicySignedYes();
		pages.getPage(OfferMakePolicy.class).checkHD();
		pages.getPage(ChangeCalculation.class).clickAccept();
		pages.getPage(ChangeCalculation.class).clickAccept();
	}
}