package WSAutomation;

import static io.restassured.RestAssured.given;
import io.restassured.path.json.JsonPath;
import io.restassured.path.json.config.JsonPathConfig;
import io.restassured.path.json.config.JsonPathConfig.NumberReturnType;
import io.restassured.response.Response;

import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import WSAutomation.utility.wsUtils;

public class webserviceUtils extends wsUtils {

	final static Logger logger = Logger.getLogger(webserviceUtils.class);

	String header = "X-DBF-ServiceRequestContext";
	String applicationJson = "application/json";
	String policyjsonpath = "policyList";
	String plcynoplcyList = "policyList.policyNumber";
	String dsplyVal = "policyList.displayValue";
	SoftAssert softassert = new SoftAssert();
	String appid = "asd";
	String logonid = "asd";
	String tmstmp = "2016-09-02-11.59.28.694000";

	/**
	 * webServicesAutopoc- Web Service automation POC - Test step automation fo
	 * all three web services
	 * 
	 * Functionality Created By : Alok Tiwari Reviewed By :Nitesh Khanna Review
	 * Date : 10/04/2017 Modified By : Alok Tiwari (Added the comments for this
	 * class) Last Modified Date : 16/01/2017 Reviewed By : Nitesh Khanna Review
	 * Date : 10/04/2017
	 */

	public void mbaWebSrvs(String baseURL, String custID, String wcNamenKey,
			String xdbfsrvsreqcntxt, String plsdHeader, String baseURL2,
			String baseURL3, String path, String plsdHeader1) {

		Response mbaSrvsRspns = given().headers(header, xdbfsrvsreqcntxt)
				.contentType(applicationJson).when()
				.get(baseURL + "/" + custID + "/" + wcNamenKey + "").then()
				.extract().response();

		logger.info(mbaSrvsRspns.asString());
		JsonPath str122 = mbaSrvsRspns.jsonPath(JsonPathConfig.jsonPathConfig()
				.numberReturnType(NumberReturnType.BIG_DECIMAL));
		String policyListRspns = str122.get(policyjsonpath).toString();
		String plcyNoLst = getAttributeValue(mbaSrvsRspns, plcynoplcyList)
				.toString();
		logger.info(plcyNoLst);
		logger.info(policyListRspns);
		String policyList[] = plcyNoLst.substring(2, plcyNoLst.length() - 2)
				.split(",");
		String dsplyValLst = getAttributeValue(mbaSrvsRspns, dsplyVal)
				.toString();
		logger.info(dsplyValLst);

		String valueList[] = dsplyValLst.substring(2, dsplyValLst.length() - 2)
				.split(",");
		HashMap<String, String> mbaplcyNoLstMap = convertToHashMap(policyList,
				valueList);

		int statCode = mbaSrvsRspns.getStatusCode();
		String rspcode = Integer.toString(statCode);
		String statMsg = mbaSrvsRspns.getStatusLine();
		verifyStatMsg(statMsg, "OK");
		verifyStatusCode(rspcode, "200");

		wsUtils.updateReport(
				"INFO",
				"<b>Test Secnario covered</b> : \n Run MBA web service for a customer ID and get display values of all the policy=<b>A</b>,\n"
						+ "Run Policy List Description web service (for same customer id as above) and get totalSavingsValue=<b>B</b>,\n"
						+ "Run Savings allocation Web service and get totalInvestmentsValue (Sum of all investmnets for each policy) for each policy=<b>C</b> \n"
						+ "<b>VALIDATIONS</b> : All the values must match i.e ==> <b>A=B=C</b>");
		wsUtils.updateReport("INFO",
				"<b style = \"color:blue;\"><i>WebService - MBA Service Description</i></b>");
		wsUtils.updateReport(
				"INFO",
				"<b>JSON Response for Customer ID - "
						+ custID
						+ "</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
						+ mbaSrvsRspns.asString() + "</textarea>");
		wsUtils.updateReport("INFO",
				"'Policy number' & 'Display Value' for the customer ID - '"
						+ custID + "' are " + "'" + plcyNoLst + "'  &  '"
						+ dsplyValLst + "' respectively");

		Response plsdSrvsRspns = given()
				.headers("cust-id", custID, header, plsdHeader,
						"endapplication-id", appid, "logon-id", logonid,
						"timestamp", tmstmp).contentType(applicationJson)
				.when().get(baseURL2).then().extract().response();

		logger.info(plsdSrvsRspns.asString());
		wsUtils.updateReport(
				"INFO",
				"<b style = \"color:blue;\"><i>WebService - Policy List Service Description</i></b>");
		wsUtils.updateReport(
				"INFO",
				"<b>JSON Response</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
						+ plsdSrvsRspns.asString() + "</textarea>");

		String ldsrspnsStatus = getAttributeValue(plsdSrvsRspns, "result")
				.toString();
		if (ldsrspnsStatus.contains("ERROR")) {
			wsUtils.updateReport("INFO",
					"There is error in the web service response");
			logger.info("An error has occured in the web service response");
			String errorCode = getAttributeValue(plsdSrvsRspns,
					"response.errorCode").toString();
			String errorText = getAttributeValue(plsdSrvsRspns,
					"response.errorText").toString();
			wsUtils.updateReport("INFO", "The error code is : '" + errorCode
					+ "'");
			logger.info("The response error code is : '" + errorCode + "'");
			wsUtils.updateReport("INFO", "The error text is : '" + errorText
					+ "'");
			logger.info("The response error text is : '" + errorText + "'");
			softassert.fail();
		}

		String policyListPolicyNo = getAttributeValue(plsdSrvsRspns,
				"response.policyList.policyNumber").toString();
		logger.info(policyListPolicyNo);
		String policyListNumber[] = policyListPolicyNo.substring(1,
				policyListPolicyNo.length() - 1).split(",");
		String totalSavings = getAttributeValue(plsdSrvsRspns,
				"response.policyList.savingDetails.totalSavings").toString();
		logger.info(totalSavings);
		String totalSavingsList[] = totalSavings.substring(1,
				totalSavings.length() - 1).split(",");

		HashMap<String, String> plsdSrvsRspnsMap = convertToHashMap(
				policyListNumber, totalSavingsList);

		boolean valCompair = compareValues(mbaplcyNoLstMap, plsdSrvsRspnsMap);
		if (valCompair == true) {
			wsUtils.updateReport(
					"PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Expected <b>displayValue</b> from MBA Service are MATCHING with actual <b>totalSavings</b> "
							+ "value from Policy List Service Description-Web Service");
		}
		if (valCompair == false) {
			wsUtils.updateReport(
					"FAIL",
					"<b style = \"color:red;\">Validation</b> : 'displayValue' &&  'totalSavings' did not mached");
			try {
				Assert.fail("'displayValues' of Holder policies from MBA Web Service are not macthing with "
						+ "totalSavings valuyes of LDS web services");
			} catch (AssertionError e) {
				logger.info(e);
			}
		}

		wsUtils.updateReport(
				"INFO",
				"<b style = \"color:blue;\"><i>WebService - Saving Allocation Details Service Description</i></b>");
		for (String str : policyList) {
			Response savingallocationRspns = given()
					.headers("cust-id", custID, header, plsdHeader1,
							"endapplication-id", "asd", "logon-id", "asd",
							"timestamp", "2016-09-02-11.59.28.694000")
					.contentType(applicationJson).when()
					.get(baseURL3 + "/" + str.trim() + "/" + path + "").then()
					.extract().response();

			logger.info(savingallocationRspns.asString());
			wsUtils.updateReport(
					"INFO",
					"<b>JSON Response for Policy No - "
							+ str
							+ "</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
							+ savingallocationRspns.asString() + "</textarea>");
			String rspnsStatus = getAttributeValue(savingallocationRspns,
					"result").toString();

			if (rspnsStatus.contains("SUCCESS")) {
				String invSavingsValue = getAttributeValue(
						savingallocationRspns,
						"response.investments.investmentSavingsValue")
						.toString();
				logger.info(invSavingsValue);
				wsUtils.updateReport("INFO",
						"Inbdividual investment values for policy no '" + str
								+ "' are : '" + invSavingsValue + "'");
				String invSvngs[] = invSavingsValue.substring(1,
						invSavingsValue.length() - 1).split(",");
				BigDecimal totalSum = addInvValue(invSvngs);
				BigDecimal totalSumVal1 = totalSum.setScale(2,
						BigDecimal.ROUND_HALF_EVEN);
				String totalSumVal = totalSumVal1.toString();
				logger.info("total investmentSavingsValue for policy no '"
						+ str + "' is '" + totalSumVal + "'");
				HashMap<String, String> plsdSrvsRspnsMap1 = new HashMap<String, String>();
				plsdSrvsRspnsMap1.put(str.trim(), totalSumVal);

				boolean compareVal = compareList(plsdSrvsRspnsMap1,
						plsdSrvsRspnsMap);
				if (compareVal == true) {
					wsUtils.updateReport(
							"PASS",
							"<b style = \"color:forestgreen;\">Validation</b> : Value Matched ===> Total investmentSavingsValue '"
									+ totalSumVal
									+ "' for policy no '"
									+ str.trim()
									+ "' from 'savingsAllocationDetails' Web Service"
									+ " are matching with 'Policy List Discription' Web Service");
				}
				if (compareVal == false) {
					wsUtils.updateReport(
							"FAIL",
							"<b style = \"color:red;\">Validation</b> : Value mismatched ==> for policy no <b>'"
									+ str.trim() + "'</b>");
					softassert.fail();
				}
			}

			if (rspnsStatus.contains("ERROR")) {
				wsUtils.updateReport("INFO",
						"There is error in the web service response");
				String errorCodeSvngs = getAttributeValue(
						savingallocationRspns, "response.errorCode").toString();
				String errorTextSvngs = getAttributeValue(
						savingallocationRspns, "response.errorText").toString();
				wsUtils.updateReport("INFO", "The error code is : '"
						+ errorCodeSvngs + "'");
				wsUtils.updateReport("INFO", "The error text is : '"
						+ errorTextSvngs + "'");
				softassert.fail();
			}
		}
	}

	public void mbaWebSrvice(String baseURL, String custID, String wcNamenKey,
			String xdbfsrvsreqcntxt, String plsdHeader, String baseURL2,
			String baseURL3, String path, String plsdHeader1) {

		Response mbaSrvsRspns = given().headers(header, xdbfsrvsreqcntxt)
				.contentType(applicationJson).when()
				.get(baseURL + "/" + custID + "/" + wcNamenKey + "").then()
				.extract().response();

		logger.info(mbaSrvsRspns.asString());
		JsonPath str122 = mbaSrvsRspns.jsonPath(JsonPathConfig.jsonPathConfig()
				.numberReturnType(NumberReturnType.BIG_DECIMAL));
		String policyListRspns = str122.get(policyjsonpath).toString();
		String plcyNoLst = getAttributeValue(mbaSrvsRspns, plcynoplcyList)
				.toString();
		logger.info(plcyNoLst);
		logger.info(policyListRspns);
		String policyList[] = plcyNoLst.substring(2, plcyNoLst.length() - 2)
				.split(",");
		String dsplyValLst = getAttributeValue(mbaSrvsRspns, dsplyVal)
				.toString();
		logger.info(dsplyValLst);

		String valueList[] = dsplyValLst.substring(2, dsplyValLst.length() - 2)
				.split(",");
		HashMap<String, String> mbaplcyNoLstMap = convertToHashMap(policyList,
				valueList);

		int statCode = mbaSrvsRspns.getStatusCode();
		String rspcode = Integer.toString(statCode);
		String statMsg = mbaSrvsRspns.getStatusLine();
		verifyStatMsg(statMsg, "OK");
		verifyStatusCode(rspcode, "200");

		wsUtils.updateReport(
				"INFO",
				"<b>Test Secnario covered</b> : \n Run MBA web service for a customer ID and get display values of all the policy=<b>A</b>,\n"
						+ "Run Policy List Description web service (for same customer id as above) and get totalSavingsValue=<b>B</b>,\n"
						+ "Run Savings allocation Web service and get totalInvestmentsValue (Sum of all investmnets for each policy) for each policy=<b>C</b> \n"
						+ "<b>VALIDATIONS</b> : All the values must match i.e ==> <b>A=B=C</b>");
		wsUtils.updateReport("INFO",
				"<b style = \"color:blue;\"><i>WebService - MBA Service Description</i></b>");
		wsUtils.updateReport(
				"INFO",
				"<b>JSON Response for Customer ID - "
						+ custID
						+ "</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
						+ mbaSrvsRspns.asString() + "</textarea>");

		Response plsdSrvsRspns = given()
				.headers("cust-id", custID, header, plsdHeader,
						"endapplication-id", appid, "logon-id", logonid,
						"timestamp", tmstmp).contentType(applicationJson)
				.when().get(baseURL2).then().extract().response();

		logger.info(plsdSrvsRspns.asString());
		wsUtils.updateReport(
				"INFO",
				"<b style = \"color:blue;\"><i>WebService - Policy List Service Description</i></b>");
		wsUtils.updateReport(
				"INFO",
				"<b>JSON Response</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
						+ plsdSrvsRspns.asString() + "</textarea>");

		String ldsrspnsStatus = getAttributeValue(plsdSrvsRspns, "result")
				.toString();
		if (ldsrspnsStatus.contains("ERROR")) {
			wsUtils.updateReport("INFO",
					"There is error in the web service response");
			logger.info("An error has occured in the web service response");
			String errorCode = getAttributeValue(plsdSrvsRspns,
					"response.errorCode").toString();
			String errorText = getAttributeValue(plsdSrvsRspns,
					"response.errorText").toString();
			wsUtils.updateReport("INFO", "The error code is : '" + errorCode
					+ "'");
			logger.info("The response error code is : '" + errorCode + "'");
			wsUtils.updateReport("INFO", "The error text is : '" + errorText
					+ "'");
			logger.info("The response error text is : '" + errorText + "'");
			softassert.fail();
		}

		String policyListPolicyNo = getAttributeValue(plsdSrvsRspns,
				"response.policyList.policyNumber").toString();
		logger.info(policyListPolicyNo);
		String policyListNumber[] = policyListPolicyNo.substring(1,
				policyListPolicyNo.length() - 1).split(",");
		String totalSavings = getAttributeValue(plsdSrvsRspns,
				"response.policyList.savingDetails.totalSavings").toString();
		logger.info(totalSavings);
		String totalSavingsList[] = totalSavings.substring(1,
				totalSavings.length() - 1).split(",");

		HashMap<String, String> plsdSrvsRspnsMap = convertToHashMap(
				policyListNumber, totalSavingsList);

		wsUtils.updateReport(
				"INFO",
				"<b style = \"color:blue;\"><i>WebService - Saving Allocation Details Service Description</i></b>");
		for (String str : policyList) {
			Response savingallocationRspns = given()
					.headers("cust-id", custID, header, plsdHeader1,
							"endapplication-id", "asd", "logon-id", "asd",
							"timestamp", "2016-09-02-11.59.28.694000")
					.contentType(applicationJson).when()
					.get(baseURL3 + "/" + str.trim() + "/" + path + "").then()
					.extract().response();

			logger.info(savingallocationRspns.asString());
			wsUtils.updateReport(
					"INFO",
					"<b>JSON Response for Policy No - "
							+ str
							+ "</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
							+ savingallocationRspns.asString() + "</textarea>");
			String rspnsStatus = getAttributeValue(savingallocationRspns,
					"result").toString();

			if (rspnsStatus.contains("SUCCESS")) {
				String invSavingsValue = getAttributeValue(
						savingallocationRspns,
						"response.investments.investmentSavingsValue")
						.toString();
				logger.info(invSavingsValue);
				wsUtils.updateReport("INFO",
						"Inbdividual investment values for policy no '" + str
								+ "' are : '" + invSavingsValue + "'");
				String invSvngs[] = invSavingsValue.substring(1,
						invSavingsValue.length() - 1).split(",");
				BigDecimal totalSum = addInvValue(invSvngs);
				BigDecimal totalSumVal1 = totalSum.setScale(2,
						BigDecimal.ROUND_HALF_EVEN);
				String totalSumVal = totalSumVal1.toString();
				logger.info("total investmentSavingsValue for policy no '"
						+ str + "' is '" + totalSumVal + "'");
				HashMap<String, String> plsdSrvsRspnsMap1 = new HashMap<String, String>();

				plsdSrvsRspnsMap1.put(str.trim(), totalSumVal);
				String mbaval = mbaplcyNoLstMap.get(str.trim());
				String plsdVal = plsdSrvsRspnsMap.get(str.trim());

				if (mbaval.equals(plsdVal) && plsdVal.equals(totalSumVal)) {
					wsUtils.updateReport(
							"PASS",
							"<b style = \"color:forestgreen;\">Validation</b> : For policy No-<b>"
									+ str
									+ "</b> of type Holder : displayValue from MBA Service = <b>"
									+ mbaval
									+ "</b> , totalSavings from Policy List Description Service = <b>"
									+ plsdVal
									+ "</b> & "
									+ "investmentSavingsValue (<b>Sum of all investments</b>) from Savings Allocation Service = <b>"
									+ totalSumVal
									+ "</b> : <b style = \"color:forestgreen;\">All values are matching</b>");
					logger.info("For policy No-"
							+ str
							+ " of type Holder : displayValue from MBA Service-"
							+ mbaval
							+ " , totalSavings from Policy List Description Service-"
							+ plsdVal
							+ " & "
							+ "investmentSavingsValue (<b>Sum of all investments : "
							+ invSavingsValue
							+ "</b>) from Savings Allocation Service-"
							+ totalSumVal + " : All values are matching");
				} else {
					wsUtils.updateReport(
							"fAIL",
							"<b style = \"color:red;\">Validation</b> : For policy No-<b>"
									+ str
									+ "</b> of type Holder : displayValue from MBA Service=<b>"
									+ mbaval
									+ "</b> , totalSavings from Policy List Description Service =<b>"
									+ plsdVal
									+ "</b> & "
									+ "investmentSavingsValue (<b>Sum of all the investments</b>) from Savings Allocation Service=<b>"
									+ totalSumVal
									+ "</b> : <b style = \"color:red;\">All values are NOT matching</b>");
					logger.info("For policy No-"
							+ str
							+ " of type Holder : displayValue from MBA Service-"
							+ mbaval
							+ " , totalSavings from Policy List Description Service-"
							+ plsdVal
							+ " & "
							+ "investmentSavingsValue (<b>Sum of all the investments : "
							+ invSavingsValue
							+ "</b>) from Savings Allocation Service-"
							+ totalSumVal + " : All values are NOT matching");
				}

				if (rspnsStatus.contains("ERROR")) {
					wsUtils.updateReport("INFO",
							"There is error in the web service response");
					String errorCodeSvngs = getAttributeValue(
							savingallocationRspns, "response.errorCode")
							.toString();
					String errorTextSvngs = getAttributeValue(
							savingallocationRspns, "response.errorText")
							.toString();
					wsUtils.updateReport("INFO", "The error code is : '"
							+ errorCodeSvngs + "'");
					wsUtils.updateReport("INFO", "The error text is : '"
							+ errorTextSvngs + "'");
					softassert.fail();
				}
			}
		}
	}
}