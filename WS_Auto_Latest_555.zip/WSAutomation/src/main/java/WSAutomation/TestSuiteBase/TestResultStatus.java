package WSAutomation.TestSuiteBase;

public class TestResultStatus {
	public static boolean Testfail = false;
}
