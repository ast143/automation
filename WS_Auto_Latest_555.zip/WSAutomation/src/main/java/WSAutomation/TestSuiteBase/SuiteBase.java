//Find More Tutorials On WebDriver at -> http://software-testing-tutorials-automation.blogspot.com
package WSAutomation.TestSuiteBase;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Properties;

import org.apache.log4j.Logger;

import WSAutomation.webserviceUtils;
import WSAutomation.utility.wsUtils;

public class SuiteBase {
	
	final static Logger logger = Logger.getLogger(SuiteBase.class);	
	public static Properties Config = null;
	public String CaseToRun = null;
	public webserviceUtils wsobj = new webserviceUtils();
	public wsUtils utils = new wsUtils();

	public void init() throws IOException {

		// Create object of Java Properties class
		Config = new Properties();
		FileInputStream fip = new FileInputStream(
				System.getProperty("user.dir")
						+ "\\src\\main\\java\\WSAutomation\\Config\\Config.properties");
		Config.load(fip);
		logger.info("Config.properties file loaded successfully.");
	}

	public String getData(LinkedHashMap<String, String> data, String key) {
		return data.get(key);
	}
}
