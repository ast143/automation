package WSAutomation.utility;

import io.restassured.path.json.config.JsonPathConfig;
import io.restassured.path.json.config.JsonPathConfig.NumberReturnType;
import io.restassured.path.xml.XmlPath;
import io.restassured.path.xml.config.XmlPathConfig;
import io.restassured.response.Response;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.Assert;
import org.testng.ITestResult;

import WSAutomation.TestSuiteBase.SuiteBase;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.NetworkMode;

public class wsUtils {
	/**
	 * webServicesAutopoc- Web Service automation POC for three web services MBA
	 * Service Description , Policy List Service Description , Saving Allocation
	 * Details Service Description All the common methods/functions are stored
	 * here.
	 * 
	 * Functionality Created By : Alok Tiwari Reviewed By :Nitesh Khanna Review
	 * Date : 05/04/2017 Modified By : Alok Tiwari (Added the comments for this
	 * class) Last Modified Date : 16/01/2017 Reviewed By : Nitesh Khanna Review
	 * Date : 05/04/2017
	 */

	public Logger Add_Log = Logger.getLogger(wsUtils.class);

	public HashMap<String, String> metaData = new HashMap<String, String>();

	public static ExtentReports report = null;
	public static ExtentTest logger;
	public static String TCname;

	public static void initiateLogger() {
		PropertyConfigurator.configure(System.getProperty("user.dir")
				+ File.separator + "src" + File.separator + "main"
				+ File.separator + "java" + File.separator + "WSAutomation"
				+ File.separator + "Config"
				+ File.separator + "log4j.properties");
	}

	/**
	 * Functionality: Extent Report Input Parameter : initiate report Type: Null
	 */
	public static void initiateReport(String testcasename) {
		TCname = testcasename;
		if (report == null) {
			report = new ExtentReports(SuiteBase.Config.get(
					"Execution_Report_Path").toString(), NetworkMode.OFFLINE);
		}
		logger = report.startTest(testcasename);
		System.out.println("Report intiated");
	}

	public static synchronized void categorizeTest(String category) {
		logger.assignCategory(category);
	}

	/**
	 * Functionality: Extent Report Input Parameter : <String Status>, <String
	 * stepName> Type: Null
	 */
	public static synchronized void updateReport(String status, String stepName) {
		if (status.equalsIgnoreCase("PASS")) {
			logger.log(LogStatus.PASS, stepName);
		} else if (status.equalsIgnoreCase("FAIL")) {
			logger.log(LogStatus.FAIL, stepName);
		} else if (status.equalsIgnoreCase("INFO")) {
			logger.log(LogStatus.INFO, stepName);
		}
	}

	/**
	 * Functionality: Extent Report Input Parameter : Test Result Type: Null
	 */
	public static synchronized void updateReport(ITestResult result)
			throws IOException {
		if (result.getStatus() == ITestResult.SUCCESS) {
			report.endTest(logger);
			report.flush();
		}
		if (result.getStatus() == ITestResult.FAILURE) {
			updateReport("FAIL", TCname);
			report.endTest(logger);
			report.flush();
		}
	}

	/**
	 * Functionality: Verify JSON response Input Parameter : Actual response
	 * string , Expected response String Type: Null
	 */
	public boolean verifyStatMsg(String actualStr, String expectedStr) {
		try {
			Assert.assertTrue(actualStr.contains(expectedStr));
		} catch (AssertionError e) {
			Add_Log.info("Actual String'" + actualStr + "'Does not 'Contains''"
					+ expectedStr + "'");
			Assert.fail("Actual String'" + actualStr + "'Does not'Contains''"
					+ expectedStr + "'");
			return false;
		}
		return true;
	}

	/**
	 * Functionality: Verify JSON response Code Input Parameter : Actual
	 * response Code , Expected response Code Type: Null
	 */
	public boolean verifyStatusCode(String actualStr, String expectedStr) {
		try {
			Assert.assertTrue(actualStr.contains(expectedStr));
			Add_Log.info("Validation of Response Code from the JSON Response is SUCCESSFULL");
		} catch (AssertionError e) {
			Add_Log.info("Actual String '" + actualStr
					+ "' Does not 'Contains' '" + expectedStr + "'");
			Assert.fail("Actual String '" + actualStr
					+ "' Does not 'Contains' '" + expectedStr + "'");
			return false;
		}
		return true;
	}

	/**
	 * Functionality: Pass timestamp Header in web service request Input
	 * Parameter : Null Type: Null
	 */
	public String timestemp() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-dd-MM.HH.mm.ss.ms");
		String dtfrmt = dateFormat.format(new Date());
		return dtfrmt;
	}

	/**
	 * Functionality: Get attribute values of various JSOn objects Input
	 * Parameter : JSON Response , JSONPath Type: Null
	 */
	public Object getAttributeValue(Response response1, String JsonPath) {
		try {
			Object jsonObj = response1.jsonPath(
					JsonPathConfig.jsonPathConfig().numberReturnType(
							NumberReturnType.BIG_DECIMAL)).get(JsonPath);
			return jsonObj;
		} catch (Exception e) {
			Add_Log.info(e);
			return 0;
		}
	}

	/**
	 * Functionality: Verify JSON response Code Input Parameter : Actual
	 * response Code , Expected response Code Type: Null
	 */
	public boolean verifyJson(String actualStr, String expectedStr) {
		try {
			Assert.assertTrue(actualStr.contains(expectedStr));
			Add_Log.info("Validation of JSON Response is SUCCESSFULL");
		} catch (AssertionError e) {
			Add_Log.info("Actual String '" + actualStr
					+ "' Does not 'Contains' '" + expectedStr + "'");
			Assert.fail("Actual String '" + actualStr
					+ "' Does not 'Contains' '" + expectedStr + "'");
			return false;
		}
		return true;
	}

	/**
	 * Functionality: Convert to hash map from ArrayList of type String Input
	 * Parameter : ArrayList<String> Type: Null
	 */
	public HashMap<String, String> convertToHashMap(String[] policyIdList,
			String[] policyValues) {
		HashMap<String, String> map = new HashMap<>();

		for (int count = 0; count < policyIdList.length; count++) {
			map.put(policyIdList[count].trim(), policyValues[count].trim());
		}
		return map;
	}

	/**
	 * Functionality: Compare Two value as 'Key-Value' Pair. Input Parameter :
	 * <FirstHashMap> , <SecondHashMap> Type: Null
	 */
	public boolean compareList(HashMap<String, String> firstMap,
			HashMap<String, String> secondMap) {
		Set<String> keys = firstMap.keySet();
		boolean flag = true;
		List<String> failedIdList = new ArrayList<String>();

		for (String key : keys) {
			if (firstMap.get(key).equals(secondMap.get(key))) {
				wsUtils.updateReport(
						"INFO",
						"Expected value from '<b><i>Polciy List Service description</i></b>' is this <b>'"
								+ secondMap.get(key)
								+ "'</b> & actual value from '<b><i>Savings Allocations Web Service</i></b>' is this <b>'"
								+ firstMap.get(key) + "'</b>");
				Add_Log.info("Matched Sucessfully=> " + key + ": "
						+ firstMap.get(key));
			} else {
				failedIdList.add(key);
				Add_Log.info("Expected value from '<b><i>Polciy List Service description</i></b>' is this '"
						+ secondMap.get(key)
						+ "' & actual from '<b><i>Savings Allocations Web Service</i></b>' is this '"
						+ firstMap.get(key) + "'");
				wsUtils.updateReport("INFO",
						"Expected value is this <b>'" + secondMap.get(key)
								+ "'</b> & actual value is this <b>'"
								+ firstMap.get(key) + "'</b>");
				flag = false;
			}
		}
		if (flag == false) {
			Add_Log.info("List of Policy ID for which values didn't matched:"
					+ failedIdList);
			try {
				Assert.fail();
			} catch (AssertionError e) {
				Add_Log.info("AssertionError has occured", e);
			}
			return false;
		}
		return true;
	}

	/**
	 * Functionality: Compare Two value as 'Key-Value' Pair. Input Parameter :
	 * <FirstHashMap> , <SecondHashMap> Type: Null
	 */
	public boolean compareValues(HashMap<String, String> firstMap,
			HashMap<String, String> secondMap) {
		Set<String> keys = firstMap.keySet();
		boolean flag = true;
		List<String> failedIdList = new ArrayList<String>();

		for (String key : keys) {
			if (firstMap.get(key).equals(secondMap.get(key))) {
				wsUtils.updateReport(
						"INFO",
						"For Policy No - <b>"
								+ key
								+ "</b> of type Holder : Expected value from MBA Web Service is this <b>'"
								+ secondMap.get(key)
								+ "'</b> & actual value from Policy List Web Service is this <b>'"
								+ firstMap.get(key) + "'</b>");
				Add_Log.info("Matched Sucessfully=> " + key + ": "
						+ firstMap.get(key));
			} else {
				failedIdList.add(key);
				Add_Log.info("Expected is this '" + secondMap.get(key)
						+ "' & actual is this '" + firstMap.get(key) + "'");
				wsUtils.updateReport(
						"INFO",
						"Expected value from MBA Web Service is this <b>'"
								+ secondMap.get(key)
								+ "'</b> & actual value from Policy List Web Service is this <b>'"
								+ firstMap.get(key) + "'</b>");
				flag = false;
			}
		}
		if (flag == false) {
			Add_Log.info("List of Policy ID for which values didn't matched:"
					+ failedIdList);
			try {
				Assert.fail();
			} catch (AssertionError e) {
				Add_Log.info("AssertionError has occured", e);
			}
			return false;
		}
		return true;
	}

	/**
	 * Functionality: To do sum of all savings values of an policy id Input
	 * Parameter : <String[] invSvngs> Type: Null
	 */

	public static BigDecimal addInvValue(String[] invSvngs) {
		BigDecimal dc = new BigDecimal(0);
		for (String str : invSvngs) {
			double digit = Double.parseDouble(str);
			dc = dc.add(new BigDecimal(digit));
		}
		return dc;
	}
}