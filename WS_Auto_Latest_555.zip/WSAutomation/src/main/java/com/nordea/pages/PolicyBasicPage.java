package com.nordea.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: PolicyBasicPage - This Page is for fetching all information from policy basic page 
 * and methods related to  Interested parties,sales info,time specific search,pension forecast.
 * .
 * Navigation to this page is by clicking on LHN >> Policy >>policy
 * 
 * Abbreviations
 * VAEIC = View account events including cancelled
 * 
 * 
 * Functionality Created By  	: Atluri Vinay Kumar
 * Reviewed By                 	: Debabrata
 * Review Date                	: 17/02/2017
 * Modified By 				   	: 
 * Last Modified Date        	: 
 * Reviewed By					: 
 * Review Date					: 
*/

public class PolicyBasicPage implements Page {

	@FindBy(xpath = "//p[@class='idfield']")									
	private WebElement elmPolicyInfo;
	
	@FindBy(xpath = "//th[contains(text(),'Mode')]//following-sibling::td[1]")									
	private WebElement elmMode;
	
	@FindBy(xpath = "//th[contains(text(),'Policy period')]//following-sibling::td[1]")									
	private WebElement elmPolicyPeriod;
	
	@FindBy(xpath = "//th[contains(text(),'Savings')]//following-sibling::td[1]")									
	private WebElement elmPolicyBasicSavings;
	
	@FindBy(linkText="Interested parties")
	private WebElement lnkInterestedParties;
	
	@FindBy(name="add")
	private WebElement btnAdd;
	
	@FindBy(name="newadd")
	private WebElement btnAppraisalAdd;
	
	@FindBy(xpath="//select[contains(@name,'indexedFieldRole')]")
	private WebElement drpIPRole;
	
	@FindBy(xpath="//input[contains(@name,'fieldNames')]")
	private WebElement txtIPUserName;
	
	@FindBy(name="nameSearch")
	private WebElement btnNameFind;
	
	@FindBy(xpath="//input[contains(@name,'indexedFieldIdentityNumber')]")
	private WebElement txtIpIdentifier;
	
	@FindBy(name="identifierSearch")
	private WebElement btnIdentifierFind;
	
	@FindBy(xpath="//input[contains(@name,'indexedFieldEffectiveDate')]")
	private WebElement txtIpStartDate;
	
	@FindBy(xpath="//input[contains(@name,'indexedFieldExpiryDate')]")
	private WebElement txtIpEndDate;
	
	@FindBy(name="save")
	private WebElement btnSave;
	
	@FindBy(linkText="Sales info")
	private WebElement lnkSalesInfo;
	
	@FindBy(name="cancel")
	private WebElement btnReturn;
	
	@FindBy(linkText="Time-specific enquiry")
	private WebElement lnkTimeSpecificEntry;
	
	@FindBy(name="queryDate")
	private WebElement txtEnquiryDate;
	
	@FindBy(name="enquiryDate")
	private WebElement btnEnquiryView;
	
	@FindBy(name="currentDate")
	private WebElement btnCurrentDate;
	
	@FindBy(linkText="Appraisal handling")
	private WebElement lnkAppraisalHandling;
	
	@FindBy(linkText="Pension Forecast")
	private WebElement lnkPensionForecast;
	
	@FindBy(linkText="Agreement between company and the insured")
	private WebElement lnkAggBtwCmpnyNInsured;
	
	
	@FindBy(linkText="Savings")
	private WebElement tabSavings;
	
	@FindBy(xpath="//th[text()='Investment']/../../../tbody/tr/td[1]")
	private List<WebElement> eleinvestmentList;
	
	
	public PolicyBasicPage(){
		PageFactory.initElements(Context.global().getDriver(), this);
	}
    
    public String[] fetchPolicyInfo(){
	     String policyInfo=Context.global().getSeleniumUtils().getText(this.elmPolicyInfo);
	     return policyInfo.split("|");
    }
    
    public String fetchPolicyId(){
	     String[] policyInfo=fetchPolicyInfo();	     
	     return policyInfo[2];
   }
    
    public String fetchMode(){
	    return Context.global().getSeleniumUtils().getText(this.elmMode);
    }
    
    public String fetchPolicyPeriod(){
	    return Context.global().getSeleniumUtils().getText(this.elmPolicyPeriod);
    }
	
    public String fetchPolicyBasicSavings(){
	    return Context.global().getSeleniumUtils().getText(this.elmPolicyBasicSavings);
    }
    
    public void clickInterestedParties(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkInterestedParties, "Interested parties link");
    } 
    
    public void clickFind() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnNameFind, "Find button");
	}
    
    public void clickReturn() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnReturn, "Return button");
	}
    
    public void clickView() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnEnquiryView, "Enquiry view button");
	}
    
    public void clickCurrentDate() {
		Context.global().getSeleniumUtils().clickOnElement(this.btnCurrentDate, "Current date button");
	}
    
    /**
	 * Method to be used to add new interested party.
	 * @param roleName
	 * @param userName
	 * @param date
	 */
    public void addInterestedParty(String roleName,String userName,String date)
    {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnAdd, "add interested party button");
    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpIPRole,"visibleText",roleName);
    	Context.global().getSeleniumUtils().enterText(this.txtIPUserName, "Interested parties name", userName);
    	Context.global().getSeleniumUtils().clickOnElement(this.btnNameFind, "Interested party name find button");
    	Context.global().getSeleniumUtils().enterText(this.txtIpStartDate, "Interested party start date", date);
    	Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "Interested party save button");
    }
    
    public void clickSalesInfo(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkSalesInfo, "Sales info link");
    } 
    
    /**
	 * Method to be used to add new sales info.
	 * @param roleName
	 * @param userName
	 * @param date
	 */
    public void addSalesInfo(String roleName,String userName,String date)
    {
    	Context.global().getSeleniumUtils().clickOnElement(this.btnAdd, "add sales info button");
    	Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpIPRole,"visibleText",roleName);
    	Context.global().getSeleniumUtils().enterText(this.txtIPUserName, "Interested parties name", userName);
    	Context.global().getSeleniumUtils().clickOnElement(this.btnNameFind, "Interested party name find button");
    	Context.global().getSeleniumUtils().enterText(this.txtIpStartDate, "Interested party start date", date);
    	Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "Interested party save button");
    }
    
    /**
	 * Method to be used to click time specific link and  click view.
	 * @param date
	 */
    public void clickTimeSpecificEntrylink(String date){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkTimeSpecificEntry, "Sales info link");
	    Context.global().getSeleniumUtils().enterText(this.txtEnquiryDate, "time specific enquiry date", date);
	    Context.global().getSeleniumUtils().clickOnElement(this.btnEnquiryView, "View button");
    } 
    
    public void clickAppraisalHandling(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkAppraisalHandling, "Appraisal handling link");
    } 
    
    public void clickAdd(String text) {
		Context.global().getSeleniumUtils().clickOnElement(this.btnAdd, text+"add button");
	}
    
    public void clickPensionForecast(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkPensionForecast, "Pension forecast link");
    }

    public void clickAggrementBtwCompanyNInsured(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkAggBtwCmpnyNInsured, "aggrement between company and insured link");
    }
    
    public void clickSavingsTab(){
	    Context.global().getSeleniumUtils().clickOnElement(this.tabSavings, "Savings Tab");
    }
    
    public void selectAggrementConcluded(String reqAction){
    	List<WebElement> aggrement= (List<WebElement>) Context.global().getDriver().findElement(By.name("agreementConcluded"));
    	if(reqAction.equals("Yes")){
    		aggrement.get(0).click();
    	}
    	else{
    		aggrement.get(1).click();
    	}
	    
    }
    
    public void selectRightToAcquire(String reqAction){
    	List<WebElement> aggrement= Context.global().getDriver().findElements(By.name("rightToAcquireInformation"));
    	if(reqAction.equals("Yes")){
    		aggrement.get(0).click();
    	}
    	else{
    		aggrement.get(1).click();
    	}
	    
    }
    
    public void selectRightToReallocate(String reqAction){
    	List<WebElement> aggrement= Context.global().getDriver().findElements(By.name("rightToReallocateInvestments"));
    	if(reqAction.equals("Yes")){
    		aggrement.get(0).click();
    	}
    	else{
    		aggrement.get(1).click();
    	}
	    
    }
    
    public void selectHandlingAddTerms(String reqAction){
    	List<WebElement> aggrement= Context.global().getDriver().findElements(By.name("handlingAdditionalTerms"));
    	if(reqAction.equals("Yes")){
    		aggrement.get(1).click();
    	}
    	else{
    		aggrement.get(0).click();
    	}
	    
    }
    
    public void selectPrintingAggrement(String reqAction){
    	List<WebElement> aggrement= Context.global().getDriver().findElements(By.name("printingAgreement"));
    	if(reqAction.equals("Yes")){
    		aggrement.get(0).click();
    	}
    	else{
    		aggrement.get(1).click();
    	}
	    
    }

	public String fetchPensionForecastAmountSavings(){
		String txpath="//h3[contains(text(),'Pension forecast amount Savings')]//following-sibling::table[1]/tbody[2]";
	    return Context.global().getDriver().findElement(By.xpath(txpath+"/tr/td[2]")).getText();
    }
	
	public String fetchPensionForecastAmountPaymentPlanSavings(){
		String txpath="//h3[contains(text(),'Pension forecast amount Savings')]//following-sibling::table[2]/tbody[2]";
	    return Context.global().getDriver().findElement(By.xpath(txpath+"/tr/td[2]")).getText();
    }

	@Override
	public void verifyPageState() {
		// TODO Auto-generated method stub		
	}

}
