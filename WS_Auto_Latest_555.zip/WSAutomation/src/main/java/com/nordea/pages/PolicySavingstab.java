package com.nordea.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;

/**
 * Description: Event View - This Page is for fetching policy information regarding savings and allocation
 *  percent to each investment and methods for savings reallocation,Value change information,
 *  Capital yield information.
 * Navigation to this page is by clicking on LHN >> Policy >>policy
 * 
 * Abbreviations
 * VAEIC = View account events including cancelled
 * 
 * 
 * Functionality Created By  	: Atluri Vinay Kumar
 * Reviewed By                 	: Debabrata Behera
 * Review Date                	: 28/04/2017
 * Modified By 				   	: 
 * Last Modified Date        	: 
 * Reviewed By					: 
 * Review Date					: 
*/

public class PolicySavingstab implements Page {

	@FindBy(name="//th[contains(text(),'Total')]//following-sibling::td[4]")
	private WebElement lblSavings;
	
	@FindBy(linkText="Reallocation of savings")
	private WebElement lnkReallocationsavings;
	
	@FindBy(name="addAllocation")
	private WebElement btnAdd;
	
	@FindBy(name="mandateDate")
	private WebElement txtMandateDate;
	
	@FindBy(name="occuredDate")
	private WebElement txtEventDate;
	
	@FindBy(id="countToValues.yes")
	private WebElement rdbTranferCountedYes;
	
	@FindBy(id="countToValues.no")
	private WebElement rdbTranferCountedNo;
	
	@FindBy(id="changeCostsCharge.yes")
	private WebElement rdbTranferCostYes;
	
	@FindBy(id="changeCostsCharge.no")
	private WebElement rdbTranferCostNo;
	
	@FindBy(id="changeInvesmentPlan.yes")
	private WebElement rdbChgInvPlanYes;
	
	@FindBy(id="changeInvesmentPlan.no")
	private WebElement rdbChgInvPlanNo;
	
	@FindBy(name="allocationTransferType")
	private WebElement drpTransferType;
	
	@FindBy(name="selectTransferType")
	private WebElement btnViewInvestments;
	
	@FindBy(name="addInvestments")
	private WebElement btnAddInvestments;
	
	@FindBy(name="submit")
	private WebElement btnCount; //can be used for button save
	
	@FindBy(xpath="//input[@value='Cancel']")
	private WebElement btnSavingsCancel;
	
	@FindBy(name="accept")
	private WebElement btnAcceptSavings;
	
	@FindBy(name="saveUnfinishedAndPrint")
	private WebElement btnSaveSavings;
	
	@FindBy(xpath="//li[@class='Blue']")
	private WebElement elmWarningMsg;
	
	@FindBy(name="return")
	private WebElement btnReturn;
	
	@FindBy(linkText="Charge plan")
	private WebElement lnkChargePlan;

	@FindBy(linkText="Cover percent information")
	private WebElement lnkCvrPrcntInfo;

	@FindBy(linkText="Capital  and Yield information")
	private WebElement lnkCptlYldInfo;

	@FindBy(linkText="Value change information")
	private WebElement lnkValueChngInfo;
	
	@FindBy(name="startDate")
	private WebElement txtValChngStrDate;

	@FindBy(name="endDate")
	private WebElement txtValChngEndDate;

	@FindBy(name="search")
	private WebElement btnFind;
	
	@FindBy(name="portfolioMgmtTypeCode")
	private WebElement drpServices;
	
	@FindBy(name="profileId")
	private WebElement drpProfiles;
	
	@FindBy(name="showProfile")
	private WebElement btnShow;
	
	@FindBy(name="Premium Guarantee")
	private WebElement lnkPremiumGuarantee;	
	
	@FindBy(name="premiumGuranteeChosen")
	private WebElement chkPremiumGuarantee;	
	
	@FindBy(name="lnkPortfolioSerStatus")
	private WebElement lnkPortfolioSerStatus;
	
	
	public PolicySavingstab(){
		PageFactory.initElements(Context.global().getDriver(), this);
	}
	
	public String fetchTotalPolicySavings()
	{
		return Context.global().getSeleniumUtils().getText(lblSavings);
	}
	
	public void clickAdd(String text) {
		Context.global().getSeleniumUtils().clickOnElement(this.btnAdd, text+"add button");
	}
	
	public void clickReallocationoOfSavings(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkReallocationsavings, "Reallocation of savings link");
    }
	
	public String fetchSavingsStatus(){
		return Context.global().getDriver().findElement(By.xpath("//table[@class='scrollTable']//tbody/tr[1]//td[1]")).getText().trim();
    }
	
	public String fetchSavingsdate(){
		return Context.global().getDriver().findElement(By.xpath("//table[@class='scrollTable']//tbody/tr[1]//td[3]")).getText().trim();
    }
	
	public  void enterMandatedate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtMandateDate, "Mandate date", date);
    }
	
	public  void enterEventdate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtEventDate, "Mandate date", date);
	}
	
	public  void selectTrnfrCounted(){
		 Context.global().getSeleniumUtils().clickOnElement(this.rdbTranferCountedYes, "Radio button Transfer countded Yes");
	}
	
	public  void selectTrnfrNotCounted(){
		 Context.global().getSeleniumUtils().clickOnElement(this.rdbTranferCountedNo, "Radio button Transfer countded No");
	}
	
	public  void selectTrnfrCharged(){
		 Context.global().getSeleniumUtils().clickOnElement(this.rdbTranferCostYes, "Radio button Transfer charged Yes");
	}
	
	public  void selectTrnfrNotCharged(){
		 Context.global().getSeleniumUtils().clickOnElement(this.rdbTranferCostNo, "Radio button Transfer charged No");
	}
	
	public  void selectChngOfInv(){
		 Context.global().getSeleniumUtils().clickOnElement(this.rdbChgInvPlanYes, "Radio button Change of investmentplan Yes");
	}
	
	public  void selectNoChngOfInv(){
		 Context.global().getSeleniumUtils().clickOnElement(this.rdbChgInvPlanNo, "Radio button Change of investmentplan No");
	}
	
	public  void selectTransferPlan(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpTransferType, "visibleText", value);
	}
	
	public  void clickSavingsView(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnViewInvestments, "View investments button");
	}
	
	public  void clickAddInvestment(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAddInvestments, "Add investments button");
	}
	
	public  void clickCount(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnCount, "count button");
	}
	
	public  void clickCancel(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnSavingsCancel, "cancel button");
	}
	
	public  String fetchOldInvValue(){
		 return Context.global().getDriver().findElement(By.xpath("//th[contains(text(),'Total')]//following-sibling::td[2]")).getText().trim();
	}
	
	public  String fetchNewInvValue(){
		 return Context.global().getDriver().findElement(By.xpath("//th[contains(text(),'Total')]//following-sibling::td[4]")).getText().trim();
	}
	
	public  String fetchNewInvCharges(){
		 return Context.global().getDriver().findElement(By.xpath("//th[contains(text(),'Total')]//following-sibling::td[5]")).getText().trim();
	}
	
	public  void clickAcceptSavings(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnAcceptSavings, "accept savings button");
	}
	
	public  void clickSaveSavings(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnSaveSavings, "save savings button");
	}
	
	public  void clickTransferOfFundsPrintout(){
		 Context.global().getDriver().findElement(By.xpath("//a[text()='Transfer of funds']")).click();
	}
	
	public  void clickReturn(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnReturn, "return button");
	}
	
	public  void clickChargePlan(){
		 Context.global().getSeleniumUtils().clickOnElement(this.lnkChargePlan, "charge plan link");
	}
	
	public  void clickCoverPrcntInfo(){
		 Context.global().getSeleniumUtils().clickOnElement(this.lnkCvrPrcntInfo, "cover percent information link");
	}
	
	public  void clickCapitalAndYieldInfo(){
		 Context.global().getSeleniumUtils().clickOnElement(this.lnkCptlYldInfo, "capital and yield information link");
	}
	
	public  void clickValueChngInfo(){
		 Context.global().getSeleniumUtils().clickOnElement(this.lnkValueChngInfo, "value change information link");
	}
	
	public  void enterValueChngStartDate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtValChngStrDate, "value change start date", date);
	}
	
	public  void enterValueChngEndDate(String date){
		 Context.global().getSeleniumUtils().enterText(this.txtValChngEndDate, "value change start date", date);
	}
	
	public  void clickFindButton(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnFind, "find button");
	}
	
	public String fetchValueChngInfo(){
		return Context.global().getDriver().findElement(By.xpath("//th[contains(text(),'Total')]//following-sibling::td[1]")).getText().trim();
	} 
    
    public  void selectservices(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpServices, "visibleText", value);
	}
    
    public  void selectProfiles(String value){
		 Context.global().getSeleniumUtils().selectValueFromDropDown(this.drpProfiles, "visibleText", value);
	}
    
    public  void clickShowButton(){
		 Context.global().getSeleniumUtils().clickOnElement(this.btnShow, "show profiles button");
	}
    
    public void clickPremiumGuarantee(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkPremiumGuarantee, "premium guarantee link");
    }
    
    public  void clickPremiumGuaranteeChkbox(){
		 Context.global().getSeleniumUtils().clickOnElement(this.chkPremiumGuarantee, "premium guarantee checkbox");
	}
    
    public void clickPortfolioServiceStatus(){
	    Context.global().getSeleniumUtils().clickOnElement(this.lnkPortfolioSerStatus, "Reallocation of savings link");
    }
    
	@Override
	public void verifyPageState() {
		// TODO Auto-generated method stub
		
	}

}
