package com.nordea.pages;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;


/** 
 * Description: This page contains web elements and methods for complete flow of offer creation for different product
 * Navigating to this page by clicking on 'offer' tabs in the LHN 
 * 
 * 
 * Naming convention guidelines
 * PageName+WebElementName  
 * DB=Death Benefit
 * PD=Permanent Disability
 * PAH=Permanent Accidental Handicap
 * CI=Critical Illness 
 * Functionality			 	: Will be called as per requirement.
 * Functionality Created By  	: Snehal Bahulekar
 * Reviewed By                 	: Mithen Kadam
 * Review Date                	: 27/12/2016
 * Modified By 				   	: Aruna Kumar Behera
 * Last Modified Date        	: 20/03/2017
 * Reviewed By					: Debabrata Behera
 * Review Date					: 20/03/2017
*/

public class OfferResultCalcAndPrinting extends LHN implements Page  {
		
	    /**
	     * Application Page : Result of calculation	
	     */

        @FindBy(xpath = "//input[@value='Save']")
        private WebElement btnSave;
      
	    /**
	     * Application Page : Printing Tab
	     */
	     
	   	    
	    @FindBy(xpath = "//td[contains(text(),'Application')]/../td/input")
	    private WebElement chkPrintApplication;
	    
	    @FindBy(xpath = "//td[contains(text(),'Offer calculation')]/../td/input")
	    private WebElement chkPrintOffer;
	    
	    @FindBy(xpath = "//td[contains(text(),'Health Declaration Form')]/../td/input")
	    private WebElement chkPrintHDForm;
	    
	    @FindBy(xpath = "//td[contains(text(),'Cover of offer calc')]/../td/input")
	    private WebElement coverOfCalc;
	    
	    @FindBy(xpath = "//input[contains(@name,'indexedPrintChosen')]")
	    private List<WebElement> elePrintCheckboxList ;
	    
	    @FindBy(xpath = "//input[@name='Print']")
	    private WebElement btnPrint;
	    
	    @FindBy(xpath = "//input[@value='Return']")
	    private WebElement btnReturn;
	    
	    @FindBy(xpath = "//input[@value='OK']")
	    private WebElement btnOK;
	    
	    @FindBy(xpath = "//input[@name='continue']")
	    private WebElement btnContinue;

	    @FindBy(xpath = "//table[@class='scrollTable']/thead/tr/th")
	    private List<WebElement> eleAnnualPremiumCoverList;
	    
	    @FindBy(xpath = "//a[text()='Annual development of cover premiums']")
	    private WebElement lnkAnnualCoverPremiums;
	    	    
	    public OfferResultCalcAndPrinting() {
	        PageFactory.initElements(Context.global().getDriver(), this); 
	    }
	    
	   
		/**
		 * Methods for Result of Calculation
		 */
	    
	    public void clickSave(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnSave, "ResultCalcSave"); 	
	    }
	    
	    /**
	     * Methods for Printing tab
	     */ 
	    
	    public void checkPrintApplication(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrintApplication, "PrintApplication checkbox");
	    }
	    public void checkPrintOffer(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrintOffer, "PrintOffer checkbox");
    	}
	    public void checkPrintHDform(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.chkPrintHDForm, "PrintHDform");
	    }	
	    
	    public void checkPrintCoverofCalc(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.coverOfCalc, "Print Cover of Calculation checkbox");
	    }
	    
	    public void checkAllPrintCheckbox(){
	    	for(int i=0;i<this.elePrintCheckboxList.size();i++){
	    	this.elePrintCheckboxList.get(i).click();
	    	}
	    }
	    
	    public void clickPrint(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnPrint, "Print");
	    }
	    public void clickReturn(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnReturn, "Return");
	    }
	    
	    public void clickOK() {
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnOK, "OK Button");
	    }
	    
	    public void clickContinue(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.btnContinue, "Continue");
	    }
	    
	    public void clickAnnualCoverPremium(){
	    	Context.global().getSeleniumUtils().clickOnElement(this.lnkAnnualCoverPremiums,"Annual development of cover premiums link");
	    	if(Context.global().getSeleniumUtils().verifyElementPresent(this.lnkAnnualCoverPremiums,"Annual development of cover premiums link")){
	        	Context.global().getSeleniumUtils().clickOnElement(this.lnkAnnualCoverPremiums,"Annual development of cover premiums link");
	        }
	    }
	    
	    public String fetchAnnualCoverPremium(Integer row,Integer column){
	    	return Context.global().getDriver().findElement(By.xpath("//h2[contains(text(),'Annual development of cover premiums')]//following-sibling::div[1]/table/tbody/tr["+row+"]/td["+column+"]")).getText().trim();
	    }
	    
		@Override
		public void verifyPageState() {
			//
		}
}
