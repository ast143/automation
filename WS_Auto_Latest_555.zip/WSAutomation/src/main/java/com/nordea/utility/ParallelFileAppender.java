package com.nordea.utility;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.spi.LoggingEvent;

import com.nordea.framework.Context;

/**
 * Class being used for parallel logging
 * @author Nitesh Khanna
 *
 */
public class ParallelFileAppender extends AppenderSkeleton {
	private ConcurrentHashMap<String, BufferedWriter> tid2file = new ConcurrentHashMap<String, BufferedWriter>();
	private static Set<String> setSession = new HashSet<String>();
	
	protected String outputDir;
	protected String outputFile;
	private final String ext = ".txt";

	public ParallelFileAppender(String strDir) throws InterruptedException {
		String outdir = strDir;
		if (!outdir.endsWith("/"))
			outdir += "/";
		outputDir = outdir;
	}

	@Override
	protected void append(LoggingEvent event) {
		if (outputDir == null) {
			return;
		}
		try {
			String sid = Context.global().getSeleniumUtils().timestemp();
			BufferedWriter fw = null;
			if (!setSession.contains(sid) && tid2file.size() == 0 && !tid2file.containsKey(sid)) {
				System.out.println("Log File created : logging_" + sid);
				outputDir = Context.global().getSessionFolderPath() + "/";
				fw = new BufferedWriter(new FileWriter(getFileNameFromSessionId(sid.toString())));
				tid2file.put(sid, fw);
			}
			PatternLayout pttrnLyt = new PatternLayout();
			pttrnLyt.setConversionPattern("%d{[MM-dd-yyyy HH:mm:ss]} %-5p %c{1}:%L - %m%n");
			pttrnLyt.format(event);
			if (tid2file.containsKey(sid)) {
				tid2file.get(sid).write(pttrnLyt.format(event));
				tid2file.get(sid).flush();
			}

		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	private String getFileNameFromSessionId(String sid) {
		return String.format("%slogging_%s%s", outputDir, sid, ext);
	}

	@Override
	public void close() {
	}

	@Override
	public boolean requiresLayout() {
		return false;
	}

}