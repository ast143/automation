 package com.nordea.utility;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.Test;

import com.nordea.framework.Context;
import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.NetworkMode;
import com.relevantcodes.extentreports.source.ExtentFlag;

public class Report {
	
	public static ExtentReports report;
	public static ThreadLocal<ExtentTest> LOGGER = new ThreadLocal<ExtentTest>();
	public static String testcasename;
	public static String systemDate;
	

	/**
	 * Method to initiate Report 
	 */
	public static void initiateReport(Method testcase) {
		testcasename = testcase.getName().replace("_", "_");
		boolean replacereport = !(Boolean.parseBoolean(LoadPropertiesUtil.configProps.getProperty("Merge_With_Existing_Report")));
		if (report == null) {
			report = new ExtentReports(LoadPropertiesUtil.configProps.getProperty("Execution_Report_Path")+"//"+LoadPropertiesUtil.configProps.getProperty("Execution_Report_Name")+".html",replacereport,DisplayOrder.OLDEST_FIRST,NetworkMode.OFFLINE);
		}
		LOGGER.set(report.startTest(testcasename));
		report.config().documentTitle("Web Service Automation");
		report.config().reportHeadline("<b style = \"color:orange;\">Automation</b>");
		report.config().reportName("<b style = \"color:orange;\">Web Service</b>");		

		Test t = testcase.getAnnotation(Test.class);
		categorizeTest(t);
		
	}
	
	/**
	 * Method to add categories to test cases in report 
	 */
	public static synchronized void categorizeTest(Test t) {
		for(int categorynum=0; categorynum < t.groups().length;categorynum++ ){
		LOGGER.get().assignCategory(t.groups()[categorynum]);
	    }
	}
	
	/**
	 * Method to log steps as Pass, Fail or Info without capturing screenshot in report 
	 */
	public static synchronized void updateReport(String status, String stepName) {
		if (status.equalsIgnoreCase("PASS")) {
			LOGGER.get().log(LogStatus.PASS, stepName);
		} else if (status.equalsIgnoreCase("FAIL")) {
			LOGGER.get().log(LogStatus.FAIL, "<b style = \"color:red;\"><i>FAIL : </i></b>"+stepName);
		} else if (status.equalsIgnoreCase("INFO")) {
			LOGGER.get().log(LogStatus.INFO,stepName);
		}
	}

	/**
	 * Method to log steps as Pass, Fail or Info and capture screenshot in report 
	 */
	public static synchronized void updateReport(String status, String stepName,String imageName) throws IOException {
		systemDate = Context.global().getSeleniumUtils().getCurrentDateTimeStamp();
		String imageDetails = testcasename+"//"+imageName+"_"+systemDate;
		if (status.equalsIgnoreCase("INFO")) {
			//String screenshotpath = GenericUtils.captureScreenshot(imageDetails);
			//String image = logger.get().addScreenCapture(screenshotpath);
			LOGGER.get().log(LogStatus.INFO,stepName);
			//logger.get().log(LogStatus.INFO, image);
		}
		if (status.equalsIgnoreCase("PASS")) {
			//String screenshotpath = GenericUtils.captureScreenshot(imageDetails);
			//String image = logger.get().addScreenCapture(screenshotpath);
			LOGGER.get().log(LogStatus.PASS, stepName);
			//logger.get().log(LogStatus.INFO,image);
		} 
		else if (status.equalsIgnoreCase("FAIL")) {
			//String screenshotpath = GenericUtils.captureScreenshot(imageDetails);
			//String image = logger.get().addScreenCapture(screenshotpath);
			LOGGER.get().log(LogStatus.FAIL,"<b style = \"color:red;\"><i>FAIL : </i></b>"+ stepName);
			//logger.get().log(LogStatus.INFO,image);
		}
	}
	
	/**
	 * Method to log PDF validation steps in Report
	 */
	public static synchronized void updatePDFReport(String status, String validationInfo,
			String expectedTxt, String actualTxt) throws IOException {
		LOGGER.get().log(LogStatus.INFO, "Expected " + validationInfo + " : "
				+ expectedTxt);
		LOGGER.get().log(LogStatus.INFO, "Actual " + validationInfo + " : "
				+ actualTxt);

		if (status.equalsIgnoreCase("PASS")) {
			LOGGER.get().log(LogStatus.PASS, "Assertion PASS for " + validationInfo);

		} else if (status.equalsIgnoreCase("FAIL")) {
			LOGGER.get().log(LogStatus.FAIL, "Assertion FAIL for " + validationInfo);
		}
	}

	/**
	 * Method to log unhandled exception in report 
	 */
	public static synchronized void updateReport(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.SUCCESS) {
			report.endTest(LOGGER.get());
			report.flush();
		}
		if (result.getStatus() == ITestResult.FAILURE) {
			String message = "";
			if(result.getThrowable() != null) {
				message = result.getThrowable().getMessage();
			}
			updateReport("FAIL", message, testcasename + "_Failed Screen");
			report.endTest(LOGGER.get());
			report.flush();
		}
	}

}
