package com.nordea.utility;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestNGMethod;

import com.nordea.framework.Context;

/**
 * This class contains all the functions related to selenium which are used
 * across the application
 * 
 * @author Nitesh Khanna
 * Updated By: Debabrata Behera
 * 
 */
public class SeleniumUtils {
	final static Logger logger = Logger.getLogger(SeleniumUtils.class);

	/**
	 * Method to be used for navigating to Application URL
	 */
	public void navigateToApplicationUrl(String env) {
		
		if (env.equalsIgnoreCase("IT")) {
			Context.global().getDriver().navigate()
					.to(LoadPropertiesUtil.configProps.getProperty("ITUrl"));
			logger.info("Navigated to Application URL: '"
					+ LoadPropertiesUtil.configProps.getProperty("ITUrl") + "'");
			Report.updateReport("INFO", "Test Environment URL: " + LoadPropertiesUtil.configProps.getProperty("ITUrl"));
			
		} else {
			Context.global().getDriver().navigate()
					.to(LoadPropertiesUtil.configProps.getProperty("SITUrl"));
			logger.info("Navigated to Application URL: '"
					+ LoadPropertiesUtil.configProps.getProperty("SITUrl")
					+ "'");
			Report.updateReport("INFO", "Test Environment URL: " + LoadPropertiesUtil.configProps.getProperty("SITUrl"));
			
		}
	}

	/**
	 * Method to be used for maximizing browser window
	 */
	public void maximizeWindow() {
		Context.global().getDriver().manage().window().maximize();
		logger.info("Browser window got maximized successfully");
	}

	/**
	 * Method to be used for refreshing a browser
	 */
	public void refreshBrowser() {
		Context.global().getDriver().navigate().refresh();
		logger.info("Refreshing browser");
	}

	/**
	 * Method to be used for clicking on an element
	 * @param element
	 * @param elementName
	 * @return 
	 */
	public void clickOnElement(WebElement element, String elementName) {
		element.click();
		logger.info("Clicked on '" + elementName + "' successfully");
	}
	
	public boolean verifyElementEnable(WebElement element, String elementName) {
		if(element.isEnabled()){
			logger.info(elementName + "' is enabled");
			return true;
		}
		else{
			logger.info(elementName + "' is disabled");
			return false;
		}
	}
		
	/**
	 * Method to be used for entering a text
	 * @param element
	 * @param elementName
	 * @param strText
	 */
	public void enterText(WebElement element, String elementName, String strText) {
		element.sendKeys(strText);
		logger.info("Entered text '" + strText + "' successfully to "
				+ elementName);
	}
	
	/**
	 * Method to be used for closing current window
	 */
	public void closecurrentWindow() {
		Context.global().getDriver().close();
		logger.info("================================================================================");
		logger.info("Window Closed");
		logger.info("================================================================================");
	}
	
	/**
	 * Method to be used for closing application
	 */
	public void closeApplication() {
		logger.info("================================================================================");
		logger.info("Application Closed");
		logger.info("================================================================================");
		Context.global().getDriver().quit();
		}
	
	/**
	 * Method to be used for uploading file
	 * @param element
	 * @param elementName
	 * @param filePath
	 */
	public void uploadFile(WebElement element, String elementName, String filePath) {
		element.sendKeys(filePath);
		logger.info("Uploaded file to '"+elementName+"'");
	}
	
	/**
	 * Method to be used for comparing two Strings
	 * @param String
	 * @param String
	 * @returntype Boolean
	 */
	public boolean assertText(String expectedText, String actualText) {
		try{
			Assert.assertEquals(expectedText,actualText);
			logger.info("Assertion PASSED - Expected: "+expectedText+" Actual: "+actualText);
			return true;	
			}catch(AssertionError e){
			logger.info("Assertion FAILED - Expected: "+expectedText+" Actual: "+actualText);
			return false;
			}
	}

	/**
	 * Method to be used for getting a text
	 * @param element
	 * @return
	 */
	public String getText(WebElement element) {
		String strText = element.getText().trim();
		logger.info("Fetched text '"+strText+"'");
		return strText;
	}
	
	/**
	 * Method to be used for getting a text
	 * @param element
	 * @return
	 */
	public String getAttribute(WebElement element,String attributeName) {
		String strText = element.getAttribute(attributeName).trim();
		logger.info("Fetched text '"+strText+"'");
		return strText;
	}
	
	
	/**
	 * Method to be used for clearing a text
	 * @param element
	 * @param elementName
	 */
	public void clearText(WebElement element, String elementName) {
		element.clear();
		logger.info("Cleared text in '" + elementName + "' successfully");
	}

	/**
	 * Method to be used for pressing an 'ENTER'
	 * @param element
	 */
	public void pressEnter(WebElement element) {
		element.sendKeys(Keys.ENTER);
		logger.info("Pressed 'ENTER' successfully");
	}

	/**
	 * Method to be used for highlighting an element
	 * @param element
	 */
	public void elementHighlight(WebElement element) {
		for (int i = 0; i < 5; i++) {
			JavascriptExecutor js = (JavascriptExecutor) Context.global()
					.getDriver();
			js.executeScript(
					"arguments[0].setAttribute('style', arguments[1]);",
					element, "border: 3px solid green;");
			js.executeScript(
					"arguments[0].setAttribute('style', arguments[1]);",
					element, "");
		}
	}

	/**
	 * Method to be used for selecting a value from drop down
	 * @param dropDown
	 * @param operation
	 * @param value
	 * @return
	 */
	public boolean selectValueFromDropDown(WebElement dropDown,
			String operation, String value) {
		try {
			Select selectDropDown = new Select(dropDown);
			if (operation.equalsIgnoreCase("visibleText")) {
				selectDropDown.selectByVisibleText(value);
				logger.info("Selected value '" + value + "' from dropdown");
				return true;
			} else if (operation.equalsIgnoreCase("value")) {
				selectDropDown.selectByValue(value);
				logger.info("Selected value '" + value + "' from dropdown");
				return true;
			} else if (operation.equalsIgnoreCase("index")) {
				selectDropDown.selectByIndex(Integer.parseInt(value));
				logger.info("Selected value '" + value + "' from dropdown");
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * Method to be used for dragging and dropping an element
	 * @param source
	 * @param target
	 */
	public void dragAndDropElement(WebElement source, WebElement target) {
		try {
			// Drag 1st control to layout
			String js_filepath = System.getProperty("user.dir")
					+ "\\src\\main\\java\\com\\cisco\\cstg\\framework\\srm\\functions\\helper\\drag_and_drop_helper.js";

			String java_script = "";
			String text;

			BufferedReader input = new BufferedReader(new FileReader(
					js_filepath));
			StringBuffer buffer = new StringBuffer();

			while ((text = input.readLine()) != null)
				buffer.append(text + "\n");
			java_script = buffer.toString();

			input.close();

			String load_jquery = "var jqueryUrl = \"http://code.jquery.com/jquery-2.1.1.min.js\";\n"
					+ "var scriptElt = document.createElement('script');\n"
					+ "scriptElt.type = 'text/javascript';\n"
					+ "scriptElt.src = jqueryUrl;\n"
					+ "scriptElt.src = jqueryUrl;\n"
					+ "document.getElementsByTagName('head')[0].appendChild(scriptElt);";

			JavascriptExecutor js = (JavascriptExecutor) Context.global()
					.getDriver();
			Context.global().getDriver().manage().timeouts()
					.setScriptTimeout(10, TimeUnit.SECONDS);

			String drag_drop_script = "jQuery(arguments[0]).simulate('drag', { dropTarget: arguments[1] });";
			js.executeScript(load_jquery);
			js.executeScript(java_script);
			js.executeScript(drag_drop_script, source, target);

		} catch (Exception e) {

			logger.info("Error :" + e.toString());
		}
	}

	/**
	 * Method to be used for dragging and dropping an element
	 * @param dragFrom
	 * @param dragTo
	 * @param xOffset
	 * @param yOffset
	 * @throws Exception
	 */
	public void dragAndDropElementUsingRobot(WebElement dragFrom,
			WebElement dragTo, int xOffset, int yOffset) throws Exception {
		// Setup robot
		Robot robot = new Robot();
		robot.setAutoDelay(500);

		// Get size of elements
		Dimension fromSize = dragFrom.getSize();
		Dimension toSize = dragTo.getSize();

		// Get centre distance
		int xCentreFrom = fromSize.width / 2;
		int yCentreFrom = fromSize.height / 2;
		int xCentreTo = toSize.width / 2;
		int yCentreTo = toSize.height / 2;

		Point toLocation = dragTo.getLocation();
		Point fromLocation = dragFrom.getLocation();

		// Make Mouse coordinate centre of element
		toLocation.x += xOffset + xCentreTo;
		toLocation.y += yOffset + yCentreTo;
		fromLocation.x += xOffset + xCentreFrom;
		fromLocation.y += yOffset + yCentreFrom;

		// Move mouse to drag from location
		robot.mouseMove(fromLocation.x, fromLocation.y);
		// Click and drag
		robot.mousePress(InputEvent.BUTTON1_MASK);
		robot.mouseMove(((toLocation.x - fromLocation.x) / 2) + fromLocation.x,
				((toLocation.y - fromLocation.y) / 2) + fromLocation.y);

		// Move to final position
		robot.mouseMove(toLocation.x, toLocation.y);
		// Drop
		robot.mouseRelease(InputEvent.BUTTON1_MASK);
	}

	/**
	 * Method to be used for getting Parent Window Handle
	 * @return
	 */
	public String getParentWindowHandle() {
		String parentWindowHandle = Context.global().getDriver()
				.getWindowHandle();
		logger.info("Able to get parent window handle");
		return parentWindowHandle;
	}

	/**
	 * Method to be used for getting all open window handles 
	 * @return
	 */
	public Set<String> getWindowHandles() {
		Set<String> windowHandles = Context.global().getDriver()
				.getWindowHandles();
		logger.info("Able to get all window handles");
		return windowHandles;
	}

	/**
	 * Method to be used for switching to a window
	 * @param title
	 */
	public void switchToWindow() {
		Set<String> windowHandles = getWindowHandles();
		System.out.println("window handle size = " + windowHandles.size());
		for(String handle : windowHandles) {
			Context.global().getDriver().switchTo().window(handle);
		}
	} 

	/**
	 * Method to be used for switching to a frame
	 * @param element
	 */
	public void switchToFrame(WebElement element) {
		Context.global().getDriver().switchTo().frame(element);
		logger.info("Able to switch to frame");
	}
	
	/**
	 * Method to be used for getting current Date and Time Stamp
	 * @return
	 */
	public String getCurrentDateTimeStamp() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy_HHmmss");
		return dateFormat.format(new Date());
	}

	// ------------------------------------------------------[STARTS] Wait
	// Related Functions
	// [STARTS]---------------------------------------------------------------
	/**
	 * Method to be used when page is getting loaded
	 * @param timeOutInSeconds
	 * @throws InterruptedException 
	 */
	public void waitForPageToLoad(int timeOutInSeconds) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) Context.global()
				.getDriver();
		String command = "return document.readyState";
		try {
			// Check the readyState before doing any waits
			if (js.executeScript(command).toString().equals("complete")
					|| js.executeScript(command).toString().equals("interactive")) {
				return;
			}
		} catch(WebDriverException e) {
			e.printStackTrace();
		}

		for (int counter = 0; counter < timeOutInSeconds; counter++) {
			try {
				Thread.sleep(1000);
				if (js.executeScript(command).toString().equals("complete")
						|| js.executeScript(command).toString()
								.equals("interactive")) {
					break;
				}
			} catch (WebDriverException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Functionality: Pass timestamp Header in web service request Input
	 * Parameter : Null Type: Null
	 */
	public String timestemp() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-dd-MM.HH.mm.ss.ms");
		String dtfrmt = dateFormat.format(new Date());
		return dtfrmt;
	}

	/**
	 * Method to be used for waiting, until an element gets visible
	 * @param element
	 * @param timeOutInSeconds
	 * @throws Exception
	 */
	public void waitForSpecificTimeTillElementLoad(WebElement element,
			long timeOutInSeconds) throws Exception {
		try {
			// Wait till element appear on the page
			WebDriverWait wait = new WebDriverWait(
					Context.global().getDriver(), timeOutInSeconds); // presenceOfElementLocated
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (UnhandledAlertException alert) {
			alert.printStackTrace();
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		} catch (NoSuchFrameException e) {
			e.printStackTrace();
		} catch (Error e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to be used for waiting, until an element becomes clickable
	 * @param element
	 * @param timeOutInSeconds
	 */
	public void waitForSpecificTimeTillElementIsClickable(WebElement element,
			long timeOutInSeconds) {
		try {
			// Wait till element appear on the page
			WebDriverWait wait = new WebDriverWait(
					Context.global().getDriver(), timeOutInSeconds); // presenceOfElementLocated
			wait.until(ExpectedConditions.elementToBeClickable(element));
		} catch (UnhandledAlertException alert) {
			alert.printStackTrace();
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		} catch (NoSuchFrameException e) {
			e.printStackTrace();
		} catch (Error e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to be used for waiting, until an element get visible
	 * @param element
	 * @param timeOutInSeconds
	 */
	public void waitForSpecificTimeTillElementIsDisplayed(WebElement element,
			long timeOutInSeconds) {
		try {
			// Wait till element appear on the page
			WebDriverWait wait = new WebDriverWait(
					Context.global().getDriver(), timeOutInSeconds); // presenceOfElementLocated
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (UnhandledAlertException alert) {
			alert.printStackTrace();
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		} catch (NoSuchFrameException e) {
			e.printStackTrace();
		} catch (Error e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to be used for waiting, until an alert gets visible
	 * @param timeOutInSeconds
	 */
	public void waitTillAlertIsPresent(long timeOutInSeconds) {
		try {
			// Wait till element appear on the page
			WebDriverWait wait = new WebDriverWait(
					Context.global().getDriver(), timeOutInSeconds); // presenceOfElementLocated
			wait.until(ExpectedConditions.alertIsPresent());
		} catch (UnhandledAlertException alert) {
			alert.printStackTrace();
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		} catch (NoSuchFrameException e) {
			e.printStackTrace();
		} catch (Error e) {
			e.printStackTrace();
		}
	}

	// --------------------------------------------------------[ENDS] Waiting
	// Related Keywords
	// [ENDS]--------------------------------------------------------------------

	// --------------------------------------------------------[STARTS] Alert
	// Related Keywords
	// [STARTS]------------------------------------------------------------------
	/**
	 * Method to be used for switching to an alert window
	 * @return
	 * @throws Exception
	 */
	public Alert switchToAlert() throws Exception {
		Context.global().getSeleniumUtils().waitTillAlertIsPresent(5);
		Alert alert = Context.global().getDriver().switchTo().alert();
		if (alert == null) {
			logger.info("Alert not found");
		} else {
			logger.info("Successfully switched to an alert ");
		}
		return alert;
	}

	/**
	 * Method to be used for verifying and accepting an alert
	 * @param alertMsg
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAndAcceptAnAlert(String alertMsg) throws Exception {
		Context.global().getSeleniumUtils().waitTillAlertIsPresent(5);
		Alert alert = switchToAlert();
		if (alertMsg.equalsIgnoreCase(getAlertText(alert))) {
			alert.accept();
			logger.info("Alert accepted successfully");
			return true;
		} else {
			alert.accept();
			logger.info("Expected alert message '" + alertMsg + "'");
		}
		return false;
	}

	/**
	 * Method to be used for accepting an alert
	 * @param alert
	 * @throws Exception
	 */
	public void acceptAnAlert(Alert alert) throws Exception {
		getAlertText(alert);
		alert.accept();
		logger.info("Alert accepted successfully");
	}

	/**
	 * Method to be used for getting an alert text
	 * @param alert
	 * @return
	 */
	public String getAlertText(Alert alert) {
		String alertMsg = alert.getText();
		logger.info("Alert message: '" + alertMsg + "' is displayed");
		return alertMsg;
	}

	/**
	 * Method to be used for verfying and dismissing an alert
	 * @param alertMsg
	 * @throws Exception
	 */
	public void verifyAndDismissAnAlert(String alertMsg) throws Exception {
		Context.global().getSeleniumUtils().waitTillAlertIsPresent(5);
		Alert alert = switchToAlert();
		logger.info(alert.getText());
		if (alertMsg.equalsIgnoreCase(getAlertText(alert))) {
			alert.dismiss();
			logger.info("Alert cancelled successfully");
		}
	}

	/**
	 * Method to be used for dismissing an alert
	 * @param alert
	 * @throws Exception
	 */
	public void dismissAnAlert(Alert alert) throws Exception {
		alert.getText();
		alert.accept();
		logger.info("Alert cancelled successfully");
	}

	// -------------------------------------------------------[ENDS] Alert
	// Related Keywords
	// [ENDS]----------------------------------------------------------------------

	// -------------------------------------------------------[STARTS] Snapshot
	// Related Keywords
	// [STARTS]----------------------------------------------------------------
	/**
	 * Method for getting a screen shot of bowser screen
	 * @throws IOException
	 */
	public void getSnapshotAs() throws IOException {
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd HH.mm.ss");
		String strFilePath = Context.global().getSessionFolderPath()
				+ "\\test-output\\screenshot" + "\\screenshot-"
				+ dateFormat.format(new Date()) + ".png";
		File scrFile = ((TakesScreenshot) Context.global().getDriver())
				.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(strFilePath));
	}

	/**
	 * Method for getting a screen shot of browser screen 
	 * from a remote machine
	 * @param remoteWebdriver
	 * @throws IOException
	 */
	public void getSnapshotFromRemoteAs(WebDriver remoteWebdriver)
			throws IOException {
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd HH.mm.ss");
		String strFilePath = Context.global().getSessionFolderPath()
				+ "\\test-output\\screenshot" + "\\screenshot-"
				+ dateFormat.format(new Date()) + ".png";
		WebDriver augmentedDriver = new Augmenter().augment(remoteWebdriver);
		File screenshot = ((TakesScreenshot) augmentedDriver)
				.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(strFilePath));
	}

	/**
	 * Method to be used for getting a screen shot for report
	 * @param testMethod
	 * @return
	 * @throws Exception
	 */
	public String takeScreenShotForReport(ITestNGMethod testMethod)
			throws Exception {
		File screenshot = ((TakesScreenshot) Context.global().getDriver())
				.getScreenshotAs(OutputType.FILE);
		String path = getPath(testMethod.getMethodName());
		FileUtils.copyFile(screenshot, new File(path));
		return path;
	}

	/**
	 * Method used for getting path of folder at which screen shots will get saved
	 * @param methodName
	 * @return
	 * @throws IOException
	 */
	private String getPath(String methodName) throws IOException {
		File directory = new File(".");
		String newFileNamePath = directory.getCanonicalPath()
				+ "\\test-output\\screenshot\\" + methodName + "_"
				+ Context.global().getDriver().getTitle() + ".png";
		return newFileNamePath;
	}
	
	/**
	 * THis method generates a random string
	 * width of string is the parameter to be passed to this method
	 * @param wordLength
	 * @return
	 */
	public  static String generateRandomWord(int wordLength) {
	    Random r = new Random(); // Intialize a Random Number Generator with SysTime as the seed
	    StringBuilder sb = new StringBuilder(wordLength);
	    for(int i = 0; i < wordLength; i++) { // For each letter in the word
	        char tmp = (char) ('a' + r.nextInt('z' - 'a')); // Generate a letter between a and z
	        sb.append(tmp); // Add it to the String
	    }
	    return sb.toString();
	}
	
	/**
	 * Method to return title of a web-element
	 * @param webElement
	 * @return
	 */
	public String getTitleForWebElement(WebElement webElement){
		return webElement.getAttribute("title");
	}

	/**
	 * Method to return True is Element is present or else will return false
	 * @param webElement, Element Name
	 * @return
	 */
	public boolean verifyElementPresent(WebElement webElement, String elementName) {
		turnOffImplicitWait();
		try{
			if(webElement.isDisplayed()&& webElement.isEnabled()){
				logger.info(elementName+ " is displayed");
				turnOnImplicitWait();
				return true;
			}
			else {
				logger.info(elementName+ " is not displayed");
				turnOnImplicitWait();
				return false;
			}
		}
		catch(Exception e){
			logger.info(elementName+ " is not displayed");
			turnOnImplicitWait();
		    return false;
		}
	}
	
	public void setAttributeValue(String javaScript, WebElement element)
	{
		JavascriptExecutor js = (JavascriptExecutor) Context.global().getDriver();
		js.executeScript(javaScript, element);
	}

	/**
	 * Method to return selected option of a dropdown
	 * @param webElement, Element Name
	 * @return String
	 */
	public String getSelectedOptionfromDropdown(WebElement webElement,String elementName) {
		Select s = new Select(webElement);
		turnOffImplicitWait();
		try{
			logger.info(elementName+" has option selected as :"+s.getFirstSelectedOption().getText());
			turnOnImplicitWait();
			return s.getFirstSelectedOption().getText();
		}catch(Exception e){
			logger.info(elementName + " has no option Selected");
			turnOnImplicitWait();
			return null;
		}
				
	} 
	
	/**
	 * Method to return all options of a dropdown
	 * @param webElement, Element Name
	 * @return List<String>
	 */
	public List<String> getAllOptionsfromDropdown(WebElement webElement,String elementName) {
		Select s = new Select(webElement);
		List<WebElement> dropdownlist = s.getOptions();
		List<String> dropdownvalues= new ArrayList<String>();
		for(int i=0;i<dropdownlist.size();i++){
			dropdownvalues.add(dropdownlist.get(i).getText());
		}
		logger.info(elementName+" has options : "+dropdownvalues);
		return dropdownvalues;	
	} 

	/**
	 * Method to reset implicitwait timing to 2 second
	 */
	public void turnOffImplicitWait(){
		Context.global().getDriver().manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		logger.info("Implicitly Wait turned off");
	}
	
	/**
	 * Method to reset implicitwait timing to 15 second
	 */
	public void turnOnImplicitWait(){
		Context.global().getDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		logger.info("Implicitly Wait turned on");
	}
	
	/**
	 * Method to double click on element using Action Class
	 */
	public void doubleclickonElement(WebElement element, String elementName){
		Actions action=new Actions(Context.global().getDriver());
	    action.moveToElement(element);
	    action.doubleClick().perform();
	    logger.info("Double Clicked on: "+elementName);
	}
	
	/**

	 * Method to be used for getting a text from attribute
	 * @param element
	 * @return
	 */
	public String getAttributeValue(WebElement element, String attributeName) {
		String strText = element.getAttribute(attributeName).trim();
		logger.info("Fetched text '"+strText+"'");
		return strText;
	}

    /**
     * 
	 *  Method to check check box is selected or not
	 * returns true,if check box is selected
	 * returns false,if check box is not selected
	 */
	
	public boolean verifycheckboxchecked(WebElement element){		
		return element.isSelected();		
	}
	
	
}
