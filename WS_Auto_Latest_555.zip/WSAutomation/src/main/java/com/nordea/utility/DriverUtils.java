package com.nordea.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import WSAutomation.utility.wsUtils;

import com.nordea.framework.Context;
import com.nordea.workflow.HeaderValidation;

/**
 * Class being used for instantiating a Browser
 * 
 * @author Nitesh Khanna
 *
 */
public class DriverUtils {
	final static Logger LOGGER = Logger.getLogger(DriverUtils.class);
	private DriverUtils driverUtil;
	private HeaderValidation hdrValidation;
	private static final int PRETTY_PRINT_INDENT_FACTOR = 4;

	/**
	 * Method being used for get a DriverUtils instance
	 * 
	 * @return
	 */
	public DriverUtils getDriverUtilsInstance() {
		if (driverUtil == null) {
			driverUtil = new DriverUtils();
		}
		return driverUtil;
	}

	/**
	 * Method being used for instantiating a driver
	 * 
	 * @param mtd
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void initiateDriver(Method mtd) throws FileNotFoundException,
			IOException, InterruptedException {
		String strBrowser = LoadPropertiesUtil.configProps
				.getProperty("BrowserName");
		ThreadLocal<ParallelFileAppender> prApp = new ThreadLocal<ParallelFileAppender>();

		if (strBrowser.equalsIgnoreCase("Chrome")) {
			System.setProperty(
					"webdriver.chrome.driver",
					System.getProperty("user.dir")
							+ "\\src\\main\\resources\\drivers\\chromedriver.exe");
			RemoteWebDriver webDriver = new ChromeDriver();
			Context.global().setDriver(webDriver);
			File session = new File(System.getProperty("user.dir") + "\\logs\\"
					+ LoggingUtils.executionFolder.getName() + "\\"
					+ mtd.getName() + "_" + webDriver.getSessionId() + "\\logs");
			session.mkdirs();
			Context.global().setSessionFolderPath(session.getPath());
			prApp.set(new ParallelFileAppender(session.getPath()));
			Logger.getRootLogger().addAppender(prApp.get());
			LOGGER.info("Chrome browser instantiated successfully");

		} else if (strBrowser.equalsIgnoreCase("ie")) {
			System.setProperty(
					"webdriver.ie.driver",
					System.getProperty("user.dir")
							+ "\\src\\main\\resources\\drivers\\IEDriverServer.exe");
			DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
			caps.setCapability(
					InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
					true);
			caps.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			RemoteWebDriver webDriver = new InternetExplorerDriver(caps);
			Context.global().setDriver(webDriver);
			File session = new File(System.getProperty("user.dir") + "\\logs\\"
					+ LoggingUtils.executionFolder.getName() + "\\"
					+ mtd.getName() + "_" + webDriver.getSessionId() + "\\logs");
			session.mkdirs();
			Context.global().setSessionFolderPath(session.getPath());
			prApp.set(new ParallelFileAppender(session.getPath()));
			Logger.getRootLogger().addAppender(prApp.get());
			LOGGER.info("Internet explorer browser instantiated successfully");

		} else if (strBrowser.equalsIgnoreCase("Firefox")) {
			ProfilesIni p = new ProfilesIni();
			FirefoxProfile firefoxProfile = p.getProfile("Automation");
			firefoxProfile.setPreference("browser.download.folderList", 2);
			firefoxProfile.setPreference(
					"browser.download.manager.showWhenStarting", false);
			firefoxProfile
					.setPreference(
							"services.sync.prefs.sync.browser.download.manager.closeWhenDone",
							false);
			firefoxProfile.setPreference("browser.download.panel.shown", true);
			firefoxProfile.setPreference(
					"browser.download.manager.showAlertOnComplete", false);
			firefoxProfile.setPreference("browser.download.dir",
					System.getProperty("user.dir")
							+ "\\src\\test\\resources\\saved-files");
			firefoxProfile.setPreference("pdfjs.disabled", true);
			firefoxProfile
					.setPreference("browser.helperApps.neverAsk.saveToDisk",
							"application/pdf, application/x-pdf, application/octet-stream");
			DesiredCapabilities capabilities = DesiredCapabilities.firefox();
			RemoteWebDriver webDriver;
			capabilities.setCapability(FirefoxDriver.PROFILE, firefoxProfile);
			if (LoadPropertiesUtil.configProps.getProperty("seleniumGrid")
					.equalsIgnoreCase("YES")) {
				String hub = "http://"
						+ LoadPropertiesUtil.configProps.getProperty("hubIP")
						+ ":"
						+ LoadPropertiesUtil.configProps.getProperty("hubPort")
						+ "/wd/hub";
				capabilities.setBrowserName("firefox");
				webDriver = new RemoteWebDriver(new URL(hub), capabilities);
				LOGGER.info("Using Selenium Grid");
			} else {
				webDriver = new FirefoxDriver(capabilities);
			}
			Context.global().setDriver(webDriver);
			File session = new File(System.getProperty("user.dir") + "\\logs\\"
					+ LoggingUtils.executionFolder.getName() + "\\"
					+ mtd.getName() + "_" + webDriver.getSessionId() + "\\logs");
			session.mkdirs();
			Context.global().setSessionFolderPath(session.getPath());
			prApp.set(new ParallelFileAppender(session.getPath()));
			Logger.getRootLogger().addAppender(prApp.get());
			LOGGER.info("Firefox browser instantiated successfully");

		} else if (strBrowser.equalsIgnoreCase("HtmlUnitDriver")) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"MM-dd-yyyy_HH.mm.ss");
			HtmlUnitDriver webDriver = new HtmlUnitDriver();
			webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			Context.global().setDriver(webDriver);
			File session = new File(System.getProperty("user.dir") + "\\logs\\"
					+ LoggingUtils.executionFolder.getName() + "\\"
					+ mtd.getName() + "_" + dateFormat + "\\logs");
			session.mkdirs();
			Context.global().setSessionFolderPath(session.getPath());
			prApp.set(new ParallelFileAppender(session.getPath()));
			Logger.getRootLogger().addAppender(prApp.get());
			LOGGER.info("HtmlUnitDriver instantiated successfully");
		} else {
			LOGGER.info("Kindly select a valid browser");
		}
		Context.global().getDriver().manage().timeouts()
				.implicitlyWait(10, TimeUnit.SECONDS);
	}

	public boolean verifyResponseHeaderErrrorCode(String expected, String actual) {
		try {
			Assert.assertEquals(actual, expected);
			;
			LOGGER.info("Validation of Web Service Response is SUCCESSFULL");
		} catch (AssertionError e) {
			LOGGER.info("Actual String '" + actual
					+ "' Does not 'matches with' '" + expected + "'");
			LOGGER.info(e);
			return false;
		}
		return true;

	}

	public boolean verifyResponseHeaderErrrorText(String expected, String actual) {
		try {
			Assert.assertEquals(actual, expected);
			;
			LOGGER.info("Validation of Web Service Response is SUCCESSFULL");
		} catch (AssertionError e) {
			LOGGER.info("Actual String '" + actual
					+ "' Does not 'matches with' '" + expected + "'");
			LOGGER.info(e);
			return false;
		}
		return true;

	}

	public boolean verifyResponse(String expected, String actual) {
		try {
			Assert.assertEquals(actual, expected);

			LOGGER.info("Validation of Web Service Response is SUCCESSFULL");
		} catch (AssertionError e) {
			LOGGER.info("Actual String '" + actual
					+ "' Does not 'matches with' '" + expected + "'");
			LOGGER.info(e);
			return false;
		}
		return true;

	}

	public boolean assertresponse(String expected, String actual) {
		try {
			Assert.assertTrue(expected.contains(actual));

			LOGGER.info("Validation of Web Service Response is SUCCESSFULL");
		} catch (AssertionError e) {
			LOGGER.info("Actual String '" + actual
					+ "' Does not 'matches with' '" + expected + "'");
			LOGGER.info(e);
			return false;
		}
		return true;

	}

	public String convertXmlToJson(String xmltext) {
		JSONObject xmlJSONObj = XML.toJSONObject(xmltext);
		String jsonPrettyPrintString = xmlJSONObj
				.toString(PRETTY_PRINT_INDENT_FACTOR);
		System.out.println(jsonPrettyPrintString);

		return jsonPrettyPrintString;
	}

	public List<String> getListOfDates(Date fromDate, Date toDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		List<String> dates = new ArrayList<String>();
		Calendar cal = Calendar.getInstance();
		cal.setTime(fromDate);
		while (cal.getTime().before(toDate)) {
			cal.add(Calendar.DATE, 1);
			if (!(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY || cal
					.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY)) {
				dates.add(dateFormat.format(cal.getTime()));
			}
		}
		return dates;
	}

	public static BigDecimal sumList(List<String> newList) {
		BigDecimal dc = new BigDecimal(0);
		for (String str : newList) {
			double digit = Double.parseDouble(str);
			dc = dc.add(new BigDecimal(digit));
		}
		return dc;
	}

	/*public boolean compareMap(Map<String, String> map1, Map<String, String> map2) {

		if (map1 == null || map2 == null)
			return false;

		for (String ch1 : map1.keySet()) {
			if (!map1.get(ch1).equalsIgnoreCase(map2.get(ch1)))
				return false;
		}
		for (String ch2 : map2.keySet()) {
			if (!map2.get(ch2).equalsIgnoreCase(map1.get(ch2)))
				return false;
		}
		return true;
	}
	
	public boolean mapsAreEqual(Map<String, String> mapA, Map<String, String> mapB) {

	    try{
	        for (String k : mapB.keySet())
	        {
	            if (!mapA.get(k).equals(mapB.get(k))) {
	                return false;
	            }
	        } 
	        for (String y : mapA.keySet())
	        {
	            if (!mapB.containsKey(y)) {
	                return false;
	            }
	        } 
	    } catch (NullPointerException np) {
	    	LOGGER.info(np);
	        return false;
	    }
	    return true;
	}*/
	
	/**
	 * Functionality: Compare Two value as 'Key-Value' Pair. Input Parameter :
	 * <FirstHashMap> , <SecondHashMap> Type: Null
	 */
	public boolean compareValues(Map<String, String> firstMap,Map<String, String> secondMap) {
		Set<String> keys = firstMap.keySet();
		boolean flag = true;
		List<String> failedIdList = new ArrayList<>();

		for (String key : keys) {
			if (firstMap.get(key).equals(secondMap.get(key))) {
				Report.updateReport("PASS",
						"<b style = \"color:forestgreen;\">Validation Passed</b> \n: For ISIN No - <b>"+ key+ "</b> Expected OrderAmount is this <b>'"+ secondMap.get(key)
								+ "'</b> & actual value (unsattledTrades) is this <b>'"+ firstMap.get(key) + "'</b>");
				LOGGER.info("Matched Sucessfully=> " + key + ": "+ firstMap.get(key));
			} else {
				failedIdList.add(key);
				LOGGER.info("Value mismatched for ISIN : "+key+" ===> Expected is this '" + secondMap.get(key)+"' & actual is this '" + firstMap.get(key) + "'");
				Report.updateReport("FAIL",
						"<b style = \"color:red;\">Validation</b> Value mismatched for ISIN : <b>"+key+"</b> ===> Expected is this <b>'" + secondMap.get(key)+"'</b> & actual is this <b>'" + firstMap.get(key) + "'</b>");
				flag = false;
			}
		}
		if (flag == false) {
			LOGGER.info("List of ISIN No for which values didn't matched:"+ failedIdList);
			try {
				Assert.fail();
			} catch (AssertionError e) {
				LOGGER.info("AssertionError has occured", e);
			}
			return false;
		}
		return true;
	}

}