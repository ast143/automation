package com.nordea.workflow;

import static io.restassured.RestAssured.given;
import io.restassured.response.Response;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import ReadFlatFile.readFlatFile;
import WSAutomation.utility.wsUtils;

import com.nordea.framework.Context;
import com.nordea.pages.PageObject;
import com.nordea.utility.DriverUtils;
import com.nordea.utility.Report;

public class NLPNOwebservice {

	private static final String BASE_URL = "BaseURL";
	private static final String BASE_URL2 = "BaseURL2";
	private static final String USERID = "userID";
	private static final String PSWD = "passoword";
	private static final String TEXTXML = "text/xml";
	private static final String DATE = "date";
	private static final String FILEPATH = "filePath";

	static final  Logger LOGGER = Logger.getLogger(NLPNOwebservice.class);
	PageObject pages = Context.local().getPages();
	wsUtils wsutils = new wsUtils();
	DriverUtils driverutils = new DriverUtils();
	readFlatFile readflatfile = new readFlatFile();
	private static final String JSONOBJECT = "com.nordea.nlp.ulm.ulmgateway.model.transaction.accumulatedorder.AccumulatedOrder";

	public void wsnlpnoService(Map<String, String> testData)
			throws ParseException, IOException {

		String baseURL = testData.get(BASE_URL);
		String baseURL2 = testData.get(BASE_URL2);
		String userName = testData.get(USERID);
		String passWord = testData.get(PSWD);
		String date = testData.get(DATE);
		String filePath = testData.get(FILEPATH);

		Response lastExeTrdDate = given().auth().basic(userName, passWord)
				.contentType(TEXTXML).when().get(baseURL).then().extract()
				.response();
		String lastExeTrdDateRspns = lastExeTrdDate.asString();
		String lstExetrdDateJson = driverutils
				.convertXmlToJson(lastExeTrdDateRspns);
		JSONObject json = new JSONObject(lstExetrdDateJson);
		String executeddate = json.get("string").toString();

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Date toDate = new Date();
		String currentDate = dateFormat.format(toDate);

		List<String> dateList = driverutils.getListOfDates(dateFormat.parse(executeddate), dateFormat.parse(currentDate));
		List<String> lstExecutedDate = new ArrayList<String>(Arrays.asList(date.split(" ")));
		
		Map<String, List<String>> multiValMap = new HashMap<>();
		HashMap<String, String> accumulatedodrmap = new HashMap<>(); 

		for (int j = 0; j < lstExecutedDate.size(); j++) {
			Response accumulatedrspns = given().auth()
					.basic("unittest", "unittest").contentType("text/xml")
					.when().get(baseURL2 + lstExecutedDate.get(j)).then().extract()
					.response();
			LOGGER.info(baseURL2+lstExecutedDate.get(j));		
			String accuulatedresponseMsg = accumulatedrspns.asString();
			String accumulatedJson = driverutils.convertXmlToJson(accuulatedresponseMsg);
			
			Report.updateReport("INFO", "<b style = \"color:purple;\">"+baseURL2+lstExecutedDate.get(j)+"</b>");
			Report.updateReport("INFO",	"<b style = \"color:royalblue;\">WebService Response For Above Requested URL Is : <style>.comments{width: 200; height: 100px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
							+ accumulatedJson + "</textarea>");	
			
			String jsonAccumulated = accumulatedJson.replace(JSONOBJECT,"accumulatedorder");
			JSONObject json1 = new JSONObject(jsonAccumulated);
			JSONObject jSN12 = json1.getJSONObject("list");
			JSONArray jsonarray = jSN12.getJSONArray("accumulatedorder");
			int arralength = jsonarray.length();

			for (int i = 0; i < arralength; i++) {
				JSONObject first = jsonarray.getJSONObject(i);
				String fundISIN = first.get("fundISIN").toString().trim();
				String accumulatedOrderType = first.get("accumulatedOrderType").toString();
				String orderedAmount = first.get("orderedAmount").toString();
				
				String finalAmnt;
				if(accumulatedOrderType.contains("SELL") && orderedAmount != "0"){
					finalAmnt = "-"+orderedAmount;
				}else{
					finalAmnt = orderedAmount;
				}

				List<String> newList = new ArrayList<>();
				newList.add(finalAmnt);
				if (multiValMap.get(fundISIN) == null) {
					
					BigDecimal newodrAmnt = driverutils.sumList(newList);
					BigDecimal newodramntbigdecimal = newodrAmnt.setScale(2,BigDecimal.ROUND_HALF_EVEN);
					String newstrordAmnt = newodramntbigdecimal.toString();
					if(newstrordAmnt.equals("0.00")){
						newstrordAmnt = "0.0";
					}		
					List<String> newAmntList = new ArrayList<>(Arrays.asList(newstrordAmnt.split(",")));
					
					multiValMap.put(fundISIN, newAmntList);
					accumulatedodrmap.put(fundISIN, newAmntList.get(0));
				} else {
					List<String> existingList = multiValMap.get(fundISIN);
					existingList.add(finalAmnt);
					
					BigDecimal odrAmnt = driverutils.sumList(existingList);
					BigDecimal odramntbigdecimal = odrAmnt.setScale(2,BigDecimal.ROUND_HALF_EVEN);
					String strordAmnt = odramntbigdecimal.toString();
					List<String> finamAmntList = new ArrayList<>(Arrays.asList(strordAmnt.split(",")));
					
					multiValMap.put(fundISIN, finamAmntList);
					accumulatedodrmap.put(fundISIN, finamAmntList.get(0));
				}
			}
		}
		
		LOGGER.info(multiValMap);
		LOGGER.info(accumulatedodrmap);
		Map<String, LinkedList<String>> nimstradelist = readflatfile.getTxtValuesInMap(filePath);
		LinkedList<String> key1 = nimstradelist.get("Security ISIN");
		LOGGER.info("======= Value for Security ISIN===== \n"+nimstradelist.get("Security ISIN"));
		LinkedList<String> val1 = nimstradelist.get("Unsettled trades");
		LOGGER.info("======= Value for Unsettled Trades===== \n"+nimstradelist.get("Unsettled trades"));
		
		HashMap<String, String> nimtradeListMap = new HashMap<>();
		if(key1.size()==val1.size()) {
			int count = 0;
			for(String isin : key1) {
				nimtradeListMap.put(isin,val1.get(count));
				count++;
			}
		}
		
		LOGGER.info(nimtradeListMap);
		
		boolean validationStatus = driverutils.compareValues(accumulatedodrmap, nimtradeListMap);
		if(validationStatus){
			Report.updateReport("PASS", "Validations are pass for all the ISINs");
		}else{
			Report.updateReport("FAIL", 
					"<b><u>Validations are failed and detailed information for  <b style = \"color:forestgreen;\">PASSED</b> & "
					+ "  <b style = \"color:red;\">FAILED</b> ISIN are above</u></b>");
		}
	}
}
