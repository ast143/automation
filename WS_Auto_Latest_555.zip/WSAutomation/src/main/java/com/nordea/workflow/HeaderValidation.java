package com.nordea.workflow;

import static io.restassured.RestAssured.given;
import io.restassured.response.Response;

import java.util.Map;

import org.apache.log4j.Logger;

import WSAutomation.utility.wsUtils;

import com.nordea.framework.Context;
import com.nordea.pages.PageObject;
import com.nordea.utility.DriverUtils;
import com.nordea.utility.Report;

public class HeaderValidation {

	private static final String BASE_URL = "BaseURL";
	private static final String SERVICE_INPUT = "ServiceInput";
	private static final String CUSTID = "custid";
	private static final String XDBF_VAL = "XDBF";
	private static final String END_APPLICATION_ID = "endapplicationid";
	private static final String LOGON_ID = "logonid";
	private static final String TIMESTAMP = "timestmp";
	private static final String ERROR_CODE = "errorCode";
	private static final String ERROR_TEXT = "errorText";
	private static final String MISSING_HDR = "missingHeader";
	private static final String POLICY_ID = "policyID";
	private static final String PRODUCT_ID = "productId";
	private static final String CATG_ID = "categoryId";
	private static final String CONTEXT = "application/json";
	private static final String HDR_CUST_ID = "cust-id";
	private static final String HDR_XDBF = "X-DBF-ServiceRequestContext";
	private static final String HDR_END_APP_ID = "endapplication-id";
	private static final String HDR_LOGONID = "logon-id";
	private static final String HDR_TIMESTAMP = "timestamp";
	private static final String HDR_PLOCY_ID = "policyID";
	private static final String HDR_PROD_ID = "productId";
	private static final String HDR_CATG_ID = "categoryId";
	final static Logger LOGGER = Logger.getLogger(HeaderValidation.class);
	PageObject pages = Context.local().getPages();
	wsUtils wsutils = new wsUtils();
	DriverUtils driverutils = new DriverUtils();

	public void wsHdrvalidation(Map<String, String> testData) {

		String baseURL = testData.get(BASE_URL);
		String serviceInput = testData.get(SERVICE_INPUT);
		String custID = testData.get(CUSTID);
		String xdbfContext = testData.get(XDBF_VAL);
		String endapplicationid = testData.get(END_APPLICATION_ID);
		String logonID = testData.get(LOGON_ID);
		String timestamp = testData.get(TIMESTAMP);
		String applicationJson = CONTEXT;
		String expectedErroCode = testData.get(ERROR_CODE);
		String expectedErrotext = testData.get(ERROR_TEXT);
		String missingHdr = testData.get(MISSING_HDR);

		Response catgryService = given()
				.headers(HDR_CUST_ID, custID, HDR_XDBF, xdbfContext,
						HDR_END_APP_ID, endapplicationid, HDR_LOGONID, logonID,
						HDR_TIMESTAMP, timestamp).contentType(applicationJson)
				.when().get(baseURL + serviceInput).then().extract().response();
		String responseMsg = catgryService.asString();

		Report.updateReport(
				"INFO",
				"<b style = \"color:purple;\">Web Service Request Input Parameters are </b> :- <b>CustomerID = </b><b style = \"color:dodgerblue;\"><i>"
						+ custID
						+ "</i></b> , "
						+ "<b>X-DBF-ServiceRequestContext = </b><b style = \"color:dodgerblue;\"><i>"
						+ xdbfContext
						+ "</i></b> , "
						+ "<b>endapplicationID = </b><b style = \"color:dodgerblue;\"><i>"
						+ endapplicationid
						+ "</i></b> , "
						+ "<b>LogonID = </b><b style = \"color:dodgerblue;\"><i>"
						+ logonID + "</i></b>");

		Report.updateReport(
				"INFO",
				"<b style = \"color:purple;\">Request URL with above input parameter is :</b> <b style = \"color:dodgerblue;\">"
						+ baseURL + serviceInput + "</b>");

		LOGGER.info("WebService Response is:" + responseMsg);
		String actualErroCode = wsutils.getAttributeValue(catgryService,
				"response.errorCode").toString();
		Report.updateReport(
				"INFO",
				"<b>JSON Response for missing header value for header - </b> <b style = \"color:dodgerblue;\"><i>"
						+ missingHdr
						+ "</i></b> - "
						+ " : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
						+ catgryService.asString() + "</textarea>");
		boolean verifyRslt = driverutils.verifyResponseHeaderErrrorCode(
				expectedErroCode, actualErroCode);
		if (verifyRslt == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error code : <b>"
							+ actualErroCode
							+ "</b> and Expected Errror Code <b>"
							+ expectedErroCode + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error code : <b><i>"
					+ actualErroCode
					+ "</i></b> and Expected Errror Code <b><i>"
					+ expectedErroCode + "</i></b> are NOT matching");
		}

		String actualErroText = wsutils.getAttributeValue(catgryService,
				"response.errorText").toString();
		LOGGER.info("Error Code & ErrorText is: " + actualErroCode + " - "
				+ actualErroText + " for missing header value for header <b>"
				+ missingHdr + "</b>");
		boolean vrfyRslterroText = driverutils.verifyResponseHeaderErrrorText(
				expectedErroCode, actualErroCode);

		if (vrfyRslterroText == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error text : <b>"
							+ actualErroText
							+ "</b> and Expected Errror text <b>"
							+ expectedErrotext + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error text : <b><i>"
					+ actualErroText
					+ "</o></b> and Expected Errror text <b><i>"
					+ expectedErrotext + "</i></b> are NOT matching");
		}

	}

	public void verifyhrdCustidPolicyID(Map<String, String> testData) {

		String baseURL = testData.get(BASE_URL);
		String serviceInput = testData.get(SERVICE_INPUT);
		String custID = testData.get(CUSTID);
		String xdbfContext = testData.get(XDBF_VAL);
		String endapplicationid = testData.get(END_APPLICATION_ID);
		String logonID = testData.get(LOGON_ID);
		String timestamp = testData.get(TIMESTAMP);
		String applicationJson = CONTEXT;
		String expectedErroCode = testData.get(ERROR_CODE);
		String expectedErrotext = testData.get(ERROR_TEXT);
		String missingHdr = testData.get(MISSING_HDR);
		String policy_id = testData.get(POLICY_ID);

		Response catgryService = given()
				.headers(HDR_PLOCY_ID, policy_id, HDR_CUST_ID, custID,
						HDR_XDBF, xdbfContext, HDR_END_APP_ID,
						endapplicationid, HDR_LOGONID, logonID, HDR_TIMESTAMP,
						timestamp).contentType(applicationJson).when()
				.get(baseURL + serviceInput).then().extract().response();
		String responseMsg = catgryService.asString();

		Report.updateReport(
				"INFO",
				"<b style = \"color:coral;\">Web Service Request Input Parameters are </b> :- <b>CustomerID = </b><b style = \"color:dodgerblue;\"><i>"
						+ custID
						+ "</i></b> , "
						+ "<b>PolicyID = </b><b style = \"color:dodgerblue;\"><i>"
						+ policy_id
						+ "</i></b> ,"
						+ "<b>X-DBF-ServiceRequestContext = </b><b style = \"color:dodgerblue;\"><i>"
						+ xdbfContext
						+ "</i></b> , "
						+ "<b>endapplicationID = </b><b style = \"color:dodgerblue;\"><i>"
						+ endapplicationid
						+ "</i></b> , "
						+ "<b>LogonID = </b><b style = \"color:dodgerblue;\"><i>"
						+ logonID + "</i></b>");

		Report.updateReport(
				"INFO",
				"<b style = \"color:purple;\">Request URL with above input parameter is :</b> <b style = \"color:dodgerblue;\">"
						+ baseURL + serviceInput + "</b>");

		LOGGER.info("WebService Response is:" + responseMsg);
		String actualErroCode = wsutils.getAttributeValue(catgryService,
				"response.errorCode").toString();
		Report.updateReport(
				"INFO",
				"<b>JSON Response for missing header value for header <i>"
						+ missingHdr
						+ "</i> - "
						+ "</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
						+ catgryService.asString() + "</textarea>");

		boolean verifyRslt = driverutils.verifyResponseHeaderErrrorCode(
				expectedErroCode, actualErroCode);
		if (verifyRslt == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error code : <b>"
							+ actualErroCode
							+ "</b> and Expected Errror Code <b>"
							+ expectedErroCode + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error code : <b><i>"
					+ actualErroCode
					+ "</i></b> and Expected Errror Code <b><i>"
					+ expectedErroCode + "</i></b> are NOT matching");
		}

		String actualErroText = wsutils.getAttributeValue(catgryService,
				"response.errorText").toString();
		LOGGER.info("Error Code & ErrorText is: " + actualErroCode + " - "
				+ actualErroText + " for missing header value for header <b>"
				+ missingHdr + "</b>");
		boolean vrfyRslterroText = driverutils.verifyResponseHeaderErrrorText(
				expectedErroCode, actualErroCode);

		if (vrfyRslterroText == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error text : <b>"
							+ actualErroText
							+ "</b> and Expected Errror text <b>"
							+ expectedErrotext + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error text : <b><i>"
					+ actualErroText
					+ "</o></b> and Expected Errror text <b><i>"
					+ expectedErrotext + "</i></b> are NOT matching");
		}

	}

	public void verifyhrdCustPlcyProdID(Map<String, String> testData) {

		String baseURL = testData.get(BASE_URL);
		String serviceInput = testData.get(SERVICE_INPUT);
		String custID = testData.get(CUSTID);
		String xdbfContext = testData.get(XDBF_VAL);
		String endapplicationid = testData.get(END_APPLICATION_ID);
		String logonID = testData.get(LOGON_ID);
		String timestamp = testData.get(TIMESTAMP);
		String applicationJson = CONTEXT;
		String expectedErroCode = testData.get(ERROR_CODE);
		String expectedErrotext = testData.get(ERROR_TEXT);
		String missingHdr = testData.get(MISSING_HDR);
		String policyID = testData.get(POLICY_ID);
		String prodID = testData.get(PRODUCT_ID);

		Response catgryService = given()
				.headers(HDR_CUST_ID, custID, HDR_PROD_ID, prodID,
						HDR_PLOCY_ID, policyID, HDR_XDBF, xdbfContext,
						HDR_END_APP_ID, endapplicationid, HDR_LOGONID, logonID,
						HDR_TIMESTAMP, timestamp).contentType(applicationJson)
				.when().get(baseURL + serviceInput).then().extract().response();
		String responseMsg = catgryService.asString();

		Report.updateReport(
				"INFO",
				"<b style = \"color:coral;\">Web Service Request Input Parameters are </b> :- <b>CustomerID = </b><b style = \"color:dodgerblue;\"><i>"
						+ custID
						+ "</i></b> , "
						+ "<b>PolicyID = </b><b style = \"color:dodgerblue;\"><i>"
						+ policyID
						+ "</i></b> , <b>ProductID = </b><b style = \"color:dodgerblue;\"><i>"
						+ prodID
						+ "</i></b> ,"
						+ "<b>X-DBF-ServiceRequestContext = </b><b style = \"color:dodgerblue;\"><i>"
						+ xdbfContext
						+ "</i></b> , "
						+ "<b>endapplicationID = </b><b style = \"color:dodgerblue;\"><i>"
						+ endapplicationid
						+ "</i></b> , "
						+ "<b>LogonID = </b><b style = \"color:dodgerblue;\"><i>"
						+ logonID + "</i></b>");

		Report.updateReport(
				"INFO",
				"<b style = \"color:purple;\">Request URL with above input parameter is :</b> <b style = \"color:dodgerblue;\">"
						+ baseURL + serviceInput + "</b>");

		LOGGER.info("WebService Response is:" + responseMsg);
		String actualErroCode = wsutils.getAttributeValue(catgryService,
				"response.errorCode").toString();
		Report.updateReport(
				"INFO",
				"<b>JSON Response for missing header value for header <i>"
						+ missingHdr
						+ "</i> - "
						+ "</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
						+ catgryService.asString() + "</textarea>");

		boolean verifyRslt = driverutils.verifyResponseHeaderErrrorCode(
				expectedErroCode, actualErroCode);
		if (verifyRslt == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error code : <b>"
							+ actualErroCode
							+ "</b> and Expected Errror Code <b>"
							+ expectedErroCode + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error code : <b><i>"
					+ actualErroCode
					+ "</i></b> and Expected Errror Code <b><i>"
					+ expectedErroCode + "</i></b> are NOT matching");
		}

		String actualErroText = wsutils.getAttributeValue(catgryService,
				"response.errorText").toString();
		LOGGER.info("Error Code & ErrorText is: " + actualErroCode + " - "
				+ actualErroText + " for missing header value for header <b>"
				+ missingHdr + "</b>");
		boolean vrfyRslterroText = driverutils.verifyResponseHeaderErrrorText(
				expectedErroCode, actualErroCode);

		if (vrfyRslterroText == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error text : <b>"
							+ actualErroText
							+ "</b> and Expected Errror text <b>"
							+ expectedErrotext + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error text : <b><i>"
					+ actualErroText
					+ "</o></b> and Expected Errror text <b><i>"
					+ expectedErrotext + "</i></b> are NOT matching");
		}

	}

	public void verifyhrdCustPlcyProdCtgryid(
			Map<String, String> testData) {

		String baseURL = testData.get(BASE_URL);
		String serviceInput = testData.get(SERVICE_INPUT);
		String custID = testData.get(CUSTID);
		String xdbfContext = testData.get(XDBF_VAL);
		String endapplicationid = testData.get(END_APPLICATION_ID);
		String logonID = testData.get(LOGON_ID);
		String timestamp = testData.get(TIMESTAMP);
		String applicationJson = CONTEXT;
		String expectedErroCode = testData.get(ERROR_CODE);
		String expectedErrotext = testData.get(ERROR_TEXT);
		String missingHdr = testData.get(MISSING_HDR);
		String policyID = testData.get(POLICY_ID);
		String prodID = testData.get(PRODUCT_ID);
		String categoryID = testData.get(CATG_ID);

		Response catgryService = given()
				.headers(HDR_PROD_ID, prodID, HDR_CUST_ID, custID,
						HDR_PLOCY_ID, policyID, HDR_CATG_ID, categoryID,
						HDR_XDBF, xdbfContext, HDR_END_APP_ID,
						endapplicationid, HDR_LOGONID, logonID, HDR_TIMESTAMP,
						timestamp).contentType(applicationJson).when()
				.get(baseURL + serviceInput).then().extract().response();
		String responseMsg = catgryService.asString();

		Report.updateReport(
				"INFO",
				"<b style = \"color:coral;\">Web Service Request Input Parameters are </b> :- <b>CustomerID = </b><b style = \"color:dodgerblue;\"><i>"
						+ custID
						+ "</i></b> , "
						+ "<b>PolicyID = </b><b style = \"color:dodgerblue;\"><i>"
						+ policyID
						+ "</i></b> , <b>ProductID = </b><b style = \"color:dodgerblue;\"><i>"
						+ prodID
						+ "</i></b> , "
						+ "<b>CategoryID = </b><b style = \"color:dodgerblue;\"><i>"
						+ categoryID
						+ "</i></b> ,"
						+ "<b>X-DBF-ServiceRequestContext = </b><b style = \"color:dodgerblue;\"><i>"
						+ xdbfContext
						+ "</i></b> , "
						+ "<b>endapplicationID = </b><b style = \"color:dodgerblue;\"><i>"
						+ endapplicationid
						+ "</i></b> , "
						+ "<b>LogonID = </b><b style = \"color:dodgerblue;\"><i>"
						+ logonID + "</i></b>");

		Report.updateReport(
				"INFO",
				"<b style = \"color:purple;\">Request URL with above input parameter is :</b> <b style = \"color:dodgerblue;\">"
						+ baseURL + serviceInput + "</b>");

		LOGGER.info("WebService Response is:" + responseMsg);
		String actualErroCode = wsutils.getAttributeValue(catgryService,
				"response.errorCode").toString();
		Report.updateReport(
				"INFO",
				"<b>JSON Response for missing header value for header <i>"
						+ missingHdr
						+ "</i> - "
						+ "</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
						+ catgryService.asString() + "</textarea>");

		boolean verifyRslt = driverutils.verifyResponseHeaderErrrorCode(
				expectedErroCode, actualErroCode);
		if (verifyRslt == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error code : <b>"
							+ actualErroCode
							+ "</b> and Expected Errror Code <b>"
							+ expectedErroCode + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error code : <b><i>"
					+ actualErroCode
					+ "</i></b> and Expected Errror Code <b><i>"
					+ expectedErroCode + "</i></b> are NOT matching");
		}

		String actualErroText = wsutils.getAttributeValue(catgryService,
				"response.errorText").toString();
		LOGGER.info("Error Code & ErrorText is: " + actualErroCode + " - "
				+ actualErroText + " for missing header value for header <b>"
				+ missingHdr + "</b>");
		boolean vrfyRslterroText = driverutils.verifyResponseHeaderErrrorText(
				expectedErroCode, actualErroCode);

		if (vrfyRslterroText == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error text : <b>"
							+ actualErroText
							+ "</b> and Expected Errror text <b>"
							+ expectedErrotext + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error text : <b><i>"
					+ actualErroText
					+ "</o></b> and Expected Errror text <b><i>"
					+ expectedErrotext + "</i></b> are NOT matching");
		}

	}

	public void verifyhrdStartEndDate(Map<String, String> testData) {

		String baseURL = testData.get(BASE_URL);
		String serviceInput = testData.get(SERVICE_INPUT);
		String custID = testData.get(CUSTID);
		String xdbfContext = testData.get(XDBF_VAL);
		String endapplicationid = testData.get(END_APPLICATION_ID);
		String logonID = testData.get(LOGON_ID);
		String timestamp = testData.get(TIMESTAMP);
		String applicationJson = CONTEXT;
		String expectedErroCode = testData.get(ERROR_CODE);
		String expectedErrotext = testData.get(ERROR_TEXT);
		String missingHdr = testData.get(MISSING_HDR);
		String policyID = testData.get(POLICY_ID);
		String startDate = "2017-01-01";
		String endDate = "2017-12-31";

		Response catgryService = given()
				.headers(HDR_PLOCY_ID, policyID, HDR_CUST_ID, custID.trim(),
						"startDate", startDate, "endDate", endDate, HDR_XDBF,
						xdbfContext, HDR_END_APP_ID, endapplicationid,
						HDR_LOGONID, logonID, HDR_TIMESTAMP, timestamp)
				.contentType(applicationJson).when()
				.get(baseURL + serviceInput).then().extract().response();
		String responseMsg = catgryService.asString();

		Report.updateReport(
				"INFO",
				"<b style = \"color:coral;\">Web Service Request Input Parameters are </b> :- <b>CustomerID = </b><b style = \"color:dodgerblue;\"><i>"
						+ custID
						+ "</i></b> , "
						+ "<b>PolicyID = </b><b style = \"color:dodgerblue;\"><i>"
						+ policyID
						+ "</i></b> , <b>StartDate = </b><b style = \"color:dodgerblue;\"><i>"
						+ startDate
						+ "</i></b> , "
						+ "<b>EndDate = </b><b style = \"color:dodgerblue;\"><i>"
						+ endDate
						+ "</i></b> ,"
						+ "<b>X-DBF-ServiceRequestContext = </b><b style = \"color:dodgerblue;\"><i>"
						+ xdbfContext
						+ "</i></b> , "
						+ "<b>endapplicationID = </b><b style = \"color:dodgerblue;\"><i>"
						+ endapplicationid
						+ "</i></b> , "
						+ "<b>LogonID = </b><b style = \"color:dodgerblue;\"><i>"
						+ logonID + "</i></b>");

		Report.updateReport(
				"INFO",
				"<b style = \"color:purple;\">Request URL with above input parameter is :</b> <b style = \"color:dodgerblue;\">"
						+ baseURL + serviceInput + "</b>");

		LOGGER.info("WebService Response is:" + responseMsg);
		String actualErroCode = wsutils.getAttributeValue(catgryService,
				"response.errorCode").toString();
		Report.updateReport(
				"INFO",
				"<b>JSON Response for missing header value for header <i>"
						+ missingHdr
						+ "</i> - "
						+ "</b> : <style>.comments{width: 100; height: 70px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
						+ catgryService.asString() + "</textarea>");

		boolean verifyRslt = driverutils.verifyResponseHeaderErrrorCode(
				expectedErroCode, actualErroCode);
		if (verifyRslt == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error code : <b>"
							+ actualErroCode
							+ "</b> and Expected Errror Code <b>"
							+ expectedErroCode + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error code : <b><i>"
					+ actualErroCode
					+ "</i></b> and Expected Errror Code <b><i>"
					+ expectedErroCode + "</i></b> are NOT matching");
		}

		String actualErroText = wsutils.getAttributeValue(catgryService,
				"response.errorText").toString();
		LOGGER.info("Error Code & ErrorText is: " + actualErroCode + " - "
				+ actualErroText + " for missing header value for header <b>"
				+ missingHdr + "</b>");
		boolean vrfyRslterroText = driverutils.verifyResponseHeaderErrrorText(
				expectedErroCode, actualErroCode);

		if (vrfyRslterroText == true) {
			Report.updateReport("PASS",
					"<b style = \"color:forestgreen;\">Validation</b> : Actual Error text : <b>"
							+ actualErroText
							+ "</b> and Expected Errror text <b>"
							+ expectedErrotext + "</b> are matching");
		} else {
			Report.updateReport("FAIL", "Actual Error text : <b><i>"
					+ actualErroText
					+ "</o></b> and Expected Errror text <b><i>"
					+ expectedErrotext + "</i></b> are NOT matching");
		}

	}

}
