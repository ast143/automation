package com.nordea.workflow;

import java.util.HashMap;
import java.util.Map;

/**
 * Workflow class provides a generic getWorkflow method for getting Workflows
 * 
 * @author Nitesh Khanna
 */
public class Workflow {

	private Map<Class<?>, Object> workflows = new HashMap<>();

	@SuppressWarnings("unchecked")
	public <T> T getWorkflow(Class<T> workflow) throws Exception {

		if (!workflows.containsKey(workflow)) {
			Object workflowInstance = workflow.newInstance();
			workflows.put(workflow, workflowInstance);
		}

		Object workflowInstance = workflows.get(workflow);
		return (T) workflowInstance;
	}

}