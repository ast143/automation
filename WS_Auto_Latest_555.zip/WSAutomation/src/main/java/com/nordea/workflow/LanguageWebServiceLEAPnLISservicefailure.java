package com.nordea.workflow;

import static io.restassured.RestAssured.given;
import io.restassured.response.Response;

import java.util.Map;

import org.apache.log4j.Logger;

import WSAutomation.utility.wsUtils;

import com.nordea.framework.Context;
import com.nordea.pages.PageObject;
import com.nordea.utility.DriverUtils;
import com.nordea.utility.Report;

public class LanguageWebServiceLEAPnLISservicefailure {

	private static final String BASE_URL = "BaseURL";
	private static final String SERVICE_INPUT = "ServiceInput";
	private static final String CUSTID = "custid";
	private static final String XDBF_VAL = "XDBF";
	private static final String END_APPLICATION_ID = "endapplicationid";
	private static final String LOGON_ID = "logonid";
	private static final String TIMESTAMP = "timestmp";
	private static final String ERROR_CODE = "errorCode";
	private static final String ERROR_TEXT = "errorText";
	private static final String CONTEXT = "application/json";
	private static final String HDR_CUST_ID = "cust-id";
	private static final String HDR_XDBF = "X-DBF-ServiceRequestContext";
	private static final String HDR_END_APP_ID = "endapplication-id";
	private static final String HDR_LOGONID = "logon-id";
	private static final String HDR_TIMESTAMP = "timestamp";
	private static final String RESPONSE = "\"result\":\"ERROR\"";
	private static final String LANG_CODE = "languageCode";

	final static Logger LOGGER = Logger
			.getLogger(LanguageWebServiceLEAPnLISservicefailure.class);
	PageObject pages = Context.local().getPages();
	wsUtils wsutils = new wsUtils();
	DriverUtils driverutils = new DriverUtils();

	public void wsLanguageService(Map<String, String> testData) {

		String baseURL = testData.get(BASE_URL);
		String serviceInput = testData.get(SERVICE_INPUT);
		String custID = testData.get(CUSTID);
		String xdbfContext = testData.get(XDBF_VAL);
		String endapplicationid = testData.get(END_APPLICATION_ID);
		String logonID = testData.get(LOGON_ID);
		String timestamp = testData.get(TIMESTAMP);
		String applicationJson = CONTEXT;
		String expectedErroCode = testData.get(ERROR_CODE);
		String expectedErrotext = testData.get(ERROR_TEXT);

		String expectedLangCode = testData.get(LANG_CODE);

		Response languageservice = given()
				.headers(HDR_CUST_ID, custID, HDR_XDBF, xdbfContext,
						HDR_END_APP_ID, endapplicationid, HDR_LOGONID, logonID,
						HDR_TIMESTAMP, timestamp).contentType(applicationJson)
				.when().get(baseURL + serviceInput).then().extract().response();
		String responseMsg = languageservice.asString();

		Report.updateReport(
				"INFO",
				"<b style = \"color:purple;\">Web Service Request Input Parameters are </b> :- <b>CustomerID = </b><b style = \"color:dodgerblue;\"><i>"
						+ custID
						+ "</i></b> , "
						+ "<b>X-DBF-ServiceRequestContext = </b><b style = \"color:dodgerblue;\"><i>"
						+ xdbfContext
						+ "</i></b> , "
						+ "<b>endapplicationID = </b><b style = \"color:dodgerblue;\"><i>"
						+ endapplicationid
						+ "</i></b> , "
						+ "<b>LogonID = </b><b style = \"color:dodgerblue;\"><i>"
						+ logonID + "</i></b>");

		Report.updateReport(
				"INFO",
				"<b style = \"color:purple;\">Request URL with above input parameter is :</b> <b style = \"color:dodgerblue;\">"
						+ baseURL + serviceInput + "</b>");

		if (responseMsg.length() > 0) {
			Report.updateReport(
					"INFO",
					"<b>JSON Response For Above Requested URL Is - </b> <b style = \"color:dodgerblue;\"><i>"
							+ "</i></b> - "
							+ " : <style>.comments{width: 70; height: 30px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
							+ languageservice.asString() + "</textarea>");
		} else {
			Report.updateReport("INFO",
					"<b>No JSON response received for the the requested URL</b>");
		}

		if (responseMsg.contains(RESPONSE)) {

			LOGGER.info("WebService Response is:" + responseMsg);
			String actualErroCode = wsutils.getAttributeValue(languageservice,
					"response.errorCode").toString();

			boolean verifyRslt = driverutils.verifyResponseHeaderErrrorCode(
					expectedErroCode, actualErroCode);
			if (verifyRslt == true) {
				Report.updateReport(
						"PASS",
						"<b style = \"color:forestgreen;\">Validation</b> : Actual Error code : <b style = \"color:green;\"><u>"
								+ actualErroCode
								+ "</u></b> and Expected Errror Code <b style = \"color:green;\"><u>"
								+ expectedErroCode + "</u></b> are matching");
			} else {
				Report.updateReport("FAIL", "Actual Error code : <b><i>"
						+ actualErroCode
						+ "</i></b> and Expected Errror Code <b><i>"
						+ expectedErroCode + "</i></b> are NOT matching");
			}

			String actualErroText = wsutils.getAttributeValue(languageservice,
					"response.errorText").toString();
			boolean vrfyRslterroText = driverutils
					.verifyResponseHeaderErrrorText(expectedErroCode,
							actualErroCode);

			if (vrfyRslterroText == true) {
				Report.updateReport(
						"PASS",
						"<b style = \"color:forestgreen;\">Validation</b> : Actual Error text : <b style = \"color:forestgreen;\"><u>"
								+ actualErroText
								+ "</u></b> and Expected Errror text <b style = \"color:green;\"><u>"
								+ expectedErrotext + "</u></b> are matching");
			} else {
				Report.updateReport("FAIL", "Actual Error text : <b><i>"
						+ actualErroText
						+ "</o></b> and Expected Errror text <b><i>"
						+ expectedErrotext + "</i></b> are NOT matching");
			}
		} else {
			String actuallangCode = wsutils.getAttributeValue(languageservice,
					"langCode").toString();

			boolean verifyRslt = driverutils.verifyResponse(expectedLangCode,
					actuallangCode);
			if (verifyRslt == true) {
				Report.updateReport(
						"PASS",
						"<b style = \"color:forestgreen;\">Validation</b> : Actual Language code : <b style = \"color:green;\"><u>"
								+ actuallangCode
								+ "</u></b> and Expected Language Code <b style = \"color:green;\"><u>"
								+ expectedLangCode + "</u></b> are matching");
			} else {
				Report.updateReport("FAIL", "Actual Language code : <b><i>"
						+ actuallangCode
						+ "</i></b> and Expected Language Code <b><i>"
						+ expectedLangCode + "</i></b> are NOT matching");
			}

		}

	}

	/*
	 * public void servicefailureLEAPnLIS(Map<String, String> testData) {
	 * 
	 * String baseURL = testData.get(BASE_URL); String serviceInput =
	 * testData.get(SERVICE_INPUT); String custID = testData.get(CUSTID); String
	 * xdbfContext = testData.get(XDBF_VAL); String endapplicationid =
	 * testData.get(END_APPLICATION_ID); String logonID =
	 * testData.get(LOGON_ID); String timestamp = testData.get(TIMESTAMP);
	 * String applicationJson = CONTEXT; String expectedErroCode =
	 * testData.get(ERROR_CODE); String expectedErrotext =
	 * testData.get(ERROR_TEXT); String missingHdr = testData.get(MISSING_HDR);
	 * 
	 * Response languageservice = given() .headers(HDR_CUST_ID, custID,
	 * HDR_XDBF, xdbfContext, HDR_END_APP_ID, endapplicationid, HDR_LOGONID,
	 * logonID, HDR_TIMESTAMP, timestamp).contentType(applicationJson)
	 * .when().get(baseURL + serviceInput).then().extract().response(); String
	 * responseMsg = languageservice.asString();
	 * 
	 * Report.updateReport( "INFO",
	 * "<b style = \"color:purple;\">Web Service Request Input Parameters are </b> :- <b>CustomerID = </b><b style = \"color:dodgerblue;\"><i>"
	 * + custID + "</i></b> , " +
	 * "<b>X-DBF-ServiceRequestContext = </b><b style = \"color:dodgerblue;\"><i>"
	 * + xdbfContext + "</i></b> , " +
	 * "<b>endapplicationID = </b><b style = \"color:dodgerblue;\"><i>" +
	 * endapplicationid + "</i></b> , " +
	 * "<b>LogonID = </b><b style = \"color:dodgerblue;\"><i>" + logonID +
	 * "</i></b>");
	 * 
	 * Report.updateReport( "INFO",
	 * "<b style = \"color:purple;\">Request URL with above input parameter is :</b> <b style = \"color:dodgerblue;\">"
	 * + baseURL + serviceInput + "</b>");
	 * 
	 * if (responseMsg.length() > 0) { Report.updateReport( "INFO",
	 * "<b>JSON Response For Above Requested URL Is - </b> <b style = \"color:dodgerblue;\"><i>"
	 * + missingHdr + "</i></b> - " +
	 * " : <style>.comments{width: 70; height: 30px}</style><textarea style=\"font-weight: bold\" class=\"comments\">"
	 * + languageservice.asString() + "</textarea>"); } else {
	 * Report.updateReport("INFO",
	 * "<b>No JSON response received for the the requested URL</b>"); }
	 * 
	 * if (responseMsg.contains(RESPONSE)) {
	 * 
	 * LOGGER.info("WebService Response is:" + responseMsg); String
	 * actualErroCode = wsutils.getAttributeValue(languageservice,
	 * "response.errorCode").toString();
	 * 
	 * boolean verifyRslt = driverutils.verifyResponseHeaderErrrorCode(
	 * expectedErroCode, actualErroCode); if (verifyRslt == true) {
	 * Report.updateReport( "PASS",
	 * "<b style = \"color:forestgreen;\">Validation</b> : Actual Error code : <b style = \"color:green;\"><u>"
	 * + actualErroCode +
	 * "</u></b> and Expected Errror Code <b style = \"color:green;\"><u>" +
	 * expectedErroCode + "</u></b> are matching"); } else {
	 * Report.updateReport("FAIL", "Actual Error code : <b><i>" + actualErroCode
	 * + "</i></b> and Expected Errror Code <b><i>" + expectedErroCode +
	 * "</i></b> are NOT matching"); }
	 * 
	 * String actualErroText = wsutils.getAttributeValue(languageservice,
	 * "response.errorText").toString();
	 * LOGGER.info("Error Code & ErrorText is: " + actualErroCode + " - " +
	 * actualErroText + " for missing header value for header <b>" + missingHdr
	 * + "</b>"); boolean vrfyRslterroText = driverutils
	 * .verifyResponseHeaderErrrorText(expectedErroCode, actualErroCode);
	 * 
	 * if (vrfyRslterroText == true) { Report.updateReport( "PASS",
	 * "<b style = \"color:forestgreen;\">Validation</b> : Actual Error text : <b style = \"color:forestgreen;\"><u>"
	 * + actualErroText +
	 * "</u></b> and Expected Errror text <b style = \"color:green;\"><u>" +
	 * expectedErrotext + "</u></b> are matching"); } else {
	 * Report.updateReport("FAIL", "Actual Error text : <b><i>" + actualErroText
	 * + "</o></b> and Expected Errror text <b><i>" + expectedErrotext +
	 * "</i></b> are NOT matching"); }
	 * 
	 * } else { Report.updateReport("FAIL",
	 * "<b>It seems the LIS/LEAP service is not down......</b>"); } }
	 */
}
