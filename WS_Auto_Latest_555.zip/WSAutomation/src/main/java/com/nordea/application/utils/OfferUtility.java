package com.nordea.application.utils;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.nordea.framework.Context;
import com.nordea.page.components.LHN;
import com.nordea.pages.EventViewPage;
import com.nordea.pages.HomeWorkflow;
import com.nordea.pages.NewOfferPage;
import com.nordea.pages.OfferCoversPage;
import com.nordea.pages.OfferMakePolicy;
import com.nordea.pages.OfferResultCalcAndPrinting;
import com.nordea.utility.Report;

public class OfferUtility {
	
	final static Logger logger = Logger.getLogger(OfferUtility.class);
	
	/**
	 * Functionality: Select Product from New Offer Page
	 * @param prodId
	 * @throws Exception
	 */
	public void selectProduct(String prodId) throws Exception {
		if ("3".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct3();
		}
		if ("4".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct4();
		}
		if ("5".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct5();
		}
		if ("6".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct6();
		}
		if ("7".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct7();
		}
		if ("8".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct8();
		}
		if ("9".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct9();
		}
		if ("36".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct36();
		}
		if ("39".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct39();
		}
		if ("58".equals(prodId)) {
			Context.local().getPages().getPage(NewOfferPage.class).selectProduct58();
		}
	}
	
	/**
	 * Functionality: Add covers as per testdata for both Private and corporate customers 
	 * @param testData
	 * @throws Exception
	 */
	public void addCovers(LinkedHashMap<String, String> testData) throws Exception {
		
		String[] cover= testData.get("CoverName").split(",");
		String productID = testData.get("Product_ID");
		boolean corporateFlag= false; 
        boolean insuredFlag = false;
        String[] custID = testData.get("Customer_ID").split("-");
		if(custID[1].length()==2){
			corporateFlag = true;
		}
				
		if(productID.equalsIgnoreCase("9")|| productID.equalsIgnoreCase("39")){
		  if(!Arrays.asList(cover).contains("DB")){
			  if(corporateFlag==false){
			     Context.local().getPages().getPage(OfferCoversPage.class).deleteDB();
			  }
		  }
		  else{
		    if(Arrays.asList(cover).contains("DB") && corporateFlag==true){
		      if(insuredFlag==false){
		        addInsuredDetails(testData);
		        insuredFlag=true;
		      }
		      else{
		    	Context.local().getPages().getPage(OfferCoversPage.class).clickAddCover();
		      }
		    Context.local().getPages().getPage(OfferCoversPage.class).selectAddCover("Death benefit, company");
			Context.local().getPages().getPage(OfferCoversPage.class).clickAdd();
		    }
		    else{
		  	Context.local().getPages().getPage(OfferCoversPage.class).clickDB();
		    }
			Context.local().getPages().getPage(OfferCoversPage.class).setCoverAmount(testData.get("DB_CoverAmount"));
			
			if(!(testData.get("BindingMethod").equals("")||testData.get("BindingMethod").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).selectCoverBindingMethod(testData.get("BindingMethod"));
			}
			if(!(testData.get("DecreasedAmount").equals("")||testData.get("DecreasedAmount").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).setDecreasedAmount(testData.get("DecreasedAmount"));
			}
			Context.local().getPages().getPage(OfferCoversPage.class).clickCalcPremiumAmount();
			Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiary();
			Context.local().getPages().getPage(OfferCoversPage.class).selectAddBeneficiary(testData.get("DB_Beneficiary"));
			if(testData.get("DB_Beneficiary").equals("Free Text Group")){				
				Context.local().getPages().getPage(OfferCoversPage.class).setFreetext(testData.get("FreeText"));
			}
			Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiaryAdd();
			Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			if(Context.local().getPages().getPage(OfferCoversPage.class).verifyCampaignMsg()==true){
				Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			}
		}
			
		if(!Arrays.asList(cover).contains("PD")){
			if(corporateFlag==false){
			   Context.local().getPages().getPage(OfferCoversPage.class).deletePD();
		    }
		}
		else{
			if(corporateFlag==true){
			    if(insuredFlag==false){
			       addInsuredDetails(testData);
			       insuredFlag=true;
			    }
			    else{
			       Context.local().getPages().getPage(OfferCoversPage.class).clickAddCover();
			    }
			    Context.local().getPages().getPage(OfferCoversPage.class).selectAddCover("Permanent disability, company");
				Context.local().getPages().getPage(OfferCoversPage.class).clickAdd();
			}
			else{
			     Context.local().getPages().getPage(OfferCoversPage.class).clickPD();
			}
			Context.local().getPages().getPage(OfferCoversPage.class).setCoverAmount(testData.get("PD_CoverAmount"));
			if(!(testData.get("BindingMethod").equals("")||testData.get("BindingMethod").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).selectCoverBindingMethod(testData.get("BindingMethod"));
			}
			if(!(testData.get("DecreasedAmount").equals("")||testData.get("DecreasedAmount").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).setDecreasedAmount(testData.get("DecreasedAmount"));
			}
			Context.local().getPages().getPage(OfferCoversPage.class).clickCalcPremiumAmount();
			Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			if(Context.local().getPages().getPage(OfferCoversPage.class).verifyCampaignMsg()==true){
				Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
		    }
		}
		
		if(!Arrays.asList(cover).contains("CI")){
			if(corporateFlag==false){
			Context.local().getPages().getPage(OfferCoversPage.class).deleteCI();
			}
			}
        else{
        	if(corporateFlag==true){
			      if(insuredFlag==false){
			        addInsuredDetails(testData);
			        insuredFlag=true;
			      }
			      else{
				    Context.local().getPages().getPage(OfferCoversPage.class).clickAddCover();
				  }
				    Context.local().getPages().getPage(OfferCoversPage.class).selectAddCover("Critical illness, company");
					Context.local().getPages().getPage(OfferCoversPage.class).clickAdd();
				  }
			 else{
        	        Context.local().getPages().getPage(OfferCoversPage.class).clickCI();
			     }
        	Context.local().getPages().getPage(OfferCoversPage.class).setSmokerStatus(testData.get("SmokerStatus"));
			Context.local().getPages().getPage(OfferCoversPage.class).setCoverAmount(testData.get("CI_CoverAmount"));
			if(!(testData.get("BindingMethod").equals("")||testData.get("BindingMethod").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).selectCoverBindingMethod(testData.get("BindingMethod"));
			}
			if(!(testData.get("DecreasedAmount").equals("")||testData.get("DecreasedAmount").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).setDecreasedAmount(testData.get("DecreasedAmount"));
			}
			Context.local().getPages().getPage(OfferCoversPage.class).clickCalcPremiumAmount();
			Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			 if(Context.local().getPages().getPage(OfferCoversPage.class).verifyCampaignMsg()==true){
				Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			  }
		}
	  }
		if(productID.equals("39") && corporateFlag == false){
		if(!Arrays.asList(cover).contains("DPDCAP")){
			Context.local().getPages().getPage(OfferCoversPage.class).deleteDPDCAP();
			}
        else{
           Context.local().getPages().getPage(OfferCoversPage.class).clickDeathorPDbyAccidentPrivate();        	
		   Context.local().getPages().getPage(OfferCoversPage.class).setCoverAmount(testData.get("DPDCA_CoverAmount"));
			if(!(testData.get("BindingMethod").equals("")||testData.get("BindingMethod").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).selectCoverBindingMethod(testData.get("BindingMethod"));
			}
			
			if(!(testData.get("DecreasedAmount").equals("")||testData.get("DecreasedAmount").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).setDecreasedAmount(testData.get("DecreasedAmount"));
			}
			
			Context.local().getPages().getPage(OfferCoversPage.class).clickCalcPremiumAmount();
			addDPDCABeneficiary(testData);
			Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			
			if(Context.local().getPages().getPage(OfferCoversPage.class).verifyCampaignMsg()==true){
				Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			}
        }
		}
		
		else if(productID.equals("39") && corporateFlag == true){
		if(Arrays.asList(cover).contains("DPDCAC")){			
        	  if(insuredFlag==false){
			        addInsuredDetails(testData);
			        insuredFlag=true;
			      }
			  else{
			    Context.local().getPages().getPage(OfferCoversPage.class).clickAddCover();  
			  }
        	Context.local().getPages().getPage(OfferCoversPage.class).selectAddCover("Death or permanent disability caused by an accident, Corporate");
          	Context.local().getPages().getPage(OfferCoversPage.class).clickAdd();         	        	
			Context.local().getPages().getPage(OfferCoversPage.class).setCoverAmount(testData.get("DPDCA_CoverAmount"));
			if(!(testData.get("BindingMethod").equals("")||testData.get("BindingMethod").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).selectCoverBindingMethod(testData.get("BindingMethod"));
			}
			if(!(testData.get("DecreasedAmount").equals("")||testData.get("DecreasedAmount").equals("NA"))){				
				Context.local().getPages().getPage(OfferCoversPage.class).setDecreasedAmount(testData.get("DecreasedAmount"));
			}
			Context.local().getPages().getPage(OfferCoversPage.class).clickCalcPremiumAmount();
			
			addDPDCABeneficiary(testData);
			
			Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			
			if(Context.local().getPages().getPage(OfferCoversPage.class).verifyCampaignMsg()==true){
			Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			}
		}
		}
		if(productID.equals("9") && corporateFlag == false){
			if(!Arrays.asList(cover).contains("PAH")){
				Context.local().getPages().getPage(OfferCoversPage.class).deletePAH();
			}
			else{
				Context.local().getPages().getPage(OfferCoversPage.class).clickPAH();
				Context.local().getPages().getPage(OfferCoversPage.class).setCoverAmount(testData.get("PAH_CoverAmount"));
				Context.local().getPages().getPage(OfferCoversPage.class).clickCalcPremiumAmount();
				Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiary();
				Context.local().getPages().getPage(OfferCoversPage.class).setFreeTextGroupName(testData.get("PAH_Beneficiary"));
				Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiaryAdd();
				Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
				if(Context.local().getPages().getPage(OfferCoversPage.class).verifyCampaignMsg()==true){
					Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
				}
			}
		}
		
		if(productID.equals("9") && corporateFlag == true){
			if(Arrays.asList(cover).contains("CoverOffAcc")){			
				if(insuredFlag==false){
				     addInsuredDetails(testData);
				     insuredFlag=true;
				}
				else{
					Context.local().getPages().getPage(OfferCoversPage.class).clickAddCover();  
				}
				Context.local().getPages().getPage(OfferCoversPage.class).selectAddCover("Covers for accidents");
          	  	Context.local().getPages().getPage(OfferCoversPage.class).clickAdd();         	        	
	          	Context.local().getPages().getPage(OfferCoversPage.class).setCoverAmount(testData.get("CoverForAcc_CoverAmount"));
				Context.local().getPages().getPage(OfferCoversPage.class).clickCalcPremiumAmount();
				Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiary();
				Context.local().getPages().getPage(OfferCoversPage.class).setFreeTextGroupName(testData.get("CoverForAcc_Beneficiary"));
				Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiaryAdd();
				Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
				if(Context.local().getPages().getPage(OfferCoversPage.class).verifyCampaignMsg()==true){
					Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
				}
			}
		}	
		if(productID.equals("58")){
    		Context.local().getPages().getPage(OfferCoversPage.class).clickDCS();
    		Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiary();
    		Context.local().getPages().getPage(OfferCoversPage.class).selectAddBeneficiary(testData.get("DCS_Beneficiary"));
			if(testData.get("DB_Beneficiary").equals("Free Text Group")){				
				Context.local().getPages().getPage(OfferCoversPage.class).setFreetext(testData.get("FreeText"));
			}
    		Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiaryAdd();
    		Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			if(Context.local().getPages().getPage(OfferCoversPage.class).verifyCampaignMsg()==true){
				Context.local().getPages().getPage(OfferCoversPage.class).clickSave();
			}
		}
	}
	
	/**
	 * Method to be used for adding Insured Details for Corporate Customer
	 */	
	public void addInsuredDetails(LinkedHashMap<String, String> testData) throws Exception{
	   Context.local().getPages().getPage(OfferCoversPage.class).clickAddInsured();
	   Context.local().getPages().getPage(OfferCoversPage.class).setInsuredIdenfier(testData.get("InsuredIdentifier"));
	   Context.local().getPages().getPage(OfferCoversPage.class).clickFindInsuredIdentifier();
	}
	
	/**
	 * Method to be used for adding beneficiary for 
	 * Death or permanent disability caused by an accident, Private
	 * and Death or permanent disability caused by an accident, Corporate
	 */	
	public void addDPDCABeneficiary(LinkedHashMap<String, String> testData) throws Exception{
		String[] beneficiary = testData.get("DPDCA_Beneficiary").split(",");
		String[] coverType = testData.get("CoverType").split(",");
		for(int beneficiarycount=0;beneficiarycount<beneficiary.length;beneficiarycount++){
		Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiary();
		Context.local().getPages().getPage(OfferCoversPage.class).selectAddBeneficiary(beneficiary[beneficiarycount]);
		if(beneficiary[beneficiarycount].equals("Free Text Group")){				
			Context.local().getPages().getPage(OfferCoversPage.class).setFreetext(testData.get("FreeText"));
		}
		Context.local().getPages().getPage(OfferCoversPage.class).selectCoverType(coverType[beneficiarycount]);
		Context.local().getPages().getPage(OfferCoversPage.class).clickAddBeneficiaryAdd();
		}
	}
	/**
	 * Method to be used to input distribution % for each investment in Investment Plan tab
	 * @param String
	 * @param String
	 * @return No return value/type
	 */
	public void enterInvestmentDistribution(LinkedHashMap<String, String> testData) {		    	
    	
		String[] arrDistribution =  testData.get("InvestmentPercentage").split(",");
		String[] arrInvestments=testData.get("InvestmentName").split(",");
		
		for (int i=0;i<arrInvestments.length;i++)
		{
			Context.global().getDriver().findElement(By.xpath("//td[contains(text(),'"+arrInvestments[i]+"')]/following-sibling::td[1]//input")).clear();
			Context.global().getDriver().findElement(By.xpath("//td[contains(text(),'"+arrInvestments[i]+"')]/following-sibling::td[1]//input")).sendKeys(arrDistribution[i]);
		}
	    	   
	}
	    
			
	/**
	 * Method to be used select investments
	 * @param String	 
	 * @return No return value/type
	 */		
	public void selectInvestments(LinkedHashMap<String, String> testData) {		    	
		String[] arrInvestments =  testData.get("InvestmentName").split(","); 			
		for (int i=0;i<arrInvestments.length;i++)
		{
			Context.global().getDriver().findElement(By.xpath("//td[contains(text(),'"+arrInvestments[i]+"')]/preceding-sibling::td//input[1]")).click();
	    }
	}
		
	/**
	 * Method to be used for verify the printout request and return batch run id
	 * @param String	 
	 * @return batch run id
	 */	
	public String  viewPrintoutRequest(String linkname,String customerName) throws Exception{
		
		String runNumber=null;		
		List<WebElement> links = Context.global().getDriver().findElements(By.xpath("//td[contains(. ,'Request')]//preceding-sibling::td[3]//a[contains(. , '"+linkname+"')]"));
		for(WebElement ele : links){
			ele.click();
			if (customerName.equalsIgnoreCase(Context.global().getDriver().findElement(By.xpath("//td[contains(. ,'"+customerName+"')]")).getText())){
				runNumber= Context.global().getDriver().findElement(By.xpath("//th[contains(. ,'Number of run')]//following-sibling ::td[1]")).getText();
				Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickReturn();
				return runNumber;
			}
			Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickReturn();			
		}
		return runNumber;
	}
	
	/**
	 * Method to be used for create and send letter
	 * @param String	 
	 * @return no return value /type
	 */	
	public void createANDsendLetter(String runNumber) throws Exception{	
			
		Context.global().getDriver().findElement(By.xpath("//td[contains(. ,'"+runNumber+"')]//preceding-sibling ::td[2]//input")).click();
		Context.local().getPages().getPage(HomeWorkflow.class).clickStart();		
		}
		
	/**
	 * Method to save letter from view events
	 * @param linkname,customername	 
	 * @return no return value /type
	 */	
	public void saveLetterFromViewEvents(String linkname,String customerName ) throws Exception{
		
		WebElement letterName;
		Context.local().getPages().getPage(LHN.class).clickPolicy();
		Context.local().getPages().getPage(LHN.class).clickEventView();
		Context.local().getPages().getPage(EventViewPage.class).clickViewletters();
		letterName=Context.global().getDriver().findElement(By.xpath("//td[contains(text(),'"+customerName+"')]/..//a[text()='"+linkname+"'"));
		Context.global().getFileDownloader().downloadFile(letterName, "C:\\");
		
	}
	
	/**
	 * Method to find column names in table
	 * @param column names ,screenshot name	 
	 * @return no return value /type
	 */	
	public void verifyColumnNames(String columnNames,String screeshotName) throws IOException{
		
		String allColumns;
		
		String[] arrColumns =  columnNames.split(","); 			
		for (int i=0;i<arrColumns.length;i++)
		{
			allColumns=Context.global().getDriver().findElement(By.xpath("//table[@class='scrollTable']//../tr")).getText();
			
			if(allColumns.contains(arrColumns[i])){
				Report.updateReport("PASS",arrColumns[i]+"column found ", Context.global().getDriver().getTitle() + screeshotName);
			}
		}
	}
	
	/**
	 * Method to verify error message
	 * @param expected error message ,screenshot name	 
	 * @return no return value /type
	 */	
	public void verifyErrorMessage(String expectederrorMessage,String screeshotName) throws IOException{
		
		String errorMessageFromApp;		
		errorMessageFromApp=Context.global().getDriver().findElement(By.xpath("//div[@class='errorbox']")).getText();
		
		if(errorMessageFromApp.equals(expectederrorMessage)){
			Report.updateReport("PASS","shows expecated error message ", Context.global().getDriver().getTitle() + expectederrorMessage);
		}
		else{
			Report.updateReport("FAIL","does not show expected error message ", Context.global().getDriver().getTitle() + expectederrorMessage);
		}		
	}
	/**
	 * Method to return the required value from Offer header 	 	
	 * @param testData	 
	 * @return no return value /type
	 */	
	public String getValueFromOfferHeader(String value) throws Exception{	
		String valueFromHeader="";
		String[] arrValueformHeader=Context.local().getPages().getPage(OfferMakePolicy.class).getDataFromHeader().split("\\|");
		
		if(value.equalsIgnoreCase("CustomerName")){
			valueFromHeader= arrValueformHeader[0];
		}
		else if(value.equalsIgnoreCase("CustomerID")){
			valueFromHeader= arrValueformHeader[1]; 
		}
		else if(value.equalsIgnoreCase("OfferID")){
			valueFromHeader= arrValueformHeader[2]; 
		}
		else if(value.equalsIgnoreCase("ProductID")){
			valueFromHeader= arrValueformHeader[3]; 
		}		
		return valueFromHeader; 		
	}
	
	/**
	 * Method to verify annual cover premiums on annual development of 
	 	cover premiums link on offer calculation page of product 39
	 * @param testData	 
	 * @return no return value /type
	 */	
	public void VerifyAnnualCoverPremiums(LinkedHashMap<String, String> testData) throws Exception{
		
		HashMap<String,Integer> CoverNameDetails;
		String[] covers = testData.get("ResultOfCalcCovers").split("\\|");
		String[] coveramnt = testData.get("AnnualCoverPrm").split("\\|");
		String year= testData.get("StmntToDownLoad");
		
		Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).clickAnnualCoverPremium();
		CoverNameDetails=fetchCoverColumnNo(covers);
		Integer row=fetchAnnualCoverPremiumYear(year);
		for(int i = 0; i<covers.length; i++)
		{
			String appcoveramount=Context.local().getPages().getPage(OfferResultCalcAndPrinting.class).fetchAnnualCoverPremium(row,CoverNameDetails.get(covers[i]));
			if(appcoveramount.equalsIgnoreCase(coveramnt[i]))
			{
				Report.updateReport("PASS","Expected "+covers[i]+" premium amount is: "+coveramnt[i]+";Actual is:"+appcoveramount);
			}else
			{
				Report.updateReport("FAIL","Expected "+covers[i]+" premium amount is: "+coveramnt[i]+";Actual is:"+appcoveramount);
			}
		}
		Report.updateReport("INFO","Application annual developement of cover premiums","Annual developement of cover premiums");
	}
	
	/**
	 * Method to fetch column numbers of respective covers on annual development of cover premiums link on 
	 	result of calculations tab of product 39.
	 * @param beneficiary	 
	 * @return HashMap<String,Integer>
	 */	
	public HashMap<String,Integer> fetchCoverColumnNo(String[] beneficiary){
    	
    	HashMap<String,Integer> coverNameDetails=new HashMap<String,Integer>();
    	WebElement tbody=Context.global().getDriver().findElement(By.xpath("//h2[contains(text(),'Annual development of cover premiums')]//following-sibling::div[1]/table/thead/tr"));
    	List<WebElement> annualPremiumCoverList=tbody.findElements(By.tagName("th"));
    	Integer colNo = null;
    	for(int i=0;i< beneficiary.length;i++){
    		
    		for(int j=0;j<annualPremiumCoverList.size();j++){
    			if(beneficiary[i].equalsIgnoreCase(annualPremiumCoverList.get(j).getText().toString())){
    				colNo=j+1;
        			break;
    			}  			
    		}
    		coverNameDetails.put(beneficiary[i], colNo);
    	}
    	return coverNameDetails;
    }
	
	/**
	 * Method to change decision code of all covers to normal in case of Comprehensive or complex HD
	 	while accepting offer for product 39 and 9.	 
	 * @return no return value /type
	 */
	public void changeDecisionCode() throws Exception{
    	
    	WebElement tbody=Context.global().getDriver().findElement(By.xpath("//h2[contains(text(),'Covers')]//following-sibling::div[1]/table/tbody"));
    	List<WebElement> rows=tbody.findElements(By.tagName("tr"));
    	for(int i=0;i< rows.size();i++){
    		String xpath="(//input[@value='Restrictions'])["+(i+1)+"]";
			Context.global().getDriver().findElement(By.xpath(xpath)).sendKeys("");
			Context.global().getDriver().findElement(By.xpath(xpath)).click();
			Context.global().getSeleniumUtils().selectValueFromDropDown(Context.global().getDriver().findElement(By.name("indexedCoverDesicionCode["+i+"]")), 
	    			"visibleText", "Normal");
    		Context.local().getPages().getPage(OfferMakePolicy.class).clickSave();
    	}
    }
	
	/**
	 * Method to fetch row number of required year on annual development of cover premiums link on 
	 	result of calculations tab of product 39.
	 * @param value 
	 * @return Integer
	 */	
	public int fetchAnnualCoverPremiumYear(String value){
    	
    	WebElement tbody=Context.global().getDriver().findElement(By.xpath("//h2[contains(text(),'Annual development of cover premiums')]//following-sibling::div[1]/table/tbody"));
    	List<WebElement> tablerows=tbody.findElements(By.tagName("tr"));
    	int row = 0;
    	for(int i=1;i<tablerows.size();i++){
    		String year = Context.global().getDriver().findElement(By.xpath("//h2[contains(text(),'Annual development of cover premiums')]//following-sibling::div[1]/table/tbody/tr["+i+"]/td[1]")).getText().trim();
    		if(value.equalsIgnoreCase(year)){
    			row=i;
    			break;
    		}
    	}
		return row;
    }
	
		
}
