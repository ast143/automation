package headlessBrowser;

import org.openqa.selenium.By;              
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;      
import org.openqa.selenium.htmlunit.HtmlUnitDriver;   
import org.testng.annotations.Test;

public class HtmlUnitDriverTest {
	                                     
	@Test            
	public void test1() throws InterruptedException {
	                	 
	                     // Creating a new instance of the HTML unit driver        
	                     WebDriver driver = new HtmlUnitDriver();
	                      
	                    // Navigate to LSI URL       
	                     driver.get("http://vda1cs0402.qaoneadr.local:5003/lis/welcome.do");                                       
	          
	                     // Locate the various elements using its name   
	                     WebElement userid = driver.findElement(By.name("j_username"));
	                     WebElement passwrd = driver.findElement(By.name("j_password"));
	                     WebElement acceptBtn = driver.findElement(By.name("submit"));
	                     
	                     userid.sendKeys("Z931099");               
	                     passwrd.sendKeys("admin099");   
	                     System.out.println("Page title is: " + driver.getTitle());
	                     acceptBtn.click();
	                                          
	                     WebElement element = driver.findElement(By.name("searchInput1")); 
	                     WebElement findBtn = driver.findElement(By.name("search")); 
	                     
	                    // Enter a search query         
	                    element.sendKeys("291141-0027");   

	                    findBtn.click();                    
	                    
	                   // This code will print the page title              
	                    System.out.println("Page title is: " + driver.getTitle());         
	                    
	                    driver.quit();                
	}


}
