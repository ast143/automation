package headlessBrowser;

import org.testng.annotations.Test;

public class phentomJStest {
	
	@Test
	public void phentomJStest(){
		
		
		
	}

}
