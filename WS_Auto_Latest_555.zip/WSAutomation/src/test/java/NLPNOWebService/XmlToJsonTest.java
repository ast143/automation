package NLPNOWebService;

import org.json.JSONObject;
import org.json.XML;
import org.testng.annotations.Test;

public class XmlToJsonTest {

	private static final String XML_TEXT = "<note>\n" + "<to>Tove</to>\n"
			+ "<from>Jani</from>\n" + "<heading>Reminder</heading>\n"
			+ "<body>Don't forget me this weekend!</body>\n" + "</note>";
	private static final int PRETTY_PRINT_INDENT_FACTOR = 4;

	@Test
	public void convert() {
		JSONObject xmlJSONObj = XML.toJSONObject(XML_TEXT);
		String jsonPrettyPrintString = xmlJSONObj
				.toString(PRETTY_PRINT_INDENT_FACTOR);
		System.out.println(jsonPrettyPrintString);
		
		return;
	}

}
