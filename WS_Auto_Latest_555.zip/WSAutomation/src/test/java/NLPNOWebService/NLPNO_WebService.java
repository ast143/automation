package NLPNOWebService;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import verifyLISnLEAPservicefailure_languagewebservice.VerifyLISnLEAPservicefailure_languagewebservice;

import com.nordea.framework.Context;
import com.nordea.pages.PageObject;
import com.nordea.utility.DriverUtils;
import com.nordea.utility.ExcelAnnotation;
import com.nordea.utility.ExcelDataProviderClass;
import com.nordea.utility.LoggingUtils;
import com.nordea.utility.Report;
import com.nordea.workflow.NLPNOwebservice;
import com.nordea.workflow.Workflow;

public class NLPNO_WebService {

	private ThreadLocal<DriverUtils> driverUtil = new ThreadLocal<DriverUtils>();
	final static Logger LOGGER = Logger
			.getLogger(VerifyLISnLEAPservicefailure_languagewebservice.class);
	private ThreadLocal<PageObject> page = new ThreadLocal<PageObject>();
	private ThreadLocal<Workflow> workflow = new ThreadLocal<Workflow>();

	@BeforeClass(alwaysRun = true)
	public void beforeClass() throws Exception {
		LoggingUtils.configureLogProperties();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeMethod(Method mtd) throws Exception {
		driverUtil.set(new DriverUtils().getDriverUtilsInstance());
		driverUtil.get().initiateDriver(mtd);
		Report.initiateReport(mtd);
		Context.local().setPages();
		page.set(Context.local().getPages());
		Context.local().setWorkflows();
		workflow.set(Context.local().getWorkflows());
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown(ITestResult result) throws IOException {
		Report.updateReport(result);
	}

	@ExcelAnnotation(filename = "wsNLPNOTestData", sheetname = "tradevalues")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebServices - NLPNOService" })
	public void lastExecutedTradedate(LinkedHashMap<String, String> testData)
			throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(NLPNOwebservice.class)
				.wsnlpnoService(testData);

	}
}
