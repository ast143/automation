package wsHeaderValidation;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.nordea.framework.Context;
import com.nordea.pages.PageObject;
import com.nordea.utility.DriverUtils;
import com.nordea.utility.ExcelAnnotation;
import com.nordea.utility.ExcelDataProviderClass;
import com.nordea.utility.LoggingUtils;
import com.nordea.utility.Report;
import com.nordea.workflow.HeaderValidation;
import com.nordea.workflow.Workflow;

public class wsHeaderValidation {

	private ThreadLocal<DriverUtils> driverUtil = new ThreadLocal<DriverUtils>();
	final static Logger LOGGER = Logger.getLogger(wsHeaderValidation.class);
	private ThreadLocal<PageObject> page = new ThreadLocal<PageObject>();
	private ThreadLocal<Workflow> workflow = new ThreadLocal<Workflow>();

	@BeforeClass(alwaysRun = true)
	public void beforeClass() throws Exception {
		LoggingUtils.configureLogProperties();
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeMethod(Method mtd) throws Exception {
		driverUtil.set(new DriverUtils().getDriverUtilsInstance());
		driverUtil.get().initiateDriver(mtd);
		Report.initiateReport(mtd);
		Context.local().setPages();
		page.set(Context.local().getPages());
		Context.local().setWorkflows();
		workflow.set(Context.local().getWorkflows());
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown(ITestResult result) throws IOException {
		Report.updateReport(result);
	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * customer-categories Created By : Alok Tiwari Creation Date : 11/07/2017
	 * Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Categories" })
	public void GET_customer_categories_mising_header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);
	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Categories" })
	public void GET_customer_categories_mising_header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);
	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Categories" })
	public void GET_customer_categories_misingHeader_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);
	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Categories" })
	public void GET_customer_categories_misingHeader_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);
	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Categories" })
	public void GET_customer_categories_MissingHeader_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * customer_policies Created By : Alok Tiwari Creation Date : 11/07/2017
	 * Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Policies" })
	public void GET_customer_policies_mising_header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);
	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Policies" })
	public void GET_customer_policies_mising_header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);
	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Policies" })
	public void GET_customer_policies_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);
	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Policies" })
	public void GET_customer_policies_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);
	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Policies" })
	public void GET_customer_policies_MissingHeader_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);
	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * incompleteSavingAllocations Created By : Alok Tiwari Creation Date :
	 * 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Incomplete Saving Allocations" })
	public void GET_incompleteSavingAllocations_mising_header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Incomplete Saving Allocations" })
	public void GET_incompleteSavingAllocations_mising_header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Incomplete Saving Allocations" })
	public void GET_incompleteSavingAllocations_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Incomplete Saving Allocations" })
	public void GET_incompleteSavingAllocations_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-Incomplete Saving Allocations" })
	public void GET_incompleteSavingAllocations_MissingHeader_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * Customer_Policy_InvestmentPlan Created By : Alok Tiwari Creation Date :
	 * 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-InvestmentPlan" })
	public void GET_Customer_Policy_InvestmentPlan_mising_header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-InvestmentPlan" })
	public void GET_Customer_Policy_InvestmentPlan_mising_header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-InvestmentPlan" })
	public void GET_Customer_Policy_InvestmentPlan_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-InvestmentPlan" })
	public void GET_Customer_Policy_InvestmentPlan_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService-InvestmentPlan" })
	public void GET_Customer_Policy_InvestmentPlan_MissingHeader_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * customer_prefer_language Created By : Alok Tiwari Creation Date :
	 * 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebServices - customer_prefer_language" })
	public void GET_customer_prefer_language_mising_header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebServices - customer_prefer_language" })
	public void GET_customer_prefer_language_mising_header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebServices - customer_prefer_language" })
	public void GET_customer_prefer_language_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebServices - customer_prefer_language" })
	public void GET_customer_prefer_language_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebServices - customer_prefer_language" })
	public void GET_customer_prefer_language_MissingHeader_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included : Marketing
	 * Created By : Alok Tiwari Creation Date : 11/07/2017 Requirement ID :
	 * NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService - Marketing" })
	public void GET_Marketing_mising_header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService - Marketing" })
	public void GET_Marketing_mising_header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService - Marketing" })
	public void GET_Marketing_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService - Marketing" })
	public void GET_Marketing_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidation")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "WebService - Marketing" })
	public void GET_Marketing_MissingHeader_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.wsHdrvalidation(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName :
	 * Customer-Policy-PaymentPlan WebServices Included : This include all the
	 * web services which is having mandatory input field as "CustomerID" &&
	 * "PolicyID" only. Created By : Alok Tiwari Creation Date : 11/07/2017
	 * Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-PaymentPlan" })
	public void GET_PaymentPlan_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-PaymentPlan" })
	public void GET_PaymentPlan_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-PaymentPlan" })
	public void GET_PaymentPlan_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-PaymentPlan" })
	public void GET_PaymentPlan_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-PaymentPlan" })
	public void GET_PaymentPlan_MissingHeader_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName :
	 * savingAllocation-history Description : This include all the web services
	 * which is having mandatory input field as "CustomerID" && "PolicyID" only.
	 * Created By : Alok Tiwari Creation Date : 11/07/2017 Requirement ID :
	 * NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savingAllocation-history" })
	public void GET_SavingsAllocationHistory_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savingAllocation-history" })
	public void GET_SavingsAllocationHistory_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savingAllocation-history" })
	public void GET_SavingsAllocationHistory_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savingAllocation-history" })
	public void GET_SavingsAllocationHistory_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savingAllocation-history" })
	public void GET_SavingsAllocationHistory_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName :
	 * savingsAllocationDetails Description : This include all the web services
	 * which is having mandatory input field as "CustomerID" && "PolicyID" only.
	 * Created By : Alok Tiwari Creation Date : 11/07/2017 Requirement ID :
	 * NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savings Allocation Details" })
	public void GET_SavingsAllocationDetails_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savings Allocation Details" })
	public void GET_SavingsAllocationDetails_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savings Allocation Details" })
	public void GET_SavingsAllocationDetails_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savings Allocation Details" })
	public void GET_SavingsAllocationDetails_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "savings Allocation Details" })
	public void GET_SavingsAllocationDetails_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName :
	 * additionalPremiumBankDetails Description : This include all the web
	 * services which is having mandatory input field as "CustomerID" &&
	 * "PolicyID" only. Created By : Alok Tiwari Creation Date : 11/07/2017
	 * Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "additionalPremiumBankDetails" })
	public void GET_additionalPremiumBankDetails_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "additionalPremiumBankDetails" })
	public void GET_additionalPremiumBankDetails_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "additionalPremiumBankDetails" })
	public void GET_additionalPremiumBankDetails_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "additionalPremiumBankDetails" })
	public void GET_additionalPremiumBankDetails_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "additionalPremiumBankDetails" })
	public void GET_additionalPremiumBankDetails_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName : Policy-basic
	 * Description : This include all the web services which is having mandatory
	 * input field as "CustomerID" && "PolicyID" only. Created By : Alok Tiwari
	 * Creation Date : 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-basic" })
	public void GET_PolicyBasic_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-basic" })
	public void GET_PolicyBasic_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-basic" })
	public void GET_PolicyBasic_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-basic" })
	public void GET_PolicyBasic_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-basic" })
	public void GET_PolicyBasic_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName :
	 * pension-basicDetails Description : This include all the web services
	 * which is having mandatory input field as "CustomerID" && "PolicyID" only.
	 * Created By : Alok Tiwari Creation Date : 11/07/2017 Requirement ID :
	 * NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-basicDetails" })
	public void GET_pensionBasicDetails_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-basicDetails" })
	public void GET_pensionBasicDetails_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-basicDetails" })
	public void GET_pensionBasicDetails_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-basicDetails" })
	public void GET_pensionBasicDetails_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-basicDetails" })
	public void GET_pensionBasicDetails_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName : pension-forecast
	 * Description : This include all the web services which is having mandatory
	 * input field as "CustomerID" && "PolicyID" only. Created By : Alok Tiwari
	 * Creation Date : 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-forecast" })
	public void GET_PensionForecast_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-forecast" })
	public void GET_PensionForecast_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-forecast" })
	public void GET_PensionForecast_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-forecast" })
	public void GET_PensionForecast_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "pension-forecast" })
	public void GET_PensionForecast_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName : Policy-covers
	 * Description : This include all the web services which is having mandatory
	 * input field as "CustomerID" && "PolicyID" only. Created By : Alok Tiwari
	 * Creation Date : 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-covers" })
	public void GET_PolicyCovers_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-covers" })
	public void GET_PolicyCovers_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-covers" })
	public void GET_PolicyCovers_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-covers" })
	public void GET_PolicyCovers_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Policy-covers" })
	public void GET_PolicyCovers_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName : Policy-covers
	 * Description : This include all the web services which is having mandatory
	 * input field as "CustomerID" && "PolicyID" only. Created By : Alok Tiwari
	 * Creation Date : 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "cutOffTime-flag" })
	public void GET_cutOffTime_flag_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "cutOffTime-flag" })
	public void GET_cutOffTime_flag_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "cutOffTime-flag" })
	public void GET_cutOffTime_flag_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "cutOffTime-flag" })
	public void GET_cutOffTime_flag_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "cutOffTime-flag" })
	public void GET_cutOffTime_flag_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName : withdrawalPlan
	 * Description : This include all the web services which is having mandatory
	 * input field as "CustomerID" && "PolicyID" only. Created By : Alok Tiwari
	 * Creation Date : 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "withdrawalPlan" })
	public void GET_WithdrawalPlan_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "withdrawalPlan" })
	public void GET_WithdrawalPlan_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "withdrawalPlan" })
	public void GET_WithdrawalPlan_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "withdrawalPlan" })
	public void GET_WithdrawalPlan_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "withdrawalPlan" })
	public void GET_WithdrawalPlan_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServicesName : bonusdetail
	 * Description : This include all the web services which is having mandatory
	 * input field as "CustomerID" && "PolicyID" only. Created By : Alok Tiwari
	 * Creation Date : 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "bonusdetail" })
	public void GET_BonusDetails_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "bonusdetail" })
	public void GET_BonusDetails_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "bonusdetail" })
	public void GET_BonusDetails_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "bonusdetail" })
	public void GET_BonusDetails_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "bonusdetail" })
	public void GET_BonusDetails_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustidPolicyID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * Customer-Policy-Product-categories WebServices Included : This include
	 * all the web services which is having mandatory input field as
	 * "CustomerID" && "PolicyID" && "ProductID" only. Created By : Alok Tiwari
	 * Creation Date : 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-Product-categories" })
	public void GET_Product_Categories_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-Product-categories" })
	public void GET_Product_Categories_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-Product-categories" })
	public void GET_Product_Categories_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-Product-categories" })
	public void GET_Product_Categories_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdID(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Customer-Policy-Product-categories" })
	public void GET_Product_Categories_MissingHeader_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdID(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * allowedInvestments WebServices Included : This include all the web
	 * services which is having mandatory input field as "CustomerID" &&
	 * "PolicyID" && "ProductID" && "CatagoryID" only. Created By : Alok Tiwari
	 * Creation Date : 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "allowedInvestments" })
	public void GET_allowedInvestments_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdCtgryid(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "allowedInvestments" })
	public void GET_allowedInvestments_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdCtgryid(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "allowedInvestments" })
	public void GET_allowedInvestments_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdCtgryid(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "allowedInvestments" })
	public void GET_allowedInvestments_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdCtgryid(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "allowedInvestments" })
	public void GET_allowedInvestments_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdCustPlcyProdCtgryid(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * Event-summary WebServices Included : This include all the web services
	 * which is having mandatory input field as "CustomerID" && "PolicyID" &&
	 * "StartDate" && "EndDate" only. Created By : Alok Tiwari Creation Date :
	 * 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-summary" })
	public void GET_EcentSummary_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-summary" })
	public void GET_EcentSummary_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-summary" })
	public void GET_EcentSummary_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-summary" })
	public void GET_EcentSummary_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-summary" })
	public void GET_EcentSummary_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * Event-premiums WebServices Included : This include all the web services
	 * which is having mandatory input field as "CustomerID" && "PolicyID" &&
	 * "StartDate" && "EndDate" only. Created By : Alok Tiwari Creation Date :
	 * 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-premiums" })
	public void GET_Event_premiums_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-premiums" })
	public void GET_Event_premiums_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-premiums" })
	public void GET_Event_premiums_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-premiums" })
	public void GET_Event_premiums_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-premiums" })
	public void GET_Event_premiums_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included :
	 * Event-withdrawals WebServices Included : This include all the web
	 * services which is having mandatory input field as "CustomerID" &&
	 * "PolicyID" && "StartDate" && "EndDate" only. Created By : Alok Tiwari
	 * Creation Date : 11/07/2017 Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-withdrawals" })
	public void GET_Event_Withdrawals_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-withdrawals" })
	public void GET_Event_Withdrawals_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-withdrawals" })
	public void GET_Event_Withdrawals_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-withdrawals" })
	public void GET_Event_Withdrawals_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "Event-withdrawals" })
	public void GET_Event_Withdrawals_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	/**
	 * Test Case 1 Description : Run the all GET web service and perform error
	 * validation for all different headers. WebServices Included : valueChange
	 * WebServices Included : This include all the web services which is having
	 * mandatory input field as "CustomerID" && "PolicyID" && "StartDate" &&
	 * "EndDate" only. Created By : Alok Tiwari Creation Date : 11/07/2017
	 * Requirement ID : NLFI-3607
	 */

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "valueChange" })
	public void GET_ValueChange_Missing_Header_endapplicationID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "valueChange" })
	public void GET_ValueChange_Missing_Header_logonID(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "valueChange" })
	public void GET_ValueChange_mising_XDBFHeader_country(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "valueChange" })
	public void GET_ValueChange_mising_XDBFHeader_channelId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}

	@ExcelAnnotation(filename = "wsTestData", sheetname = "HdrValidationWithHdrInput")
	@Test(dataProviderClass = ExcelDataProviderClass.class, dataProvider = "excel-data-provider", groups = { "valueChange" })
	public void GET_ValueChange_mising_XDBFHeader_sessionId(
			LinkedHashMap<String, String> testData) throws Exception {
		LOGGER.info("================================================================================");
		LOGGER.info("TEST DATA: " + testData);
		LOGGER.info("================================================================================");
		Context.local().getWorkflows().getWorkflow(HeaderValidation.class)
				.verifyhrdStartEndDate(testData);

	}
}
