package ReadFlatFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;

public class readFlatFile {

	public void validate(String isin) throws IOException {
		Map<String, LinkedList<String>> map = getTxtValuesInMap(isin);
//		List<Integer> indexList = getListOfIndexes(map.get("Security ISIN"),
//				isin);
//		double settledValue = 0;
//		for (int index : indexList) {
//			if ("NOK".equalsIgnoreCase(map.get("Security currency").get(index))) {
//				settledValue = settledValue
//						+ Double.parseDouble(map.get("Settled Value")
//								.get(index));
//			}
//		}
		System.out.println(map);
		System.out.println(map.get("Security ISIN"));
	}

	public Map<String, LinkedList<String>> getTxtValuesInMap(String pathofFile)throws IOException {
		String filePath = pathofFile;
		LineIterator it = FileUtils.lineIterator(new File(filePath));
		Map<String, LinkedList<String>> map = new HashMap<String, LinkedList<String>>();
		try {
			String[] arr = it.nextLine().split(";");
			while (it.hasNext()) {
				String currentLine = it.nextLine();
//				if (currentLine.contains(query)) {
					String[] lineArr = currentLine.split(";");
					for (int count = 0; count < lineArr.length; count++) {
						if (map.containsKey(arr[count])) {
							map.get(arr[count]).add(lineArr[count]);
						} else {
							LinkedList<String> list = new LinkedList<String>();
							list.add(lineArr[count]);
							map.put(arr[count], list);
						}
					}
//				}
			}
		} finally {
			LineIterator.closeQuietly(it);
		}
		return map;
	}

	public int getIndex(Map<String, LinkedList<String>> map, String key,
			String value) {
		return map.get(key).indexOf(value);
	}

	public List<Integer> getListOfIndexes(LinkedList<String> list, String search) {
		List<Integer> result = new ArrayList<Integer>();
		for (int count = 0; count < list.size(); count++) {
			if (list.get(count).equalsIgnoreCase(search)) {
				result.add(count);
			}
		}
		return result;
	}

}
