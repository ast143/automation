package WSAutomation.WebServicePOC;

import java.io.IOException;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import WSAutomation.TestSuiteBase.SuiteBase;
import WSAutomation.utility.wsUtils;

public class mbaWebService extends SuiteBase {

	/**
	 * webServicesAutopoc- Web Service automation POC for three web services MBA
	 * Service Description , Policy List Service Description , Saving Allocation
	 * Details Service Description
	 * 
	 * Functionality Created By : Alok Tiwari Reviewed By :Nitesh Khanna Review
	 * Date : 05/04/2017 Modified By : Alok Tiwari (Added the comments for this
	 * class) Last Modified Date : 16/01/2017 Reviewed By : Nitesh Khanna Review
	 * Date : 05/04/2017
	 */

	@BeforeTest()
	public void setUp() throws IOException {
		init();
		wsUtils.initiateLogger();
	}

	@AfterMethod
	public void tearDown(ITestResult result) throws IOException {
		wsUtils.updateReport(result);

	}

	@Test
	public void webServicePOC() throws InterruptedException {
		wsUtils.initiateReport("WebServiceAutomationPOC - Summary");
		String baseURL = Config.get("baseURL").toString();
		String custID = Config.get("cust_id").toString();
		String wcNamenKey = Config.get("wcNamenKey").toString();
		String xdbfsrvsreqcntxt = Config.get("XDBFServiceRequestContext")
				.toString();
		String plsdHeader = Config.get("plsdHeaders").toString();
		String baseURL2 = Config.get("baseURL2").toString();
		String baseURL3 = Config.get("baseURL3").toString();
		String path = Config.get("path").toString();
		String plsdHeader1 = Config.get("plsdHeaders1").toString();

		wsobj.mbaWebSrvice(baseURL, custID, wcNamenKey, xdbfsrvsreqcntxt,
				plsdHeader, baseURL2, baseURL3, path, plsdHeader1);

	}
}
